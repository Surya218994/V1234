// =================================================================================
//                                 !!! IMPORTANT !!!
// This function is part of the Google Cloud Functions backend implementation.
// The application is currently configured to use the Supabase backend.
// THEREFORE, THIS FILE IS NOT CURRENTLY IN USE.
// This function is called by the 'initiate-call' GCP function.
// =================================================================================

const functions = require('@google-cloud/functions-framework');
const WebSocketServer = require('ws').Server;
const cors = require('cors')({ origin: true });

/**
 * An HTTP-triggered Cloud Function that upgrades the connection to a WebSocket
 * to handle a real-time audio stream from Twilio.
 * 
 * NOTE: For production-grade, high-concurrency WebSocket applications on Google Cloud,
 * it is recommended to use Cloud Run, which has native WebSocket support.
 * This function demonstrates the protocol handling within a Cloud Functions environment.
 */
functions.http('audioStream', (req, res) => {
    // Handle CORS for the initial HTTP request.
    cors(req, res, () => {
        // The 'ws' library doesn't integrate directly with Express-style req/res.
        // We signal that we're done with the HTTP part of the request.
        // The actual WebSocket upgrade is handled by the underlying server instance
        // that the Functions Framework provides.
    });

    // The 'upgrade' event on the raw Node.js server is the key to WebSocket handshakes.
    if (!res.socket.server.listeners('upgrade').some(f => f.name === 'webSocketListener')) {
        const wss = new WebSocketServer({ noServer: true });

        const webSocketListener = (request, socket, head) => {
            // Check if the request is for our function's path.
            if (request.url.includes('/audio-stream')) {
                wss.handleUpgrade(request, socket, head, (ws) => {
                    wss.emit('connection', ws, request);
                });
            } else {
                // If the upgrade request is not for us, destroy the socket.
                socket.destroy();
            }
        };
        
        // Add our listener only once.
        res.socket.server.on('upgrade', webSocketListener);
    
        wss.on('connection', (ws) => {
            console.log('WebSocket connection established with Twilio!');

            ws.on('message', (message) => {
                try {
                    const data = JSON.parse(message.toString());

                    switch (data.event) {
                        case 'connected':
                            console.log('Twilio connected event received:', data);
                            break;
                        case 'start':
                            console.log('Twilio start event received:', data);
                            console.log(`Starting conversation for stream SID: ${data.start.streamSid}`);
                            // This is where the STT -> Gemini -> TTS pipeline would be implemented.
                            break;
                        case 'media':
                            // The `data.media.payload` is a base64 encoded audio chunk (mulaw).
                            // This would be sent to a real-time Speech-to-Text service.
                            break;
                        case 'stop':
                            console.log('Twilio stop event received. Closing connection.', data);
                            ws.close(1000, 'Call ended.');
                            break;
                        default:
                            break;
                    }
                } catch (err) {
                    console.error('Error processing WebSocket message:', err);
                }
            });

            ws.on('error', (error) => {
                console.error('WebSocket error:', error);
            });

            ws.on('close', (code, reason) => {
                console.log(`WebSocket connection closed: ${code} ${reason}`);
            });
        });
    }
});