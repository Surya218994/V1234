// =================================================================================
//                                 !!! IMPORTANT !!!
// This function is part of the Google Cloud Functions backend implementation.
// The application is currently configured to use the Supabase backend.
// THEREFORE, THIS FILE IS NOT CURRENTLY IN USE.
// To use this GCP implementation, you must update the function URL in:
// services/twilioService.ts
// =================================================================================

const functions = require('@google-cloud/functions-framework');
const cors = require('cors')({ origin: true });
const twilio = require('twilio');

/**
 * An HTTP-triggered Cloud Function that securely initiates a Twilio call.
 */
functions.http('initiateCall', (req, res) => {
  // Use the cors middleware to automatically handle OPTIONS preflight requests
  // and add the necessary 'Access-Control-Allow-Origin' header.
  cors(req, res, async () => {
    try {
      const { to, from, agentId, twilioAccountSid, twilioAuthToken } = req.body;

      if (!to || !from || !agentId || !twilioAccountSid || !twilioAuthToken) {
        throw new Error("Missing required parameters in the request body.");
      }
      
      const client = twilio(twilioAccountSid, twilioAuthToken);

      // =================================================================================
      // IMPORTANT: Replace this placeholder with your deployed audio-stream function URL.
      // =================================================================================
      const AUDIO_STREAM_FUNCTION_URL = 'https://your-region-your-project-id.cloudfunctions.net/audio-stream';

      if (AUDIO_STREAM_FUNCTION_URL.includes('your-project-id')) {
        throw new Error("Backend not configured. Please update the audio-stream URL in the 'initiate-call' function.");
      }

      // Convert the HTTPS URL to a WSS (WebSocket Secure) URL.
      const streamUrl = AUDIO_STREAM_FUNCTION_URL.replace('https://', 'wss://');

      // TwiML (Twilio Markup Language) to instruct Twilio on how to handle the call.
      // This tells Twilio to connect the call to our WebSocket audio stream function.
      const twiml = new twilio.twiml.VoiceResponse();
      const connect = twiml.connect();
      const stream = connect.stream({ url: streamUrl });
      stream.parameter({ name: 'agentId', value: agentId });

      // Create the call using the Twilio API.
      const call = await client.calls.create({
        to: to,
        from: from,
        twiml: twiml.toString(),
      });
      
      console.log(`Successfully initiated call with SID: ${call.sid}`);

      // Send a success response back to the frontend with the Call SID.
      res.status(200).json({ callSid: call.sid });

    } catch (error) {
      console.error('Error initiating call:', error);
      const errorMessage = error instanceof Error ? error.message : 'An unknown server error occurred.';
      res.status(500).json({ error: errorMessage });
    }
  });
});