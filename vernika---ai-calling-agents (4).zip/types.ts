


export enum CallStatus {
  IDLE,
  CONNECTING,
  ACTIVE,
  ENDED,
}

export interface Message {
  id: string;
  sender: 'user' | 'agent';
  text: string;
}

export type Page = 'home' | 'features' | 'solutions' | 'pricing' | 'app' | 'login' | 'signup';

export interface Agent {
  id: string;
  name: string;
  title: string;
  description: string;
  status: 'Ready for deployment' | 'In training';
  category: 'Support' | 'Sales' | 'Scheduling' | 'Custom';
  imageUrl: string;
  configuration?: AgentConfigurationData;
}

export interface DropdownOption {
  value: string;
  label: string;
}

export interface AgentConfigurationData {
  agentName: string;
  voice: string; // Represents the Google voice name for medium/high quality
  accent: string; // Represents the browser voice name for low quality
  quality: 'low' | 'medium' | 'high';
  // Step 2: Knowledge
  systemPrompt: string;
  knowledgeBaseFiles?: File[];
  // Step 3: Rules
  conversationStarters: string;
  escalationRules: string;
  prohibitedTopics: string;
}

export interface AuthUser {
  name: string;
  email: string;
  password:string;
}

export interface CallHistoryRecord {
  id: string;
  agent: {
    name: string;
    category: 'Support' | 'Sales' | 'Scheduling' | 'Custom';
  };
  contact: string;
  duration: number; // in seconds
  cost: number; // in local currency (e.g., INR)
  status: 'Completed' | 'Failed' | 'No Answer';
  timestamp: string; // ISO string
  summary: string;
}

export interface TwilioConfig {
  accountSid: string;
  authToken: string;
}

export interface PhoneNumber {
  sid: string;
  phoneNumber: string;
  friendlyName: string;
  linkedAgentId: string | null;
}