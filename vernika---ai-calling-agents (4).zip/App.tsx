
import React, { useState } from 'react';
import Header from './components/Header';
import { HomePage } from './components/HomePage';
import FeaturesPage from './components/FeaturesPage';
import SolutionsPage from './components/SolutionsPage';
import PricingPage from './components/PricingPage';
import { AuthenticatedApp } from './components/AuthenticatedApp';
import LoginPage from './components/LoginPage';
import SignUpPage from './components/SignUpPage';
import { Page } from './types';
import { ChatProvider } from './contexts/ChatContext';
import { ThemeProvider } from './contexts/ThemeContext';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userEmail, setUserEmail] = useState('');

  const navigateTo = (page: Page) => {
    setCurrentPage(page);
    window.scrollTo(0, 0); // Scroll to top on page change
  };

  const handleLoginSuccess = (email: string) => {
    setIsAuthenticated(true);
    setUserEmail(email);
    navigateTo('app');
  };
  
  // Determine the effective page to render, handling auth redirection.
  let pageToRender = currentPage;
  if (currentPage === 'app' && !isAuthenticated) {
    pageToRender = 'login';
  }

  const isAuthPage = pageToRender === 'login' || pageToRender === 'signup';
  const isAppPage = pageToRender === 'app';
  
  const showHeaderFooter = !isAuthPage && !isAppPage;
  const mainContainerClasses = `min-h-screen transition-colors duration-300`;

  const renderCurrentPage = () => {
    switch (pageToRender) {
      case 'features':
        return <FeaturesPage />;
      case 'solutions':
        return <SolutionsPage />;
      case 'pricing':
        return <PricingPage navigateTo={navigateTo} />;
      case 'app':
        return <AuthenticatedApp navigateTo={navigateTo} userEmail={userEmail} />;
      case 'login':
        return <LoginPage navigateTo={navigateTo} onLoginSuccess={handleLoginSuccess} />;
      case 'signup':
        return <SignUpPage navigateTo={navigateTo} onLoginSuccess={handleLoginSuccess} />;
      case 'home':
      default:
        return <HomePage navigateTo={navigateTo} />;
    }
  };

  return (
    <ThemeProvider>
      <ChatProvider>
        <div className={mainContainerClasses}>
          {showHeaderFooter && <Header navigateTo={navigateTo} currentPage={currentPage} />}
          <main className={!isAppPage && !isAuthPage ? "pt-20 md:pt-24" : ""}>
            {renderCurrentPage()}
          </main>
          {showHeaderFooter && (
            <footer className="border-t border-[var(--c-border)] bg-[var(--c-surface)] py-12">
                <div className="container mx-auto px-6 text-center text-[var(--c-text-secondary)]">
                <p>&copy; {new Date().getFullYear()} PitchX. All rights reserved.</p>
                </div>
            </footer>
          )}
        </div>
      </ChatProvider>
    </ThemeProvider>
  );
};

export default App;