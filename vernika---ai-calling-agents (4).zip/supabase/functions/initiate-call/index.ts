
import { serve } from 'https://deno.land/std@0.177.0/http/server.ts'

console.log(`🚀 Function "initiate-call" up and running!`);

declare const Deno: any;

// These headers are essential for the browser to allow the frontend
// to communicate with this function.
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req: Request) => {
  // This is a preflight request. The browser sends it to ask for permission
  // before sending the actual POST request to make a call.
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { to, from, agentId, twilioAccountSid, twilioAuthToken } = await req.json()

    if (!to || !from || !agentId || !twilioAccountSid || !twilioAuthToken) {
        throw new Error("Missing required parameters: to, from, agentId, twilioAccountSid, twilioAuthToken");
    }

    const twilioApiUrl = `https://api.twilio.com/2010-04-01/Accounts/${twilioAccountSid}/Calls.json`;

    // Dynamically get the Supabase project URL from environment variables.
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    if (!supabaseUrl) {
      throw new Error('Could not find SUPABASE_URL environment variable.');
    }
    const streamUrl = `${supabaseUrl.replace('https', 'wss')}/functions/v1/audio-stream`;
    
    // TwiML to connect the call to a WebSocket audio stream.
    const twiml = `
<Response>
  <Connect>
    <Stream url="${streamUrl}">
        <Parameter name="agentId" value="${agentId}" />
    </Stream>
  </Connect>
</Response>
    `.trim();

    const body = new URLSearchParams();
    body.append('To', to);
    body.append('From', from);
    body.append('Twiml', twiml);

    const response = await fetch(twilioApiUrl, {
      method: 'POST',
      headers: {
        'Authorization': 'Basic ' + btoa(`${twilioAccountSid}:${twilioAuthToken}`),
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: body.toString(),
    });

    const responseData = await response.json();

    if (!response.ok) {
        const errorMessage = responseData.message || `Twilio API Error: ${response.status}`;
        throw new Error(errorMessage);
    }
    
    return new Response(JSON.stringify({ callSid: responseData.sid }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    })
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 400,
    })
  }
})