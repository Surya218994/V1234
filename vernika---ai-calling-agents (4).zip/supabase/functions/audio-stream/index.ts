
import { serve } from "https://deno.land/std@0.177.0/http/server.ts";

console.log(`🚀 Function "audio-stream" up and running!`);

declare const Deno: any;

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, upgrade',
};

serve((req: Request) => {
  // Handle CORS preflight requests for WebSocket connections.
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }
  
  if (req.headers.get("upgrade") !== "websocket") {
    return new Response("This endpoint requires a WebSocket connection.", { 
        headers: { 'Content-Type': 'text/plain', ...corsHeaders },
        status: 426 // Upgrade Required
    });
  }

  const { socket, response } = Deno.upgradeWebSocket(req);

  socket.onopen = () => {
    console.log("WebSocket connection established with Twilio!");
  };

  socket.onmessage = (event) => {
    const data = JSON.parse(event.data);

    switch (data.event) {
      case "connected":
        console.log("Twilio connected event received:", data);
        break;
      case "start":
        console.log("Twilio start event received:", data);
        // This is where you would start your STT -> Gemini -> TTS pipeline.
        // For now, let's just log it.
        console.log("Starting conversation for stream SID:", data.start.streamSid);
        break;
      case "media":
        // This is where you receive the raw audio data from the caller.
        // The `data.media.payload` is a base64 encoded audio chunk.
        // You would send this payload to your Speech-to-Text service.
        // console.log("Received audio media chunk from Twilio.");
        break;
      case "stop":
        console.log("Twilio stop event received:", data);
        socket.close(1000, "Call ended");
        break;
      default:
        break;
    }
  };

  socket.onerror = (error) => {
    console.error("WebSocket error:", error);
  };

  socket.onclose = (event) => {
    console.log("WebSocket connection closed:", event.code, event.reason);
  };

  // Add CORS headers to the upgrade response
  for (const [key, value] of Object.entries(corsHeaders)) {
      response.headers.set(key, value);
  }

  return response;
});