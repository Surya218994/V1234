
import React, { createContext, useState, useContext, ReactNode, useCallback } from 'react';
import { Chat } from '@google/genai';
import { createChat as createChatService } from '../services/geminiService';

interface ChatContextType {
  chat: Chat | null;
  isInitializing: boolean;
  chatError: string | null;
  initializeChat: (systemInstruction?: string, knowledgeBaseText?: string, quality?: 'low' | 'medium' | 'high', initialHistory?: any[]) => Promise<void>;
  endChat: () => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [chat, setChat] = useState<Chat | null>(null);
  const [isInitializing, setIsInitializing] = useState(false);
  const [chatError, setChatError] = useState<string | null>(null);

  const initializeChat = useCallback(async (
      systemInstruction?: string, 
      knowledgeBaseText?: string, 
      quality: 'low' | 'medium' | 'high' = 'medium',
      initialHistory?: any[]
    ) => {
    setIsInitializing(true);
    setChatError(null);
    setChat(null);
    try {
      const newChat = await createChatService(systemInstruction, knowledgeBaseText, quality, initialHistory);
      setChat(newChat);
    } catch (error) {
      console.error("Failed to initialize chat session:", error);
      const message = error instanceof Error ? error.message : "An unknown error occurred.";
      setChatError(message);
      setChat(null);
      throw error; // Re-throw to allow caller to know it failed
    } finally {
      setIsInitializing(false);
    }
  }, []);

  const endChat = useCallback(() => {
    setChat(null);
    setChatError(null);
    setIsInitializing(false);
  }, []);

  return (
    <ChatContext.Provider value={{ chat, isInitializing, chatError, initializeChat, endChat }}>
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = (): ChatContextType => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};