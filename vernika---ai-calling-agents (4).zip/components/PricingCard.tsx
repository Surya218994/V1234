import React from 'react';
import { Check } from './IconComponents';
import { Page } from '../types';

interface PricingCardProps {
    planName: string;
    price: string;
    description: string;
    features: string[];
    isFeatured?: boolean;
    ctaText: string;
    navigateTo: (page: Page) => void;
}

const PricingCard: React.FC<PricingCardProps> = ({ planName, price, description, features, isFeatured = false, ctaText, navigateTo }) => {
    const cardClasses = `relative h-full flex flex-col p-8 rounded-2xl border transition-all duration-300 ${isFeatured ? 'bg-[var(--c-surface)] border-[var(--c-primary)] shadow-lg' : 'bg-[var(--c-surface)] border-[var(--c-border)]'}`;
    const buttonClasses = `w-full mt-8 py-3 px-6 rounded-lg font-semibold transition-colors duration-300 transform hover:scale-105 ${isFeatured ? 'bg-[var(--c-primary)] hover:opacity-90 text-white' : 'bg-[var(--c-text-strong)] hover:opacity-90 text-[var(--c-bg)]'}`;
    
    return (
        <div className={cardClasses}>
            {isFeatured && (
                <div className="absolute top-0 -translate-y-1/2 left-1/2 -translate-x-1/2">
                    <span className="bg-[var(--c-primary)] text-white text-xs font-semibold px-3 py-1 rounded-full uppercase">Most Popular</span>
                </div>
            )}
            <h3 className="text-xl font-semibold text-[var(--c-text-strong)]">{planName}</h3>
            <p className="mt-2 text-[var(--c-text-secondary)] text-sm">{description}</p>
            <div className="mt-6">
                <span className="text-5xl font-bold tracking-tight text-[var(--c-text-strong)]">{price}</span>
                {planName !== 'Enterprise' && <span className="text-base font-medium text-[var(--c-text-secondary)]">/mo</span>}
            </div>
            <ul className="mt-8 space-y-4 text-[var(--c-text-primary)] flex-grow">
                {features.map((feature, index) => (
                    <li key={index} className="flex items-start text-sm">
                        <Check className="w-5 h-5 text-[var(--c-primary)] mr-3 mt-0.5 flex-shrink-0" />
                        <span>{feature}</span>
                    </li>
                ))}
            </ul>
            <button onClick={() => navigateTo('login')} className={buttonClasses}>{ctaText}</button>
        </div>
    );
};

export default PricingCard;