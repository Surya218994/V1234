import React, { useState, useEffect } from 'react';
import { Bot, Spinner } from '../IconComponents';

interface CreatingAgentModalProps {
    onComplete: () => void;
}

const CreatingAgentModal: React.FC<CreatingAgentModalProps> = ({ onComplete }) => {
    const [progress, setProgress] = useState(0);
    const [statusText, setStatusText] = useState('Processing knowledge base...');

    useEffect(() => {
        const timer = setInterval(() => {
            setProgress(oldProgress => {
                if (oldProgress >= 100) {
                    clearInterval(timer);
                    setStatusText('Agent created successfully!');
                    setTimeout(onComplete, 1000);
                    return 100;
                }
                
                const nextProgress = Math.min(oldProgress + Math.random() * 15, 100);
                
                if (nextProgress > 75) {
                    setStatusText('Finalizing configuration...');
                } else if (nextProgress > 40) {
                    setStatusText('Training language models...');
                }

                return nextProgress;
            });
        }, 400);

        return () => {
            clearInterval(timer);
        };
    }, [onComplete]);

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in">
            <div className="bg-[var(--c-surface)] border border-[var(--c-border)] rounded-2xl shadow-xl w-full max-w-md p-8 text-center">
                <div className="w-20 h-20 bg-[var(--c-primary)]/20 rounded-full mx-auto flex items-center justify-center mb-6">
                    <div className="w-16 h-16 bg-[var(--c-primary)] rounded-full flex items-center justify-center">
                        <Bot className="w-8 h-8 text-white animate-pulse" />
                    </div>
                </div>
                <h2 className="text-2xl font-bold text-[var(--c-text-strong)]">Creating Your AI Agent</h2>
                <p className="text-[var(--c-text-secondary)] mt-2">Please wait while we set up your new assistant...</p>

                <div className="w-full bg-[var(--c-bg)] rounded-full h-2.5 mt-8">
                    <div className="bg-[var(--c-primary)] h-2.5 rounded-full" style={{ width: `${progress}%`, transition: 'width 0.5s ease-in-out' }}></div>
                </div>
                <div className="flex justify-between items-center mt-2">
                    <p className="text-sm text-[var(--c-text-secondary)]">{statusText}</p>
                    <p className="text-sm font-semibold text-[var(--c-text-strong)]">{Math.round(progress)}%</p>
                </div>
            </div>
        </div>
    );
};

export default CreatingAgentModal;