

import React, { useState, useEffect, useRef } from 'react';
import { Agent, DropdownOption, AgentConfigurationData } from '../../types';
import { 
  Share, 
  Trash2, 
  Save, 
  Mic, 
  MessageSquarePlus, 
  BookText,
  Import,
  User,
  GitBranch,
  Spinner,
  Check,
  AlertTriangle,
  PhoneForwarded,
  PlayCircle,
  ChevronsUpDown,
  Code,
  Target
} from '../IconComponents';
import Dropdown from '../ui/Dropdown';
import FileUpload from '../ui/FileUpload';
import AgentTestModal from './AgentTestModal';
import { useChat } from '../../contexts/ChatContext';
import { synthesizeSpeech, stopSpeech, getAvailableBrowserVoices } from '../../services/ttsService';
import { EmbedSdkModal } from './EmbedSdkModal';
import { SetOutboundModal } from './SetOutboundModal';
import ImportAgentModal from './ImportAgentModal';

// --- Start of Embedded Modal Component ---
interface ConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  confirmButtonVariant?: 'primary' | 'danger';
}

const ConfirmationModal: React.FC<ConfirmationModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  confirmText = 'Confirm',
  cancelText = 'Cancel',
  confirmButtonVariant = 'primary',
}) => {
  if (!isOpen) return null;

  const confirmButtonClasses = {
    primary: 'bg-[var(--c-primary)] hover:opacity-90 text-white',
    danger: 'bg-[var(--color-danger)] hover:opacity-90 text-white',
  };
  
  const iconWrapperClasses = {
      primary: 'bg-[var(--c-primary)]/10',
      danger: 'bg-red-500/10'
  };

  const iconClasses = {
      primary: 'text-[var(--c-primary)]',
      danger: 'text-red-500'
  }

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-[var(--c-surface)] border border-[var(--c-border)] rounded-2xl shadow-xl w-full max-w-md" role="dialog" aria-modal="true" aria-labelledby="modal-title">
        <div className="p-6">
          <div className="flex items-start gap-4">
            <div className={`mx-auto flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full ${iconWrapperClasses[confirmButtonVariant]} sm:mx-0 sm:h-10 sm:w-10`}>
              <AlertTriangle className={`h-6 w-6 ${iconClasses[confirmButtonVariant]}`} aria-hidden="true" />
            </div>
            <div className="mt-0 text-left flex-grow">
              <h3 className="text-lg font-semibold leading-6 text-[var(--c-text-strong)]" id="modal-title">{title}</h3>
              <div className="mt-2">
                <p className="text-sm text-[var(--c-text-secondary)]">{message}</p>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-[var(--c-bg)] px-6 py-4 flex flex-row-reverse gap-3 rounded-b-2xl">
          <button
            type="button"
            className={`inline-flex w-full justify-center rounded-md px-4 py-2 text-sm font-semibold shadow-sm sm:w-auto transition-colors ${confirmButtonClasses[confirmButtonVariant]}`}
            onClick={onConfirm}
          >
            {confirmText}
          </button>
          <button
            type="button"
            className="inline-flex w-full justify-center rounded-md bg-[var(--c-surface)] px-4 py-2 text-sm font-semibold text-[var(--c-text-primary)] shadow-sm ring-1 ring-inset ring-[var(--c-border)] hover:bg-[var(--c-bg)] sm:w-auto transition-colors"
            onClick={onClose}
          >
            {cancelText}
          </button>
        </div>
      </div>
    </div>
  );
};
// --- End of Embedded Modal Component ---

interface AgentConfigurationProps {
  agent: Agent;
  allAgents: Agent[];
  onSelectAgent: (agent: Agent) => void;
  onUpdateAgent: (agent: Agent) => void;
  onDeleteAgent: (agentId: string) => void;
  handleBackToList: () => void;
  onStartCreateAgent: () => void;
  onSetInbound: () => void;
  onAgentImported: (config: AgentConfigurationData) => void;
}

const defaultAgentConfig: Omit<AgentConfigurationData, 'agentName'> = {
  voice: 'en-US-Studio-O', 
  accent: '',
  quality: 'high',
  systemPrompt: '',
  knowledgeBaseFiles: [],
  conversationStarters: 'Hello, how can I help you today?',
  escalationRules: '',
  prohibitedTopics: '',
};

const standardGoogleVoiceOptions: DropdownOption[] = [
    { value: 'en-US-Standard-C', label: 'US Standard C (Female)' },
    { value: 'en-US-Standard-B', label: 'US Standard B (Male)' },
    { value: 'en-US-Standard-E', label: 'US Standard E (Female)' },
    { value: 'en-US-Standard-D', label: 'US Standard D (Male)' },
    { value: 'en-GB-Standard-A', label: 'British Standard A (Female)' },
    { value: 'en-GB-Standard-B', label: 'British Standard B (Male)' },
    { value: 'en-AU-Standard-A', label: 'Australian Standard A (Female)' },
    { value: 'en-AU-Standard-B', label: 'Australian Standard B (Male)' },
    { value: 'en-IN-Standard-D', label: 'Indian Standard D (Male)' },
    { value: 'en-IN-Standard-A', label: 'Indian Standard A (Female)' },
];

const premiumGoogleVoiceOptions: DropdownOption[] = [
    { value: 'en-US-Studio-O', label: 'US Studio O (Female)' },
    { value: 'en-US-Studio-M', label: 'US Studio M (Male)' },
    { value: 'en-US-Wavenet-A', label: 'US WaveNet A (Male)' },
    { value: 'en-US-Wavenet-C', label: 'US WaveNet C (Female)' },
    { value: 'en-US-Wavenet-F', label: 'US WaveNet F (Female)' },
    { value: 'en-GB-Wavenet-A', label: 'British WaveNet A (Female)' },
    { value: 'en-GB-Wavenet-B', label: 'British WaveNet B (Male)' },
    { value: 'en-GB-Wavenet-F', label: 'British WaveNet F (Female)' },
    { value: 'en-AU-Wavenet-A', label: 'Australian WaveNet A (Female)' },
    { value: 'en-AU-Wavenet-B', label: 'Australian WaveNet B (Male)' },
    { value: 'en-IN-Wavenet-D', label: 'Indian WaveNet D (Male)' },
    { value: 'en-IN-Wavenet-A', label: 'Indian WaveNet A (Female)' },
];

type TestModalConfig = {
  agentName: string;
  agentVoice: string;
  agentAccent: string;
  agentQuality: 'low' | 'medium' | 'high';
  initialGreeting: string;
  initialMode: 'voice' | 'chat';
};

const AgentSelectorDropdown: React.FC<{
    agents: Agent[],
    selectedAgent: Agent,
    onSelect: (agent: Agent) => void,
    onNew: () => void,
    onImport: () => void,
}> = ({ agents, selectedAgent, onSelect, onNew, onImport }) => {
    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);
    
    return (
        <div className="relative w-full lg:hidden mb-6" ref={dropdownRef}>
            <button
                type="button"
                className="flex items-center justify-between w-full bg-[var(--c-surface)] border border-[var(--c-border)] rounded-lg px-4 py-3 text-left"
                onClick={() => setIsOpen(!isOpen)}
            >
                <div>
                    <span className="block text-xs text-[var(--c-text-secondary)]">Current Agent</span>
                    <span className="block font-semibold text-[var(--c-text-strong)]">{selectedAgent.name}</span>
                </div>
                <ChevronsUpDown className="w-5 h-5 text-[var(--c-text-secondary)] ml-2 flex-shrink-0" />
            </button>
            {isOpen && (
                 <div className="absolute z-10 mt-1 w-full bg-[var(--c-surface)] border border-[var(--c-border)] rounded-lg shadow-lg max-h-80 overflow-auto focus:outline-none animate-fade-in-fast p-2"
                 role="listbox">
                     {agents.map(a => (
                         <button key={a.id} onClick={() => { onSelect(a); setIsOpen(false); }} className={`group w-full text-left px-3 py-2.5 rounded-lg transition-all duration-200 flex justify-between items-center ${selectedAgent.id === a.id ? 'bg-[var(--c-primary)]/10' : 'hover:bg-[var(--c-bg)]'}`}>
                             <span className={`font-medium ${selectedAgent.id === a.id ? 'text-[var(--c-primary)]' : 'text-[var(--c-text-strong)]'}`}>{a.name}</span>
                             {selectedAgent.id === a.id && <Check className="w-5 h-5 text-[var(--c-primary)]" />}
                         </button>
                     ))}
                     <div className="border-t border-[var(--c-border)] my-2"></div>
                     <div className="grid grid-cols-2 gap-2">
                        <button onClick={() => { onNew(); setIsOpen(false); }} className="w-full text-center px-3 py-3 rounded-lg flex items-center justify-center gap-2 text-[var(--c-text-primary)] hover:bg-[var(--c-primary)]/5 font-semibold">
                            <MessageSquarePlus className="w-5 h-5" />
                            <span>New</span>
                        </button>
                        <button onClick={() => { onImport(); setIsOpen(false); }} className="w-full text-center px-3 py-3 rounded-lg flex items-center justify-center gap-2 text-[var(--c-text-primary)] hover:bg-[var(--c-primary)]/5 font-semibold">
                            <Import className="w-5 h-5" />
                            <span>Import</span>
                        </button>
                     </div>
                 </div>
            )}
        </div>
    );
};


export const AgentConfiguration: React.FC<AgentConfigurationProps> = ({ agent, allAgents, onSelectAgent, onUpdateAgent, onDeleteAgent, onStartCreateAgent, onSetInbound, onAgentImported }) => {
  const [activeTab, setActiveTab] = useState('persona');
  
  const [agentName, setAgentName] = useState(agent.name);
  const [voice, setVoice] = useState(agent.configuration?.voice || defaultAgentConfig.voice);
  const [accent, setAccent] = useState(agent.configuration?.accent || defaultAgentConfig.accent);
  const [quality, setQuality] = useState<'low' | 'medium' | 'high'>(agent.configuration?.quality || defaultAgentConfig.quality);
  
  const [systemPrompt, setSystemPrompt] = useState(agent.configuration?.systemPrompt || `You are ${agent.name}, a helpful AI assistant.`);
  const [files, setFiles] = useState<File[]>(agent.configuration?.knowledgeBaseFiles || []);
  const [conversationStarters, setConversationStarters] = useState(agent.configuration?.conversationStarters || defaultAgentConfig.conversationStarters);
  const [escalationRules, setEscalationRules] = useState(agent.configuration?.escalationRules || defaultAgentConfig.escalationRules);
  const [prohibitedTopics, setProhibitedTopics] = useState(agent.configuration?.prohibitedTopics || defaultAgentConfig.prohibitedTopics);
  
  const [browserVoiceOptions, setBrowserVoiceOptions] = useState<DropdownOption[]>([]);
  const [areBrowserVoicesLoading, setAreBrowserVoicesLoading] = useState(true);

  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [isTestModalOpen, setIsTestModalOpen] = useState(false);
  const [isSdkModalOpen, setIsSdkModalOpen] = useState(false);
  const [isOutboundModalOpen, setIsOutboundModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [testModalConfig, setTestModalConfig] = useState<TestModalConfig | null>(null);

  const { initializeChat, isInitializing, chatError } = useChat();

  useEffect(() => {
    // When the agent prop changes (user selects a different agent), update the form state
    setAgentName(agent.name);
    setVoice(agent.configuration?.voice || defaultAgentConfig.voice);
    setAccent(agent.configuration?.accent || defaultAgentConfig.accent);
    setQuality(agent.configuration?.quality || defaultAgentConfig.quality);
    setSystemPrompt(agent.configuration?.systemPrompt || `You are ${agent.name}, a helpful AI assistant.`);
    setFiles(agent.configuration?.knowledgeBaseFiles || []);
    setConversationStarters(agent.configuration?.conversationStarters || defaultAgentConfig.conversationStarters);
    setEscalationRules(agent.configuration?.escalationRules || defaultAgentConfig.escalationRules);
    setProhibitedTopics(agent.configuration?.prohibitedTopics || defaultAgentConfig.prohibitedTopics);
  }, [agent]);
  
  useEffect(() => {
    if (quality === 'low') {
        setAreBrowserVoicesLoading(true);
        getAvailableBrowserVoices()
            .then(voices => {
                setBrowserVoiceOptions(voices);
                if (!accent && voices.length > 0) {
                    setAccent(voices[0].value); // Set a default if none is set
                }
            })
            .catch(console.error)
            .finally(() => setAreBrowserVoicesLoading(false));
    }
  }, [quality, accent]);


  const handleSaveChanges = () => {
    setIsSaving(true);
    setSaveSuccess(false);

    const updatedConfig: AgentConfigurationData = {
      agentName,
      voice,
      accent,
      quality,
      systemPrompt,
      knowledgeBaseFiles: files,
      conversationStarters,
      escalationRules,
      prohibitedTopics,
    };

    const updatedAgent: Agent = {
      ...agent,
      name: agentName,
      description: systemPrompt.substring(0, 100) + '...',
      configuration: updatedConfig,
    };
    
    onUpdateAgent(updatedAgent);
    
    setTimeout(() => {
      setIsSaving(false);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2000); // Hide success message after 2s
    }, 1000);
  };
  
  const handleTestClick = async (mode: 'voice' | 'chat') => {
    try {
      const readFilesAsText = (filesToRead: File[]): Promise<string> => {
        return Promise.all(
          filesToRead.map(file => new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => resolve(e.target?.result as string);
            reader.onerror = (e) => reject(new Error(`Failed to read file: ${file.name}`));
            reader.readAsText(file);
          }))
        ).then(contents => contents.join('\n\n'));
      };

      const knowledgeBaseText = await readFilesAsText(files);
      
      const knowledgeBaseInstruction = files.length > 0
        ? `\n\nYour primary instruction is to answer user questions based *only* on the information provided in the CONTEXT given in the conversation history. If the answer is not in the context, you must explicitly say "I do not have that information." Do not make up answers.`
        : "";

      const finalSystemPrompt = systemPrompt + knowledgeBaseInstruction;
      
      const initialHistory = [{
          role: "model",
          parts: [{ text: conversationStarters }]
      }];

      await initializeChat(finalSystemPrompt, knowledgeBaseText, quality, initialHistory);
      
      setTestModalConfig({
        agentName,
        agentVoice: voice,
        agentAccent: accent,
        agentQuality: quality,
        initialGreeting: conversationStarters,
        initialMode: mode,
      });
      setIsTestModalOpen(true);
    } catch (error) {
        console.error("Failed to initialize test session:", error);
    }
  };

  const handlePreviewVoice = async () => {
    stopSpeech();
    const text = 'Hello, this is a preview of my voice.';
    const hindiText = 'नमस्ते, यह मेरी आवाज़ का पूर्वावलोकन है।';

    synthesizeSpeech({
      text,
      quality,
      voice,
      accent,
      handlers: {
        onEnd: () => {
             setTimeout(() => {
                synthesizeSpeech({
                    text: hindiText,
                    quality,
                    voice,
                    accent,
                    handlers: {
                        onEnd: () => console.log('Hindi preview finished.'),
                        onError: (e) => {
                            if (String(e).toLowerCase().includes('interrupted') || String(e).toLowerCase().includes('canceled')) return;
                            alert(`Voice preview failed for Hindi: ${e}`);
                        }
                    }
                });
             }, 500);
        },
        onError: (e) => {
            if (String(e).toLowerCase().includes('interrupted') || String(e).toLowerCase().includes('canceled')) return;
            alert(`Voice preview failed: ${e}`);
        },
      }
    });
  };
  
  const TabButton: React.FC<{id: string; label: string; icon: React.ReactNode;}> = ({ id, label, icon }) => (
    <button
      onClick={() => setActiveTab(id)}
      className={`flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
        activeTab === id ? 'bg-[var(--c-primary)]/10 text-[var(--c-primary)]' : 'text-[var(--c-text-secondary)] hover:bg-[var(--c-bg)] hover:text-[var(--c-text-primary)]'
      }`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );

  const renderVoiceOptions = () => {
      let options: DropdownOption[] = [];
      let label = "";
      let description = "";
      let currentValue = "";
      let valueUpdater: (val: string) => void = () => {};

      switch (quality) {
          case 'low':
              options = browserVoiceOptions;
              label = 'Voice (Browser)';
              description = 'Select a browser-native voice. Actual sound may vary by browser.';
              currentValue = accent;
              valueUpdater = setAccent;
              if (areBrowserVoicesLoading) {
                  return <div><label className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">{label}</label><p className="text-xs text-[var(--c-text-secondary)]">Loading available voices...</p></div>;
              }
              break;
          case 'medium':
              options = standardGoogleVoiceOptions;
              label = 'Voice (Google - Standard)';
              description = 'Good quality, fast response. A good balance for most use cases.';
              currentValue = voice;
              valueUpdater = setVoice;
              break;
          case 'high':
          default:
              options = premiumGoogleVoiceOptions;
              label = 'Voice (Google - Premium)';
              description = 'Highest quality, most natural-sounding voices (Studio & WaveNet).';
              currentValue = voice;
              valueUpdater = setVoice;
              break;
      }
      
      return (
        <div>
            <label className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">{label}</label>
            <p className="text-xs text-[var(--c-text-secondary)] mb-2">{description}</p>
            <div className="flex items-center gap-2">
                <Dropdown options={options} value={currentValue} onChange={valueUpdater} placeholder="Select a voice"/>
                <button onClick={handlePreviewVoice} type="button" className="p-2.5 bg-[var(--c-surface)] border border-[var(--c-border)] rounded-md hover:bg-[var(--c-bg)] transition-colors flex-shrink-0" aria-label="Preview Voice">
                    <PlayCircle className="w-5 h-5 text-[var(--c-text-secondary)]"/>
                </button>
            </div>
        </div>
      );
  }

  const renderContent = () => {
    switch(activeTab) {
      case 'persona':
        return (
          <div className="space-y-6 animate-fade-in">
            <div>
              <label className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Agent Name</label>
              <input type="text" value={agentName} onChange={(e) => setAgentName(e.target.value)} className="w-full bg-[var(--c-surface)] border border-[var(--c-border)] rounded-md px-3 py-2 text-sm text-[var(--c-text-strong)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)]" />
            </div>
            {renderVoiceOptions()}
          </div>
        );
      case 'knowledge':
        return (
          <div className="space-y-8 animate-fade-in">
            <div>
              <label className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">System Prompt</label>
              <p className="text-xs text-[var(--c-text-secondary)] mb-2">This is the core instruction for your agent, defining its personality and primary goal.</p>
              <textarea 
                value={systemPrompt}
                onChange={(e) => setSystemPrompt(e.target.value)}
                rows={6}
                className="w-full bg-[var(--c-surface)] border border-[var(--c-border)] rounded-md px-3 py-2 text-sm text-[var(--c-text-strong)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)] font-mono"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Knowledge Base</label>
              <p className="text-xs text-[var(--c-text-secondary)] mb-2">Upload documents for the agent to use as a source of information to answer user questions.</p>
              <FileUpload files={files} setFiles={setFiles} />
            </div>
          </div>
        );
      case 'behavior':
        return (
          <div className="space-y-8 animate-fade-in">
            <div>
              <label className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Conversation Starters</label>
              <p className="text-xs text-[var(--c-text-secondary)] mb-2">Enter each starter on a new line. The agent will use these to begin conversations.</p>
              <textarea 
                placeholder="Hello, how can I help you today?"
                rows={4}
                value={conversationStarters}
                onChange={(e) => setConversationStarters(e.target.value)}
                className="w-full bg-[var(--c-surface)] border border-[var(--c-border)] rounded-md px-3 py-2 text-sm text-[var(--c-text-strong)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)] font-mono"
              />
            </div>
             <div>
              <label className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Escalation Rules</label>
              <p className="text-xs text-[var(--c-text-secondary)] mb-2">Define when the agent should hand over to a human. e.g., "If the user says they want to file a formal complaint."</p>
              <textarea 
                placeholder="If user is angry, transfer to human."
                rows={4}
                value={escalationRules}
                onChange={(e) => setEscalationRules(e.target.value)}
                className="w-full bg-[var(--c-surface)] border border-[var(--c-border)] rounded-md px-3 py-2 text-sm text-[var(--c-text-strong)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)] font-mono"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Prohibited Topics</label>
              <p className="text-xs text-[var(--c-text-secondary)] mb-2">List topics the agent must avoid, one per line.</p>
              <textarea 
                placeholder="Politics\nReligion\nPersonal opinions"
                rows={4}
                value={prohibitedTopics}
                onChange={(e) => setProhibitedTopics(e.target.value)}
                className="w-full bg-[var(--c-surface)] border border-[var(--c-border)] rounded-md px-3 py-2 text-sm text-[var(--c-text-strong)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)] font-mono"
              />
            </div>
          </div>
        )
      default:
        return null;
    }
  }

  return (
    <>
      <div className="flex flex-col lg:flex-row gap-6">
        <aside className="w-full lg:w-72 flex-shrink-0 hidden lg:block">
          <div className="bg-[var(--c-surface)] border border-[var(--c-border)] rounded-xl p-4">
            <div className="flex justify-between items-center mb-4 px-2">
              <h2 className="font-semibold text-[var(--c-text-strong)]">Your Agents</h2>
              <button 
                onClick={() => setIsImportModalOpen(true)}
                className="flex items-center gap-1.5 text-sm text-[var(--c-primary)] hover:opacity-80 font-semibold"
              >
                <Import className="w-4 h-4"/>
                <span>Import</span>
              </button>
            </div>
            <div className="space-y-1.5">
               <button
                onClick={onStartCreateAgent}
                className="group w-full text-center px-3 py-3 rounded-lg transition-all duration-200 border-2 border-dashed border-[var(--c-border)] hover:border-[var(--c-primary)] hover:bg-[var(--c-primary)]/5"
              >
                <div className="flex items-center justify-center gap-2">
                  <MessageSquarePlus className="w-5 h-5 text-[var(--c-text-secondary)] group-hover:text-[var(--c-primary)] transition-colors" />
                  <span className="font-medium text-[var(--c-text-primary)] group-hover:text-[var(--c-primary)] transition-colors">
                    Add New Agent
                  </span>
                </div>
              </button>
              {allAgents.map(a => (
                <button 
                  key={a.id}
                  onClick={() => onSelectAgent(a)}
                  className={`group w-full text-left px-3 py-2.5 rounded-lg transition-all duration-200 ${
                    agent.id === a.id 
                      ? 'bg-[var(--c-primary)]/10 ring-1 ring-[var(--c-primary)]/50' 
                      : 'hover:bg-[var(--c-bg)]'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className={`font-medium ${agent.id === a.id ? 'text-[var(--c-primary)]' : 'text-[var(--c-text-strong)]'}`}>{a.name}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      agent.id === a.id ? 'bg-[var(--c-bg)] text-[var(--c-text-secondary)]' : 'bg-[var(--c-bg)] text-[var(--c-text-secondary)] group-hover:bg-[var(--c-surface)]'
                    }`}>{a.category}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </aside>

        <main className="flex-grow min-w-0">
          <AgentSelectorDropdown agents={allAgents} selectedAgent={agent} onSelect={onSelectAgent} onNew={onStartCreateAgent} onImport={() => setIsImportModalOpen(true)} />

          <div className="flex flex-col sm:flex-row justify-between sm:items-start mb-6 gap-4">
            <div>
              <h3 className="text-2xl font-bold text-[var(--c-text-strong)]">{agent.name}</h3>
              <p className="text-sm text-[var(--c-text-secondary)] mt-1 max-w-lg">{agent.description}</p>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <button className="p-2.5 rounded-lg bg-[var(--c-surface)] hover:bg-[var(--c-bg)] border border-[var(--c-border)] transition-colors" aria-label="Share Agent">
                <Share className="w-5 h-5 text-[var(--c-text-secondary)]" />
              </button>
              <button 
                onClick={() => setIsDeleteConfirmOpen(true)}
                className="p-2.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 transition-colors" aria-label="Delete Agent">
                <Trash2 className="w-5 h-5 text-red-500" />
              </button>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
              <div className="flex items-center gap-1 sm:gap-2 bg-[var(--c-surface)] border border-[var(--c-border)] p-1 rounded-lg self-start">
                  <TabButton id="persona" label="Persona & Voice" icon={<User className="w-5 h-5"/>} />
                  <TabButton id="knowledge" label="Knowledge Base" icon={<BookText className="w-5 h-5"/>} />
                  <TabButton id="behavior" label="Behavior & Rules" icon={<GitBranch className="w-5 h-5"/>} />
              </div>
              <div className="flex items-center flex-wrap gap-2 self-start">
                <button 
                    onClick={onSetInbound}
                    className="flex items-center gap-2 bg-[var(--c-surface)] border border-[var(--c-border)] text-sm font-semibold px-4 py-2.5 rounded-lg text-[var(--c-text-strong)] hover:bg-[var(--c-bg)] transition-colors">
                  <PhoneForwarded className="w-5 h-5 text-[var(--c-text-secondary)]"/>
                  <span>Set Inbound</span>
                </button>
                <button 
                    onClick={() => setIsOutboundModalOpen(true)}
                    className="flex items-center gap-2 bg-[var(--c-surface)] border border-[var(--c-border)] text-sm font-semibold px-4 py-2.5 rounded-lg text-[var(--c-text-strong)] hover:bg-[var(--c-bg)] transition-colors">
                  <Target className="w-5 h-5 text-[var(--c-text-secondary)]"/>
                  <span>Set Outbound</span>
                </button>
                <button
                    onClick={() => setIsSdkModalOpen(true)}
                    className="flex items-center gap-2 bg-[var(--c-surface)] border border-[var(--c-border)] text-sm font-semibold px-4 py-2.5 rounded-lg text-[var(--c-text-strong)] hover:bg-[var(--c-bg)] transition-colors">
                    <Code className="w-5 h-5 text-[var(--c-text-secondary)]"/>
                    <span>Embed SDK</span>
                </button>
                 <button
                    onClick={handleSaveChanges}
                    className="flex items-center gap-2 bg-[var(--c-primary)] text-white text-sm font-semibold px-4 py-2.5 rounded-lg hover:opacity-90 transition-colors"
                    disabled={isSaving}
                >
                    {isSaving ? <Spinner className="w-5 h-5" /> : saveSuccess ? <Check className="w-5 h-5" /> : <Save className="w-5 h-5" />}
                    <span>{isSaving ? 'Saving...' : saveSuccess ? 'Saved!' : 'Save Changes'}</span>
                </button>
              </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 bg-[var(--c-surface)] border border-[var(--c-border)] rounded-xl p-6 min-h-[400px]">
                  {renderContent()}
              </div>
              <div className="lg:col-span-1 space-y-6">
                <div className="bg-[var(--c-surface)] border border-[var(--c-border)] rounded-xl p-6">
                  <h4 className="font-semibold text-[var(--c-text-strong)] mb-4">Test Your Agent</h4>
                  <div className="space-y-4">
                    <button 
                      onClick={() => handleTestClick('voice')} 
                      disabled={isInitializing}
                      className="w-full flex items-center justify-center gap-2 bg-[var(--c-primary)] text-white font-semibold py-3 px-4 rounded-lg hover:opacity-90 transition-colors disabled:opacity-60"
                    >
                      <Mic className="w-5 h-5"/>
                      <span>{isInitializing ? 'Initializing...' : 'Test with Voice'}</span>
                    </button>
                    <div className="relative text-center">
                      <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-[var(--c-border)]"/></div>
                      <span className="relative bg-[var(--c-surface)] px-2 text-xs text-[var(--c-text-secondary)]">OR</span>
                    </div>
                     <button 
                       onClick={() => handleTestClick('chat')}
                       disabled={isInitializing}
                       className="w-full flex items-center justify-center gap-2 bg-[var(--c-surface)] border border-[var(--c-text-primary)] font-semibold py-3 px-4 rounded-lg hover:bg-[var(--c-bg)] transition-colors disabled:opacity-60"
                     >
                      <MessageSquarePlus className="w-5 h-5"/>
                      <span>{isInitializing ? 'Initializing...' : 'Test with Chat'}</span>
                    </button>
                  </div>
                   <p className="text-xs text-[var(--c-text-secondary)] text-center mt-4">Test your agent's text responses in a simulated chat environment.</p>
                   {chatError && <p className="text-xs text-red-500 mt-2 text-center">Initialization failed: {chatError}</p>}
                </div>

                <div className="bg-[var(--c-surface)] border border-[var(--c-border)] rounded-xl p-6">
                    <h4 className="font-semibold text-[var(--c-text-strong)] mb-4">Response Quality</h4>
                    <div className="flex gap-1 p-1 bg-[var(--c-bg)] rounded-lg border border-[var(--c-border)]">
                      <button onClick={() => setQuality('low')} className={`w-full text-center py-1.5 px-2 rounded-md transition-colors text-sm font-semibold ${quality === 'low' ? 'bg-[var(--c-surface)] text-[var(--c-text-strong)] shadow-sm' : 'text-[var(--c-text-secondary)] hover:bg-[var(--c-surface)]/50'}`}>Fast</button>
                      <button onClick={() => setQuality('medium')} className={`w-full text-center py-1.5 px-2 rounded-md transition-colors text-sm font-semibold ${quality === 'medium' ? 'bg-[var(--c-surface)] text-[var(--c-text-strong)] shadow-sm' : 'text-[var(--c-text-secondary)] hover:bg-[var(--c-surface)]/50'}`}>Balanced</button>
                      <button onClick={() => setQuality('high')} className={`w-full text-center py-1.5 px-2 rounded-md transition-colors text-sm font-semibold ${quality === 'high' ? 'bg-[var(--c-surface)] text-[var(--c-text-strong)] shadow-sm' : 'text-[var(--c-text-secondary)] hover:bg-[var(--c-surface)]/50'}`}>Quality</button>
                    </div>
                </div>
              </div>
          </div>
        </main>
      </div>

      <ConfirmationModal
        isOpen={isDeleteConfirmOpen}
        onClose={() => setIsDeleteConfirmOpen(false)}
        onConfirm={() => {
          onDeleteAgent(agent.id);
          setIsDeleteConfirmOpen(false);
        }}
        title="Delete Agent"
        message={`Are you sure you want to delete the agent "${agent.name}"? This action cannot be undone.`}
        confirmButtonVariant="danger"
        confirmText="Delete"
      />
      {isTestModalOpen && testModalConfig && (
        <AgentTestModal onClose={() => setIsTestModalOpen(false)} config={testModalConfig} />
      )}
      {isSdkModalOpen && (
        <EmbedSdkModal agentId={agent.id} onClose={() => setIsSdkModalOpen(false)} />
      )}
      {isOutboundModalOpen && (
        <SetOutboundModal agentId={agent.id} onClose={() => setIsOutboundModalOpen(false)} />
      )}
      {isImportModalOpen && (
        <ImportAgentModal
          onClose={() => setIsImportModalOpen(false)}
          onAgentImported={onAgentImported}
        />
      )}
    </>
  );
};
