
import React from 'react';
import { PhoneMockup } from '../PhoneMockup';
import { useChat } from '../../contexts/ChatContext';

interface AgentTestModalProps {
  onClose: () => void;
  config: {
    agentName: string;
    agentVoice: string;
    agentAccent: string;
    agentQuality: 'low' | 'medium' | 'high';
    initialGreeting: string;
    initialMode: 'voice' | 'chat';
  };
}

const AgentTestModal: React.FC<AgentTestModalProps> = ({ onClose, config }) => {
  const { endChat } = useChat();

  const handleClose = () => {
    endChat();
    onClose();
  };

  // Prevent clicks inside the modal from closing it
  const handleModalContentClick = (e: React.MouseEvent) => {
    e.stopPropagation();
  };
  
  return (
    <div 
      className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={handleClose}
    >
      <div 
        className="relative w-full max-w-md"
        onClick={handleModalContentClick}
      >
        <button
          onClick={handleClose}
          className="absolute -top-2 -right-2 w-9 h-9 bg-white rounded-full text-slate-900 flex items-center justify-center font-bold text-xl z-10 hover:bg-gray-200 transition-colors"
          aria-label="Close test"
        >
          &times;
        </button>
        <div className="transform scale-90 md:scale-100">
             <PhoneMockup 
                key={config.agentName}
                initialGreeting={config.initialGreeting}
                defaultInteractionMode={config.initialMode}
                agentVoice={config.agentVoice}
                agentAccent={config.agentAccent}
                agentQuality={config.agentQuality}
             />
        </div>
      </div>
    </div>
  );
};

export default AgentTestModal;