
import React from 'react';
import { AgentConfigurationData } from '../../types';
import { ChevronLeft, ChevronRight } from '../IconComponents';
import FileUpload from '../ui/FileUpload';

interface Step2Props {
  data: AgentConfigurationData;
  onUpdate: (data: Partial<AgentConfigurationData>) => void;
  onNext: () => void;
  onPrev: () => void;
}

const Step2AgentKnowledge: React.FC<Step2Props> = ({ data, onUpdate, onNext, onPrev }) => {
  return (
    <div className="flex flex-col h-full">
      <div className="space-y-8 flex-grow">
        <div>
          <label htmlFor="systemPrompt" className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Agent's Core Instructions (System Prompt)</label>
          <p className="text-xs text-[var(--c-text-secondary)] mt-1 mb-2">This is the most important step. Define your agent's personality, purpose, and rules here. Be as descriptive as possible.</p>
          <textarea
            id="systemPrompt"
            rows={8}
            value={data.systemPrompt}
            onChange={(e) => onUpdate({ systemPrompt: e.target.value })}
            placeholder={`e.g., "You are a friendly and helpful assistant for Acme Corp. Your primary goal is to answer user questions based *only* on the documents provided in your knowledge base. If the answer is not in the documents, say 'I do not have that information.' Do not make up answers."`}
            className="w-full bg-[var(--c-bg)] border border-[var(--c-border)] rounded-lg px-4 py-2.5 text-[var(--c-text-strong)] placeholder:text-[var(--c-text-secondary)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)] font-mono text-sm"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Knowledge Base</label>
          <p className="text-xs text-[var(--c-text-secondary)] mt-1 mb-2">Upload documents (PDF, TXT, DOCX) for your agent to learn from. The agent will use this information to answer user questions.</p>
          <FileUpload
            files={data.knowledgeBaseFiles}
            setFiles={(files) => onUpdate({ knowledgeBaseFiles: files })}
          />
        </div>
      </div>
      <div className="mt-8 pt-6 border-t border-[var(--c-border)] flex justify-between">
        <button
          onClick={onPrev}
          className="bg-[var(--c-surface)] text-[var(--c-text-strong)] border border-[var(--c-border)] font-semibold py-2.5 px-6 rounded-lg hover:bg-[var(--c-bg)] transition-colors flex items-center gap-2"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Previous</span>
        </button>
        <button
          onClick={onNext}
          disabled={!data.systemPrompt}
          className="bg-[var(--c-primary)] text-white font-semibold py-2.5 px-6 rounded-lg hover:opacity-90 transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <span>Next</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

export default Step2AgentKnowledge;
