

import React, { useState } from 'react';
import { AgentConfigurationData } from '../../types';
import Stepper from '../ui/Stepper';
import { Step1AgentInfo } from './Step1AgentInfo';
import Step2AgentKnowledge from './Step2AgentKnowledge';
import Step3AgentRules from './Step3AgentRules';
import CreatingAgentModal from './CreatingAgentModal';
import { X } from '../IconComponents';

interface CreateAgentWizardProps {
  onClose: () => void;
  onAgentCreated: (config: AgentConfigurationData) => void;
}

const steps = [
  { title: 'Persona & Voice', description: 'Define agent identity' },
  { title: 'Knowledge Base', description: 'Provide information' },
  { title: 'Behavior & Rules', description: 'Set guardrails' },
];

const CreateAgentWizard: React.FC<CreateAgentWizardProps> = ({ onClose, onAgentCreated }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isCreating, setIsCreating] = useState(false);
  const [data, setData] = useState<AgentConfigurationData>({
    agentName: '',
    voice: 'en-US-Standard-C',
    accent: '',
    quality: 'medium',
    systemPrompt: '',
    knowledgeBaseFiles: [],
    conversationStarters: '',
    escalationRules: '',
    prohibitedTopics: '',
  });

  const updateData = (update: Partial<AgentConfigurationData>) => {
    setData(prev => ({ ...prev, ...update }));
  };

  const handleNext = () => setCurrentStep(prev => Math.min(prev + 1, steps.length));
  const handlePrev = () => setCurrentStep(prev => Math.max(prev - 1, 1));
  
  const handleCreate = () => {
    console.log('Final agent configuration:', data);
    setIsCreating(true);
  };

  const handleCreationComplete = () => {
    setIsCreating(false);
    onAgentCreated(data);
    onClose();
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return <Step1AgentInfo data={data} onUpdate={updateData} onNext={handleNext} />;
      case 2:
        return <Step2AgentKnowledge data={data} onUpdate={updateData} onNext={handleNext} onPrev={handlePrev} />;
      case 3:
        return <Step3AgentRules data={data} onUpdate={updateData} onPrev={handlePrev} onCreate={handleCreate} />;
      default:
        return null;
    }
  };

  if (isCreating) {
    return <CreatingAgentModal onComplete={handleCreationComplete} />;
  }

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-0 md:p-4 animate-fade-in">
      <div className="bg-[var(--c-surface)] border-0 md:border md:border-[var(--c-border)] md:rounded-2xl shadow-xl w-full h-full md:max-w-4xl md:h-[90vh] flex flex-col">
        <header className="flex items-center justify-between p-4 md:p-6 border-b border-[var(--c-border)] flex-shrink-0">
          <div>
            <h2 className="text-lg md:text-xl font-bold text-[var(--c-text-strong)]">Create a New Agent</h2>
            <p className="text-sm text-[var(--c-text-secondary)]">Follow the steps to build and configure your AI voice agent.</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-[var(--c-bg)]">
            <X className="w-6 h-6 text-[var(--c-text-secondary)]" />
          </button>
        </header>

        <div className="p-4 md:p-8 flex-shrink-0">
          <Stepper currentStep={currentStep} steps={steps} />
        </div>

        <main className="flex-grow p-4 md:p-8 pt-0 overflow-y-auto">
          {renderStep()}
        </main>
      </div>
    </div>
  );
};

export default CreateAgentWizard;