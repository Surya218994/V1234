

import React, { useState, useEffect } from 'react';
import { AgentConfigurationData, DropdownOption } from '../../types';
import Dropdown from '../ui/Dropdown';
import { PlayCircle, ChevronRight } from '../IconComponents';
import { synthesizeSpeech, stopSpeech, getAvailableBrowserVoices } from '../../services/ttsService';

interface Step1Props {
  data: AgentConfigurationData;
  onUpdate: (data: Partial<AgentConfigurationData>) => void;
  onNext: () => void;
}

const standardGoogleVoiceOptions: DropdownOption[] = [
    { value: 'en-US-Standard-C', label: 'US Standard C (Female)' },
    { value: 'en-US-Standard-B', label: 'US Standard B (Male)' },
    { value: 'en-US-Standard-E', label: 'US Standard E (Female)' },
    { value: 'en-US-Standard-D', label: 'US Standard D (Male)' },
    { value: 'en-GB-Standard-A', label: 'British Standard A (Female)' },
    { value: 'en-GB-Standard-B', label: 'British Standard B (Male)' },
    { value: 'en-AU-Standard-A', label: 'Australian Standard A (Female)' },
    { value: 'en-AU-Standard-B', label: 'Australian Standard B (Male)' },
    { value: 'en-IN-Standard-D', label: 'Indian Standard D (Male)' },
    { value: 'en-IN-Standard-A', label: 'Indian Standard A (Female)' },
];

const premiumGoogleVoiceOptions: DropdownOption[] = [
    { value: 'en-US-Studio-O', label: 'US Studio O (Female)' },
    { value: 'en-US-Studio-M', label: 'US Studio M (Male)' },
    { value: 'en-US-Wavenet-A', label: 'US WaveNet A (Male)' },
    { value: 'en-US-Wavenet-C', label: 'US WaveNet C (Female)' },
    { value: 'en-US-Wavenet-F', label: 'US WaveNet F (Female)' },
    { value: 'en-GB-Wavenet-A', label: 'British WaveNet A (Female)' },
    { value: 'en-GB-Wavenet-B', label: 'British WaveNet B (Male)' },
    { value: 'en-GB-Wavenet-F', label: 'British WaveNet F (Female)' },
    { value: 'en-AU-Wavenet-A', label: 'Australian WaveNet A (Female)' },
    { value: 'en-AU-Wavenet-B', label: 'Australian WaveNet B (Male)' },
    { value: 'en-IN-Wavenet-D', label: 'Indian WaveNet D (Male)' },
    { value: 'en-IN-Wavenet-A', label: 'Indian WaveNet A (Female)' },
];

export const Step1AgentInfo: React.FC<Step1Props> = ({ data, onUpdate, onNext }) => {
    const [browserVoiceOptions, setBrowserVoiceOptions] = useState<DropdownOption[]>([]);
    const [areBrowserVoicesLoading, setAreBrowserVoicesLoading] = useState(false);

    useEffect(() => {
        if (data.quality === 'low') {
            setAreBrowserVoicesLoading(true);
            getAvailableBrowserVoices()
                .then(voices => {
                    setBrowserVoiceOptions(voices);
                    if (!data.accent && voices.length > 0) {
                        onUpdate({ accent: voices[0].value });
                    }
                })
                .catch(console.error)
                .finally(() => setAreBrowserVoicesLoading(false));
        }
    }, [data.quality, data.accent, onUpdate]);

    const handlePreviewVoice = async () => {
        stopSpeech();
        const text = 'Hello, this is a preview of my voice.';

        synthesizeSpeech({
            text,
            quality: data.quality,
            voice: data.voice,
            accent: data.accent,
            handlers: {
                onEnd: () => console.log('Preview finished.'),
                onError: (e) => {
                    if (String(e).toLowerCase().includes('interrupted') || String(e).toLowerCase().includes('canceled')) return;
                    alert(`Failed to preview voice: ${e}`);
                }
            }
        });
    }
    
    const renderVoiceOptions = () => {
      let options: DropdownOption[] = [];
      let label = "";
      let description = "";
      let currentValue = "";
      let valueUpdater: (val: string) => void = () => {};

      switch (data.quality) {
          case 'low':
              options = browserVoiceOptions;
              label = 'Voice (Browser)';
              description = 'Select a browser-native voice. Actual sound may vary by browser.';
              currentValue = data.accent;
              valueUpdater = (accent) => onUpdate({ accent });
              if (areBrowserVoicesLoading) {
                  return <div><label className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">{label}</label><p className="text-xs text-[var(--c-text-secondary)]">Loading available voices...</p></div>;
              }
              break;
          case 'medium':
              options = standardGoogleVoiceOptions;
              label = 'Voice (Google - Standard)';
              description = 'Good quality, fast response. A good balance for most use cases.';
              currentValue = data.voice;
              valueUpdater = (voice) => onUpdate({ voice });
              break;
          case 'high':
          default:
              options = premiumGoogleVoiceOptions;
              label = 'Voice (Google - Premium)';
              description = 'Highest quality, most natural-sounding voices (Studio & WaveNet).';
              currentValue = data.voice;
              valueUpdater = (voice) => onUpdate({ voice });
              break;
      }
      
      return (
        <div>
            <label className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">{label}</label>
            <p className="text-xs text-[var(--c-text-secondary)] mt-1 mb-2">{description}</p>
            <div className="flex items-center gap-2">
                <Dropdown options={options} value={currentValue} onChange={valueUpdater} placeholder="Select a voice"/>
                <button onClick={handlePreviewVoice} type="button" className="p-3 bg-[var(--c-surface)] border border-[var(--c-border)] rounded-lg hover:bg-[var(--c-bg)] transition-colors flex-shrink-0">
                    <PlayCircle className="w-5 h-5 text-[var(--c-text-secondary)]"/>
                </button>
            </div>
        </div>
      );
    }

    return (
        <div className="flex flex-col h-full">
            <div className="space-y-6 flex-grow">
                <div>
                    <label htmlFor="agentName" className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Agent Name</label>
                    <input
                        type="text"
                        id="agentName"
                        value={data.agentName}
                        onChange={(e) => onUpdate({ agentName: e.target.value })}
                        placeholder="e.g., SupportBot, Sales Assistant"
                        className="w-full bg-[var(--c-bg)] border border-[var(--c-border)] rounded-lg px-4 py-2.5 text-[var(--c-text-strong)] placeholder:text-[var(--c-text-secondary)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)]"
                    />
                    <p className="text-xs text-[var(--c-text-secondary)] mt-2">Give your agent a unique name.</p>
                </div>
                 <div>
                    <label className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Response Quality</label>
                    <div className="flex gap-1 p-1 bg-[var(--c-bg)] rounded-lg border border-[var(--c-border)]">
                      <button type="button" onClick={() => onUpdate({ quality: 'low' })} className={`w-full text-center py-1.5 px-2 rounded-md transition-colors text-sm font-semibold ${data.quality === 'low' ? 'bg-[var(--c-surface)] text-[var(--c-text-strong)] shadow-sm' : 'text-[var(--c-text-secondary)] hover:bg-[var(--c-surface)]/50'}`}>Fast</button>
                      <button type="button" onClick={() => onUpdate({ quality: 'medium' })} className={`w-full text-center py-1.5 px-2 rounded-md transition-colors text-sm font-semibold ${data.quality === 'medium' ? 'bg-[var(--c-surface)] text-[var(--c-text-strong)] shadow-sm' : 'text-[var(--c-text-secondary)] hover:bg-[var(--c-surface)]/50'}`}>Balanced</button>
                      <button type="button" onClick={() => onUpdate({ quality: 'high' })} className={`w-full text-center py-1.5 px-2 rounded-md transition-colors text-sm font-semibold ${data.quality === 'high' ? 'bg-[var(--c-surface)] text-[var(--c-text-strong)] shadow-sm' : 'text-[var(--c-text-secondary)] hover:bg-[var(--c-surface)]/50'}`}>Quality</button>
                    </div>
                </div>

                {renderVoiceOptions()}
            </div>
            <div className="mt-8 pt-6 border-t border-[var(--c-border)] flex justify-end">
                <button
                    onClick={onNext}
                    disabled={!data.agentName}
                    className="bg-[var(--c-primary)] text-white font-semibold py-2.5 px-6 rounded-lg hover:opacity-90 transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    <span>Next</span>
                    <ChevronRight className="w-4 h-4"/>
                </button>
            </div>
        </div>
    );
};