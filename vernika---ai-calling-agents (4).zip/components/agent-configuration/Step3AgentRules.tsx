import React from 'react';
import { AgentConfigurationData } from '../../types';
import { ChevronLeft } from '../IconComponents';

interface Step3Props {
  data: AgentConfigurationData;
  onUpdate: (data: Partial<AgentConfigurationData>) => void;
  onPrev: () => void;
  onCreate: () => void;
}

const Step3AgentRules: React.FC<Step3Props> = ({ data, onUpdate, onPrev, onCreate }) => {
  return (
    <div className="flex flex-col h-full">
      <div className="space-y-8 flex-grow">
        <div>
          <label htmlFor="conversationStarters" className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Conversation Starters</label>
           <p className="text-xs text-[var(--c-text-secondary)] mt-1 mb-2">How should the agent start the conversation? Enter one starter per line.</p>
          <textarea
              id="conversationStarters"
              rows={3}
              value={data.conversationStarters}
              onChange={(e) => onUpdate({ conversationStarters: e.target.value })}
              placeholder="Hi there, how can I assist you today?"
              className="w-full bg-[var(--c-bg)] border border-[var(--c-border)] rounded-lg px-4 py-2.5 text-[var(--c-text-strong)] placeholder:text-[var(--c-text-secondary)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)] font-mono text-sm"
          />
        </div>
        <div>
          <label htmlFor="escalationRules" className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Escalation Rules</label>
           <p className="text-xs text-[var(--c-text-secondary)] mt-1 mb-2">Define triggers for when the agent should hand off the conversation to a human.</p>
          <textarea
              id="escalationRules"
              rows={3}
              value={data.escalationRules}
              onChange={(e) => onUpdate({ escalationRules: e.target.value })}
              placeholder="If the user asks to speak to a manager, or mentions a legal issue, transfer the call."
              className="w-full bg-[var(--c-bg)] border border-[var(--c-border)] rounded-lg px-4 py-2.5 text-[var(--c-text-strong)] placeholder:text-[var(--c-text-secondary)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)] font-mono text-sm"
          />
        </div>
        <div>
          <label htmlFor="prohibitedTopics" className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Prohibited Topics</label>
           <p className="text-xs text-[var(--c-text-secondary)] mt-1 mb-2">Define topics the agent must refuse to discuss.</p>
          <textarea
              id="prohibitedTopics"
              rows={3}
              value={data.prohibitedTopics}
              onChange={(e) => onUpdate({ prohibitedTopics: e.target.value })}
              placeholder="Do not discuss personal opinions, politics, or give medical or financial advice."
              className="w-full bg-[var(--c-bg)] border border-[var(--c-border)] rounded-lg px-4 py-2.5 text-[var(--c-text-strong)] placeholder:text-[var(--c-text-secondary)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)] font-mono text-sm"
          />
        </div>
      </div>
      <div className="mt-8 pt-6 border-t border-[var(--c-border)] flex justify-between">
        <button
            onClick={onPrev}
            className="bg-[var(--c-surface)] text-[var(--c-text-strong)] border border-[var(--c-border)] font-semibold py-2.5 px-6 rounded-lg hover:bg-[var(--c-bg)] transition-colors flex items-center gap-2"
        >
            <ChevronLeft className="w-4 h-4"/>
            <span>Previous</span>
        </button>
        <button
            onClick={onCreate}
            className="bg-green-600 text-white font-semibold py-2.5 px-6 rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
        >
            <span>Create Agent</span>
        </button>
      </div>
    </div>
  );
};

export default Step3AgentRules;