
import React, { useState } from 'react';
import { X, Check, Spinner, Target } from '../IconComponents';
import FileUpload from '../ui/FileUpload';

interface SetOutboundModalProps {
  agentId: string;
  onClose: () => void;
}

export const SetOutboundModal: React.FC<SetOutboundModalProps> = ({ agentId, onClose }) => {
  const [files, setFiles] = useState<File[]>([]);
  const [isStarting, setIsStarting] = useState(false);
  const [isStarted, setIsStarted] = useState(false);

  const handleStartCampaign = async () => {
    if (files.length === 0) {
      alert("Please upload a contact list first.");
      return;
    }
    setIsStarting(true);
    await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate API call
    setIsStarting(false);
    setIsStarted(true);
    // In a real app, you would start the campaign here.
    console.log(`Starting campaign for agent ${agentId} with ${files.length} contacts.`);
    setTimeout(() => {
        onClose();
    }, 1500); // Close modal after showing success message
  };

  return (
    <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in"
        onClick={onClose}
    >
      <div 
        className="bg-[var(--c-surface)] border border-[var(--c-border)] rounded-2xl shadow-xl w-full max-w-lg flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
        role="dialog" 
        aria-modal="true" 
        aria-labelledby="outbound-modal-title"
      >
        <header className="flex items-center justify-between p-6 border-b border-[var(--c-border)] flex-shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 flex items-center justify-center rounded-lg bg-[var(--c-primary)]/10">
                <Target className="w-6 h-6 text-[var(--c-primary)]" />
              </div>
              <div>
                <h2 id="outbound-modal-title" className="text-lg font-semibold text-[var(--c-text-strong)]">
                    Set Outbound Campaign
                </h2>
                <p className="text-sm text-[var(--c-text-secondary)]">Upload a contact list to start calling.</p>
              </div>
            </div>
            <button onClick={onClose} className="p-2 rounded-full hover:bg-[var(--c-bg)]">
                <X className="w-5 h-5 text-[var(--c-text-secondary)]" />
            </button>
        </header>

        <main className="flex-grow p-6 overflow-y-auto space-y-6">
            <div>
                <h3 className="font-semibold text-[var(--c-text-strong)] mb-2">Step 1: Upload Your Contact List</h3>
                <p className="text-sm text-[var(--c-text-secondary)] mb-4">
                    Upload a CSV file containing the phone numbers and any other relevant information for your agent to call.
                </p>
                <FileUpload files={files} setFiles={setFiles} />
            </div>
            <div>
                <h3 className="font-semibold text-[var(--c-text-strong)] mb-2">Step 2: Launch the Campaign</h3>
                <p className="text-sm text-[var(--c-text-secondary)] mb-4">
                    Once your list is uploaded, your agent is ready to start calling.
                </p>
            </div>
        </main>

        <footer className="p-4 border-t border-[var(--c-border)] flex-shrink-0 flex justify-end gap-3">
             <button
                type="button"
                className="inline-flex justify-center rounded-md bg-[var(--c-surface)] px-4 py-2.5 text-sm font-semibold text-[var(--c-text-primary)] shadow-sm ring-1 ring-inset ring-[var(--c-border)] hover:bg-[var(--c-bg)] transition-colors"
                onClick={onClose}
            >
                Cancel
            </button>
            <button
                type="button"
                className="inline-flex justify-center items-center gap-2 rounded-md bg-green-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-green-700 transition-colors disabled:opacity-60"
                onClick={handleStartCampaign}
                disabled={files.length === 0 || isStarting || isStarted}
            >
                {isStarting && <Spinner className="w-5 h-5"/>}
                {isStarted && <Check className="w-5 h-5"/>}
                <span>{isStarting ? 'Starting...' : isStarted ? 'Campaign Started!' : 'Start Calling'}</span>
            </button>
        </footer>
      </div>
    </div>
  );
};
