
import React, { useState } from 'react';
import { X, Copy, Check, Code, Phone, FileText } from '../IconComponents';

interface EmbedSdkModalProps {
  agentId: string;
  onClose: () => void;
}

const CodeBlock: React.FC<{ code: string }> = ({ code }) => {
    const [copied, setCopied] = useState(false);
    const handleCopy = () => {
        navigator.clipboard.writeText(code).then(() => {
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        }).catch(err => {
            console.error('Failed to copy text: ', err);
            alert('Failed to copy text.');
        });
    };
    return (
        <div className="relative bg-[#282c34] p-4 rounded-lg border border-gray-700 font-mono text-sm text-gray-300 overflow-x-auto">
            <pre>
                <code>{code}</code>
            </pre>
            <button
                onClick={handleCopy}
                className="absolute top-3 right-3 p-2 rounded-md bg-gray-600/50 hover:bg-gray-500/50 transition-colors text-gray-300"
                aria-label={copied ? "Copied!" : "Copy code"}
            >
                {copied ? <Check className="w-5 h-5 text-green-400" /> : <Copy className="w-5 h-5" />}
            </button>
        </div>
    );
};


export const EmbedSdkModal: React.FC<EmbedSdkModalProps> = ({ agentId, onClose }) => {
  const [activeTab, setActiveTab] = useState<'chat' | 'call'>('chat');

  const chatScript = `<script src="https://cdn.vernika.ai/sdk.js" data-agent-id="${agentId}" defer></script>`;
  
  const callButtonCSS = `
.vernika-call-button {
  position: fixed;
  bottom: 20px;
  right: 20px;
  width: 60px;
  height: 60px;
  background-color: #2563EB; /* Your brand color */
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);
  cursor: pointer;
  z-index: 1000;
  transition: transform 0.2s ease;
}
.vernika-call-button:hover {
  transform: scale(1.1);
}
.vernika-call-button svg {
  color: white;
  width: 28px;
  height: 28px;
}`;
  
  const callButtonHTML = `
<div id="vernika-call-btn" class="vernika-call-button">
  <!-- Phone Icon SVG -->
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
  </svg>
</div>`;

  const callButtonJS = `
document.addEventListener('DOMContentLoaded', () => {
  const callButton = document.getElementById('vernika-call-btn');
  const agentId = "${agentId}";

  if (callButton) {
    callButton.addEventListener('click', () => {
      // TODO: Add your call initiation logic here.
      // This could trigger a Twilio Device call, for example.
      console.log(\`Starting call with agent: \${agentId}\`);
      alert(\`Calling agent: \${agentId}\`);
    });
  }
});`;

  const TabButton: React.FC<{
    id: 'chat' | 'call';
    label: string;
    icon: React.ReactNode;
  }> = ({ id, label, icon }) => (
    <button
      onClick={() => setActiveTab(id)}
      className={`w-full flex items-center justify-center gap-2 px-3 py-2.5 text-sm font-semibold rounded-lg transition-colors ${
        activeTab === id ? 'bg-[var(--c-surface)] text-[var(--c-primary)] shadow-sm' : 'text-[var(--c-text-secondary)] hover:bg-[var(--c-surface)]/50'
      }`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );

  return (
    <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in"
        onClick={onClose}
    >
      <div 
        className="bg-[var(--c-surface)] border border-[var(--c-border)] rounded-2xl shadow-xl w-full max-w-2xl flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
        role="dialog" 
        aria-modal="true" 
        aria-labelledby="sdk-modal-title"
      >
        <header className="flex items-center justify-between p-6 border-b border-[var(--c-border)] flex-shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 flex items-center justify-center rounded-lg bg-[var(--c-primary)]/10">
                <Code className="w-6 h-6 text-[var(--c-primary)]" />
              </div>
              <div>
                <h2 id="sdk-modal-title" className="text-lg font-semibold text-[var(--c-text-strong)]">
                    Embed Your Agent
                </h2>
                <p className="text-sm text-[var(--c-text-secondary)]">Add a widget to your website in seconds.</p>
              </div>
            </div>
            <button onClick={onClose} className="p-2 rounded-full hover:bg-[var(--c-bg)]">
                <X className="w-5 h-5 text-[var(--c-text-secondary)]" />
            </button>
        </header>

        <main className="flex-grow p-6 overflow-y-auto space-y-6">
            <div className="flex gap-2 p-1 bg-[var(--c-bg)] rounded-lg border border-[var(--c-border)]">
              <TabButton id="chat" label="Chat Widget" icon={<FileText className="w-5 h-5" />} />
              <TabButton id="call" label="Call Button" icon={<Phone className="w-5 h-5" />} />
            </div>

            {activeTab === 'chat' && (
              <div className="space-y-6 animate-fade-in">
                  <div>
                    <h3 className="font-semibold text-[var(--c-text-strong)] mb-2">Step 1: Copy the Code Snippet</h3>
                    <p className="text-sm text-[var(--c-text-secondary)] mb-4">
                      This snippet adds a chat widget to the bottom-right of your page.
                    </p>
                    <CodeBlock code={chatScript} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-[var(--c-text-strong)] mb-2">Step 2: Paste in Your HTML</h3>
                    <div className="flex items-start gap-4 p-4 rounded-lg bg-[var(--c-bg)] border border-[var(--c-border)]">
                      <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center rounded-lg bg-[var(--c-surface)] border border-[var(--c-border)]">
                        <FileText className="w-5 h-5 text-[var(--c-text-secondary)]" />
                      </div>
                      <div>
                        <p className="text-sm text-[var(--c-text-strong)] font-medium">
                          Paste the snippet just before the closing <code>&lt;/body&gt;</code> tag of your website's HTML file.
                        </p>
                      </div>
                    </div>
                  </div>
              </div>
            )}
            
            {activeTab === 'call' && (
              <div className="space-y-6 animate-fade-in">
                <div>
                  <h3 className="font-semibold text-[var(--c-text-strong)] mb-2">Step 1: Add the CSS Style</h3>
                  <p className="text-sm text-[var(--c-text-secondary)] mb-4">Add this CSS to your website's stylesheet to style the call button.</p>
                  <CodeBlock code={callButtonCSS} />
                </div>
                 <div>
                  <h3 className="font-semibold text-[var(--c-text-strong)] mb-2">Step 2: Add the HTML Element</h3>
                   <p className="text-sm text-[var(--c-text-secondary)] mb-4">Paste this HTML snippet just before your closing <code>&lt;/body&gt;</code> tag.</p>
                  <CodeBlock code={callButtonHTML} />
                </div>
                 <div>
                  <h3 className="font-semibold text-[var(--c-text-strong)] mb-2">Step 3: Add the JavaScript Logic</h3>
                   <p className="text-sm text-[var(--c-text-secondary)] mb-4">Add this script to your site to handle the button click. You'll need to add your own call logic (e.g., using Twilio).</p>
                  <CodeBlock code={callButtonJS} />
                </div>
              </div>
            )}
        </main>

        <footer className="p-4 border-t border-[var(--c-border)] flex-shrink-0 text-right">
             <button
                type="button"
                className="inline-flex justify-center rounded-md bg-[var(--c-primary)] px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:opacity-90 transition-colors"
                onClick={onClose}
            >
                Done
            </button>
        </footer>
      </div>
    </div>
  );
};
