
import React, { useState } from 'react';
import { X, ExternalLink, Sparkles } from '../IconComponents';
import { AgentConfigurationData } from '../../types';

interface ImportAgentModalProps {
  onClose: () => void;
  onAgentImported: (config: AgentConfigurationData) => void;
}

const ImportAgentModal: React.FC<ImportAgentModalProps> = ({ onClose, onAgentImported }) => {
    const [agentName, setAgentName] = useState('');
    const [systemPrompt, setSystemPrompt] = useState('');
    const [greeting, setGreeting] = useState('');

    const handleImport = () => {
        if (!agentName || !systemPrompt) {
            alert('Agent Name and System Prompt are required.');
            return;
        }

        const newConfig: AgentConfigurationData = {
            agentName,
            systemPrompt,
            conversationStarters: greeting || `Hello, I'm ${agentName}. How can I assist you?`,
            // Use default values for other fields for a quick import
            voice: 'en-US-Studio-O',
            accent: '',
            quality: 'high',
            knowledgeBaseFiles: [],
            escalationRules: '',
            prohibitedTopics: '',
        };

        onAgentImported(newConfig);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
            <div className="bg-[var(--c-surface)] border border-[var(--c-border)] rounded-2xl shadow-xl w-full max-w-2xl flex flex-col max-h-[90vh]" onClick={e => e.stopPropagation()}>
                <header className="flex items-center justify-between p-6 border-b border-[var(--c-border)]">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 flex items-center justify-center rounded-lg bg-[var(--c-primary)]/10">
                            <Sparkles className="w-6 h-6 text-[var(--c-primary)]" />
                        </div>
                        <div>
                            <h2 className="text-lg font-semibold text-[var(--c-text-strong)]">Import from Google AI Studio</h2>
                            <p className="text-sm text-[var(--c-text-secondary)]">Quickly set up an agent by pasting your prompt details.</p>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-[var(--c-bg)]">
                        <X className="w-5 h-5 text-[var(--c-text-secondary)]" />
                    </button>
                </header>

                <main className="flex-grow p-6 space-y-6 overflow-y-auto">
                    <a href="https://aistudio.google.com/" target="_blank" rel="noopener noreferrer" className="block p-4 rounded-lg bg-[var(--c-bg)] hover:bg-[var(--c-surface)] border border-[var(--c-border)] group">
                        <div className="flex justify-between items-center">
                            <p className="font-semibold text-[var(--c-text-strong)]">Go to Google AI Studio</p>
                            <ExternalLink className="w-5 h-5 text-[var(--c-text-secondary)] group-hover:text-[var(--c-primary)]" />
                        </div>
                        <p className="text-sm text-[var(--c-text-secondary)] mt-1">
                            Create or open your prompt in AI Studio, then copy the details into the form below.
                        </p>
                    </a>

                    <div>
                        <label htmlFor="import-agent-name" className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Agent Name</label>
                        <input
                            id="import-agent-name"
                            type="text"
                            value={agentName}
                            onChange={(e) => setAgentName(e.target.value)}
                            placeholder="e.g., Marketing Copywriter"
                            className="w-full bg-[var(--c-surface)] border border-[var(--c-border)] rounded-md px-3 py-2 text-sm text-[var(--c-text-strong)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)]"
                        />
                    </div>

                    <div>
                        <label htmlFor="import-system-prompt" className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">System Prompt</label>
                        <textarea
                            id="import-system-prompt"
                            rows={8}
                            value={systemPrompt}
                            onChange={(e) => setSystemPrompt(e.target.value)}
                            placeholder="Paste the full system prompt or instructions for your agent here..."
                            className="w-full bg-[var(--c-surface)] border border-[var(--c-border)] rounded-md px-3 py-2 text-sm text-[var(--c-text-strong)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)] font-mono"
                        />
                    </div>
                     <div>
                        <label htmlFor="import-greeting" className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Initial Greeting (Optional)</label>
                        <textarea
                            id="import-greeting"
                            rows={2}
                            value={greeting}
                            onChange={(e) => setGreeting(e.target.value)}
                            placeholder="e.g., Hello, how can I help you today?"
                            className="w-full bg-[var(--c-surface)] border border-[var(--c-border)] rounded-md px-3 py-2 text-sm text-[var(--c-text-strong)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)]"
                        />
                        <p className="text-xs text-[var(--c-text-secondary)] mt-1">This will be the first message the agent says.</p>
                    </div>
                </main>

                <footer className="p-4 border-t border-[var(--c-border)] flex-shrink-0 flex justify-end gap-3">
                    <button
                        type="button"
                        className="inline-flex justify-center rounded-md bg-[var(--c-surface)] px-4 py-2.5 text-sm font-semibold text-[var(--c-text-primary)] shadow-sm ring-1 ring-inset ring-[var(--c-border)] hover:bg-[var(--c-bg)] transition-colors"
                        onClick={onClose}
                    >
                        Cancel
                    </button>
                    <button
                        type="button"
                        className="inline-flex justify-center rounded-md bg-[var(--c-primary)] px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:opacity-90 transition-colors disabled:opacity-60"
                        onClick={handleImport}
                        disabled={!agentName || !systemPrompt}
                    >
                        Import Agent
                    </button>
                </footer>
            </div>
        </div>
    );
};

export default ImportAgentModal;
