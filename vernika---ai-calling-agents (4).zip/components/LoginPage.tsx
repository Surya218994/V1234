

import React, { useState } from 'react';
import { Page } from '../types';
import { GoogleIcon } from './IconComponents';
import * as authService from '../services/authService';
import GoogleSignInModal from './GoogleSignInModal';

interface LoginPageProps {
    navigateTo: (page: Page) => void;
    onLoginSuccess: (email: string) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ navigateTo, onLoginSuccess }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [isGoogleSignInOpen, setIsGoogleSignInOpen] = useState(false);

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!email || !password) {
            setError('Please enter your email and password.');
            return;
        }
        
        try {
            authService.login(email, password);
            onLoginSuccess(email);
        } catch (err) {
            if (err instanceof Error) {
                setError(err.message);
            } else {
                setError('An unknown error occurred.');
            }
        }
    };
    
    const handleGoogleLogin = () => {
        setIsGoogleSignInOpen(true);
    };

    return (
        <>
            <div className="flex items-center justify-center min-h-screen bg-[var(--c-bg)] px-4">
                <div className="w-full max-w-md">
                    <div className="text-center mb-8">
                        <h1 className="text-3xl font-bold text-[var(--c-text-strong)]">Welcome Back</h1>
                        <p className="text-[var(--c-text-secondary)]">Sign in to continue to Vernika.</p>
                    </div>
                    
                    <div className="bg-[var(--c-surface)] border border-[var(--c-border)] rounded-2xl p-8 shadow-lg">
                        <form onSubmit={handleLogin} className="space-y-6">
                            <div>
                                <label htmlFor="email" className="block text-sm font-medium text-[var(--c-text-primary)] mb-1">Email address</label>
                                <input
                                    type="email"
                                    id="email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    required
                                    className="w-full bg-[var(--c-surface)] border border-[var(--c-border)] rounded-lg px-4 py-2.5 text-[var(--c-text-strong)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)]"
                                />
                            </div>
                            <div>
                                <label htmlFor="password" className="block text-sm font-medium text-[var(--c-text-primary)] mb-1">Password</label>
                                <input
                                    type="password"
                                    id="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    required
                                    className="w-full bg-[var(--c-surface)] border border-[var(--c-border)] rounded-lg px-4 py-2.5 text-[var(--c-text-strong)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)]"
                                />
                            </div>

                            {error && (
                                <div className="bg-red-100 border border-red-300 text-red-700 text-sm rounded-lg p-3 text-center">
                                    {error}
                                </div>
                            )}

                            <button
                                type="submit"
                                className="w-full bg-[var(--c-primary)] text-white font-semibold py-3 px-4 rounded-lg hover:opacity-90 transition-colors"
                            >
                                Sign In
                            </button>
                        </form>

                        <div className="relative my-6">
                            <div className="absolute inset-0 flex items-center" aria-hidden="true">
                                <div className="w-full border-t border-[var(--c-border)]" />
                            </div>
                            <div className="relative flex justify-center text-sm">
                                <span className="bg-[var(--c-surface)] px-2 text-[var(--c-text-secondary)]">OR</span>
                            </div>
                        </div>

                        <button
                            onClick={handleGoogleLogin}
                            className="w-full flex items-center justify-center gap-3 bg-[var(--c-surface)] text-[var(--c-text-primary)] font-semibold py-3 px-4 rounded-lg hover:bg-[var(--c-bg)] transition-colors border border-[var(--c-border)]"
                        >
                            <GoogleIcon className="w-5 h-5 text-[#4285F4]"/>
                            <span>Sign in with Google</span>
                        </button>
                    </div>
                    <p className="mt-8 text-center text-sm text-[var(--c-text-secondary)]">
                        Don't have an account?{' '}
                        <a onClick={() => navigateTo('signup')} className="font-semibold text-[var(--c-primary)] hover:opacity-80 cursor-pointer">
                            Sign up
                        </a>
                    </p>
                </div>
            </div>
            {isGoogleSignInOpen && (
                <GoogleSignInModal 
                    onClose={() => setIsGoogleSignInOpen(false)} 
                    onLoginSuccess={onLoginSuccess}
                />
            )}
        </>
    );
};

export default LoginPage;