import React from 'react';
import { useTheme } from '../contexts/ThemeContext';
import { Sun, Moon } from './IconComponents';

interface ThemeToggleButtonProps {
  className?: string;
}

export const ThemeToggleButton: React.FC<ThemeToggleButtonProps> = ({ className }) => {
    const { theme, toggleTheme } = useTheme();

    return (
        <button
            onClick={toggleTheme}
            className={`p-2 rounded-lg transition-colors text-[var(--c-text-secondary)] hover:bg-[var(--c-bg)] hover:text-[var(--c-text-primary)] ${className}`}
            aria-label={theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode'}
        >
            {theme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
        </button>
    );
};
