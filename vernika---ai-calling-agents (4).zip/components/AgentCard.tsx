


import React, { useState, useEffect } from 'react';
import { Agent } from '../types';
import { ChevronRight, Bot } from './IconComponents';

interface AgentCardProps {
    agent: Agent;
    onSelect?: (agent: Agent) => void;
    showButton?: boolean;
    index?: number; // For staggered animation
}

export default function AgentCard({ agent, onSelect, showButton = true, index = 0 }: AgentCardProps) {
    const [imgError, setImgError] = useState(false);

    useEffect(() => {
        setImgError(false);
    }, [agent.imageUrl]);
    
    // Theme-aware badge styles using semi-transparent backgrounds
    const badgeStyles: { [key: string]: string } = {
        // Status Badges
        'Ready for deployment': 'bg-green-100 dark:bg-green-500/20 text-green-700 dark:text-green-300',
        'In training': 'bg-amber-100 dark:bg-amber-500/20 text-amber-700 dark:text-amber-300',
        
        // Category Badges
        'Support': 'bg-sky-100 dark:bg-sky-500/20 text-sky-700 dark:text-sky-300',
        'Sales': 'bg-rose-100 dark:bg-rose-500/20 text-rose-700 dark:text-rose-300',
        'Scheduling': 'bg-violet-100 dark:bg-violet-500/20 text-violet-700 dark:text-violet-300',
        'Custom': 'bg-slate-200 dark:bg-slate-500/20 text-slate-700 dark:text-slate-300',
    };

    const statusClasses = badgeStyles[agent.status] || badgeStyles['Custom'];
    const categoryClasses = badgeStyles[agent.category] || badgeStyles['Custom'];

    const Avatar = () => {
        if (imgError || !agent.imageUrl) {
            return (
                <div className="w-16 h-16 rounded-full flex items-center justify-center bg-[var(--c-primary)]/10 text-[var(--c-primary)]/80 border-2 border-transparent group-hover:border-[var(--c-primary)]/30 transition-all duration-300">
                    <Bot className="w-9 h-9" />
                </div>
            );
        }

        return (
            <img 
                src={agent.imageUrl} 
                alt={agent.name} 
                onError={() => setImgError(true)}
                className="w-16 h-16 rounded-full object-cover border-2 border-transparent group-hover:border-[var(--c-primary)]/30 transition-all duration-300" 
            />
        );
    };

    return (
        <div 
            className="opacity-0 relative bg-[var(--c-surface)] border border-[var(--c-border)] rounded-2xl p-6 flex flex-col text-left h-full transition-all duration-300 group hover:-translate-y-1.5 hover:shadow-xl hover:border-2 hover:border-[var(--c-primary)] animate-fade-in-up"
            style={{ animationDelay: `${index * 100}ms` }}
        >
           {/* Card Header */}
           <div className="flex items-start space-x-4 mb-4">
                <div className="relative flex-shrink-0">
                    <Avatar />
                    <span className={`absolute -bottom-0.5 -right-0.5 block h-4 w-4 rounded-full border-2 border-[var(--c-surface)] ${agent.status === 'Ready for deployment' ? 'bg-green-500' : 'bg-orange-500'}`}></span>
                </div>
                <div className="flex-1 mt-1">
                    <h3 className="text-xl font-bold text-[var(--c-text-strong)]">{agent.name}</h3>
                    <p className="text-sm text-[var(--c-text-secondary)] -mt-0.5">{agent.title}</p>
                </div>
            </div>
            
            {/* Description */}
            <p className="text-sm text-[var(--c-text-primary)] mb-5 flex-grow">{agent.description}</p>
        
            {/* Divider */}
            <div className="border-t border-[var(--c-border)] my-4"></div>

            {/* Tags */}
            <div className="w-full space-y-3 text-sm mb-4">
                <div className="flex justify-between items-center">
                    <span className="text-[var(--c-text-secondary)] font-medium">Status</span>
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${statusClasses}`}>{agent.status}</span>
                </div>
                <div className="flex justify-between items-center">
                    <span className="text-[var(--c-text-secondary)] font-medium">Category</span>
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${categoryClasses}`}>{agent.category}</span>
                </div>
            </div>
            
            {/* Action Button */}
            {showButton && onSelect && (
                 <div className="mt-auto pt-2">
                     <button 
                        onClick={() => onSelect(agent)}
                        className="w-full bg-[var(--c-primary)] text-white font-semibold py-3 px-4 rounded-lg transition-all duration-300 transform hover:scale-105 group-hover:opacity-100 opacity-90 flex items-center justify-center gap-2 shadow-lg shadow-blue-500/10 dark:shadow-blue-500/20">
                        <span>Select & customize</span>
                        <ChevronRight className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1"/>
                    </button>
                </div>
            )}
        </div>
    );
};
