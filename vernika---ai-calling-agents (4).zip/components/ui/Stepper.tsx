import React from 'react';
import { ChevronRight, Check } from '../IconComponents';

interface StepProps {
  stepNumber: number;
  title: string;
  isCurrent: boolean;
  isCompleted: boolean;
}

const Step: React.FC<StepProps> = ({ stepNumber, title, isCurrent, isCompleted }) => {
  const circleClasses = isCompleted
    ? 'bg-[var(--c-primary)] text-white'
    : isCurrent
    ? 'border-2 border-[var(--c-primary)] text-[var(--c-primary)] bg-[var(--c-primary)]/10'
    : 'border-2 border-[var(--c-border)] bg-[var(--c-surface)] text-[var(--c-text-secondary)]';
  
  const titleClasses = isCurrent || isCompleted ? 'text-[var(--c-text-strong)]' : 'text-[var(--c-text-secondary)]';

  return (
    <div className="flex flex-col items-center text-center w-36">
      <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg flex-shrink-0 transition-colors duration-300 ${circleClasses}`}>
        {isCompleted ? <Check className="w-6 h-6" /> : stepNumber}
      </div>
      <h4 className={`mt-2 font-semibold text-sm ${titleClasses}`}>{title}</h4>
    </div>
  );
};

interface StepperProps {
    currentStep: number;
    steps: { title: string; description: string }[];
}

const Stepper: React.FC<StepperProps> = ({ currentStep, steps }) => {
    return (
        <div className="flex items-start justify-center">
            {steps.map((step, index) => (
                <React.Fragment key={step.title}>
                    <Step
                        stepNumber={index + 1}
                        title={step.title}
                        isCurrent={currentStep === index + 1}
                        isCompleted={currentStep > index + 1}
                    />
                    {index < steps.length - 1 && (
                        <div className="flex-1 h-1 bg-[var(--c-border)] rounded-full mx-4 mt-5 relative">
                           <div className="h-1 bg-[var(--c-primary)] rounded-full transition-all duration-500" style={{ width: currentStep > index + 1 ? '100%' : '0%' }}></div>
                        </div>
                    )}
                </React.Fragment>
            ))}
        </div>
    );
};

export default Stepper;