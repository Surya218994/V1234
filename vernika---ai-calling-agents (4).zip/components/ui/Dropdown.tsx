import React, { useState, useRef, useEffect } from 'react';
import { DropdownOption } from '../../types';
import { ChevronsUpDown, Check } from '../IconComponents';

interface DropdownProps {
  options: DropdownOption[];
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

export default function Dropdown({ options, value, onChange, placeholder = 'Select an option' }: DropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const selectedOption = options.find(opt => opt.value === value);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (optionValue: string) => {
    onChange(optionValue);
    setIsOpen(false);
  };

  return (
    <div className="relative w-full" ref={dropdownRef}>
      <button
        type="button"
        className="flex items-center justify-between w-full bg-[var(--c-surface)] border border-[var(--c-border)] rounded-lg px-4 py-2.5 text-sm text-left text-[var(--c-text-strong)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)]"
        onClick={() => setIsOpen(!isOpen)}
        aria-haspopup="listbox"
        aria-expanded={isOpen}
      >
        <span className="truncate">{selectedOption?.label || placeholder}</span>
        <ChevronsUpDown className="w-4 h-4 text-[var(--c-text-secondary)] ml-2 flex-shrink-0" />
      </button>
      
      {isOpen && (
        <div 
            className="absolute z-10 mt-1 w-full bg-[var(--c-surface)] border border-[var(--c-border)] rounded-lg shadow-lg max-h-60 overflow-auto focus:outline-none animate-fade-in-fast p-1"
            role="listbox"
        >
            {options.map(option => (
              <div
                key={option.value}
                className={`flex items-center justify-between px-3 py-2 text-[var(--c-text-strong)] hover:bg-[var(--c-primary)]/10 cursor-pointer text-sm rounded-md ${value === option.value ? 'bg-[var(--c-primary)]/10' : ''}`}
                onClick={() => handleSelect(option.value)}
                role="option"
                aria-selected={value === option.value}
              >
                <span className="truncate">{option.label}</span>
                {value === option.value && <Check className="w-5 h-5 text-[var(--c-primary)] flex-shrink-0" />}
              </div>
            ))}
        </div>
      )}
    </div>
  );
}
