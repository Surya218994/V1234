import React, { useState } from 'react';
import { ChevronRight } from '../IconComponents';

interface CollapsibleSectionProps {
  title: React.ReactNode;
  children: React.ReactNode;
  defaultOpen?: boolean;
}

const CollapsibleSection: React.FC<CollapsibleSectionProps> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="border-b border-slate-700/50 last:border-b-0 py-4">
      <button
        type="button"
        className="w-full flex justify-between items-center text-left"
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="flex items-center gap-2 text-md font-semibold text-white">{title}</div>
        <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform transform ${isOpen ? 'rotate-90' : ''}`} />
      </button>
      {isOpen && <div className="mt-4 text-gray-300">{children}</div>}
    </div>
  );
};

export default CollapsibleSection;
