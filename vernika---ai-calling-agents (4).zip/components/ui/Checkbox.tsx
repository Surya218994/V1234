import React from 'react';
import { Check } from '../IconComponents';

interface CheckboxProps {
  id: string;
  label: React.ReactNode;
  checked: boolean;
  onChange: (checked: boolean) => void;
  description?: string;
}

const Checkbox: React.FC<CheckboxProps> = ({ id, label, checked, onChange, description }) => {
  return (
    <div className="relative flex items-start">
      <div className="flex h-6 items-center">
        <input
          id={id}
          aria-describedby={description ? `${id}-description` : undefined}
          name={id}
          type="checkbox"
          checked={checked}
          onChange={(e) => onChange(e.target.checked)}
          className="peer sr-only"
        />
        <label
            htmlFor={id}
            className={`
                flex h-5 w-5 cursor-pointer items-center justify-center rounded 
                border-2 
                transition-colors
                peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-offset-2 peer-focus:ring-offset-slate-800 peer-focus:ring-blue-500
                ${checked
                    ? 'border-blue-600 bg-blue-600'
                    : 'border-slate-600 bg-slate-700/50 hover:border-slate-500'
                }
            `}
        >
            <Check className={`h-3.5 w-3.5 text-white transition-opacity ${checked ? 'opacity-100' : 'opacity-0'}`} />
        </label>
      </div>
      <div className="ml-3 text-sm leading-6">
        <label htmlFor={id} className="font-medium text-white cursor-pointer">
          {label}
        </label>
        {description && <p id={`${id}-description`} className="text-gray-400">{description}</p>}
      </div>
    </div>
  );
};

export default Checkbox;
