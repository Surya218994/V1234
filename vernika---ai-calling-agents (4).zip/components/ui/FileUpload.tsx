import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, File, X } from '../IconComponents';

interface FileUploadProps {
  files: File[];
  setFiles: (files: File[]) => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ files, setFiles }) => {

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setFiles([...files, ...acceptedFiles]);
  }, [files, setFiles]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'text/plain': ['.txt'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
    },
  });

  const removeFile = (fileToRemove: File) => {
    setFiles(files.filter(file => file !== fileToRemove));
  };
  
  const formatBytes = (bytes: number, decimals = 2) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  return (
    <div className="space-y-4">
      <div
        {...getRootProps()}
        className={`
          relative w-full p-6 border-2 border-dashed rounded-xl text-center cursor-pointer transition-colors duration-200
          ${isDragActive ? 'border-blue-500 bg-blue-500/10' : 'border-[var(--c-border)] hover:border-blue-500/50 bg-[var(--c-surface)] hover:bg-[var(--c-bg)]'}
        `}
      >
        <input {...getInputProps()} />
        <div className="flex flex-col items-center justify-center text-[var(--c-text-secondary)]">
          <Upload className="w-8 h-8 mb-3 text-[var(--c-text-secondary)]" />
          <p className="font-semibold text-[var(--c-text-primary)]">
            {isDragActive ? 'Drop the files here...' : 'Drag & drop files, or click to browse'}
          </p>
          <p className="text-xs mt-1">Supports: PDF, TXT, DOCX</p>
        </div>
      </div>

      {files.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-sm font-semibold text-[var(--c-text-secondary)] px-1">Uploaded Files ({files.length})</h4>
          <ul className="max-h-48 overflow-y-auto space-y-2 rounded-lg border border-[var(--c-border)] bg-[var(--c-bg)] p-2">
            {files.map((file, index) => (
              <li key={index} className="flex items-center justify-between bg-[var(--c-surface)] p-2.5 rounded-md animate-fade-in-fast">
                <div className="flex items-center gap-3 overflow-hidden">
                  <File className="w-5 h-5 text-[var(--c-text-secondary)] flex-shrink-0" />
                  <div className="overflow-hidden">
                     <p className="text-sm text-[var(--c-text-strong)] truncate font-medium">{file.name}</p>
                     <p className="text-xs text-[var(--c-text-secondary)]">{formatBytes(file.size)}</p>
                  </div>
                </div>
                <button
                  onClick={() => removeFile(file)}
                  className="p-1 rounded-full hover:bg-red-500/20 text-[var(--c-text-secondary)] hover:text-red-400 transition-colors flex-shrink-0"
                  aria-label={`Remove ${file.name}`}
                >
                  <X className="w-4 h-4" />
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default FileUpload;