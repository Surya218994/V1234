import React from 'react';
import { ShoppingCart, HeartPulse, Landmark, PhoneForwarded, MessageCircle, GitFork, UsersRound, CalendarDays } from './IconComponents';

interface SolutionCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const SolutionCard: React.FC<SolutionCardProps> = ({ icon, title, description }) => (
    <div className="bg-[var(--c-surface)] p-8 rounded-2xl border border-[var(--c-border)] transition-all duration-300 hover:shadow-md hover:-translate-y-1">
        <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-4 mb-4">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-lg bg-[var(--c-primary)]/10 text-[var(--c-primary)] flex-shrink-0">
                {icon}
            </div>
            <h3 className="text-2xl font-semibold text-[var(--c-text-strong)]">{title}</h3>
        </div>
        <p className="text-[var(--c-text-primary)]">{description}</p>
    </div>
);

const solutions = [
    {
        icon: <UsersRound className="w-6 h-6"/>,
        title: "Inbound Customer Support",
        description: "Deploy AI agents to handle customer queries, resolve common issues, and answer FAQs 24/7, dramatically improving customer satisfaction and reducing agent workload."
    },
    {
        icon: <PhoneForwarded className="w-6 h-6"/>,
        title: "Outbound Sales & Lead Gen",
        description: "Automate your cold calling process. Qualify leads, gather information, and route high-intent prospects directly to your sales team, boosting pipeline and revenue."
    },
    {
        icon: <CalendarDays className="w-6 h-6"/>,
        title: "Automated Appointment Setting",
        description: "Let your AI agent handle the entire scheduling process, from initial outreach to finding a suitable time and sending calendar invites, freeing up your team's time."
    },
    {
        icon: <MessageCircle className="w-6 h-6"/>,
        title: "Proactive Website Assistant",
        description: "Engage website visitors with a voice or chat assistant that can answer questions, guide them through your product, and capture leads before they leave your site."
    }
];

const SolutionsPage: React.FC = () => {
    return (
        <div className="container mx-auto px-4 sm:px-6 py-16 md:py-24">
            <div className="text-center max-w-3xl mx-auto">
                <h1 className="font-serif font-bold tracking-tight text-[var(--c-text-strong)] text-4xl sm:text-5xl md:text-6xl">
                    Solutions for Every Business Need
                </h1>
                <p className="mt-6 text-lg leading-8 text-[var(--c-text-primary)]">
                    Vernika is a versatile platform that can be customized to meet the unique challenges and demands of any business communication workflow.
                </p>
            </div>
            <div className="mt-20 grid grid-cols-1 gap-8 md:grid-cols-2">
                {solutions.map(solution => (
                    <SolutionCard key={solution.title} {...solution} />
                ))}
            </div>
        </div>
    );
};

export default SolutionsPage;