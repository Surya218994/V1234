import React, { useState, useEffect } from 'react';
import { Page } from '../types';
import { ThemeToggleButton } from './ThemeToggleButton';
import { X } from './IconComponents';

interface HeaderProps {
    navigateTo: (page: Page) => void;
    currentPage: Page;
}

const NavLink: React.FC<{ page: Page; currentPage: Page; onClick: (page: Page) => void; children: React.ReactNode; className?: string }> = 
({ page, currentPage, onClick, children, className = '' }) => (
    <a 
        onClick={() => onClick(page)} 
        className={`cursor-pointer transition-colors text-base font-medium whitespace-nowrap ${currentPage === page ? 'text-[var(--c-text-strong)]' : 'text-[var(--c-text-secondary)] hover:text-[var(--c-text-primary)]'} ${className}`}
    >
        {children}
    </a>
);

const MobileNav: React.FC<{ navigateTo: (page: Page) => void; currentPage: Page, closeMenu: () => void }> = ({ navigateTo, currentPage, closeMenu }) => {
    const handleNavigate = (page: Page) => {
        navigateTo(page);
        closeMenu();
    };
    
    return (
        <div className="md:hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-50 animate-fade-in" onClick={closeMenu}>
            <div 
                className="fixed top-4 right-4 w-full max-w-xs bg-[var(--c-surface)] rounded-2xl p-6 shadow-lg border border-[var(--c-border)]"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex items-center justify-between mb-8">
                    <h3 className="font-semibold text-lg text-[var(--c-text-strong)]">Menu</h3>
                    <button onClick={closeMenu} className="p-2 -mr-2 rounded-full hover:bg-[var(--c-bg)]">
                        <X className="w-6 h-6 text-[var(--c-text-secondary)]" />
                    </button>
                </div>
                <nav className="flex flex-col space-y-5">
                    <NavLink page="features" currentPage={currentPage} onClick={handleNavigate} className="text-lg">Features</NavLink>
                    <NavLink page="solutions" currentPage={currentPage} onClick={handleNavigate} className="text-lg">Solutions</NavLink>
                    <NavLink page="pricing" currentPage={currentPage} onClick={handleNavigate} className="text-lg">Pricing</NavLink>
                </nav>
                <div className="border-t border-[var(--c-border)] mt-6 pt-6">
                    <button 
                        onClick={() => handleNavigate('login')}
                        className="w-full font-semibold px-5 py-3 rounded-lg transition-all duration-300 transform hover:scale-105 bg-[var(--c-text-strong)] text-[var(--c-bg)] hover:opacity-90"
                    >
                      Get Started
                    </button>
                </div>
            </div>
        </div>
    );
};

const Header: React.FC<HeaderProps> = ({ navigateTo, currentPage }) => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    useEffect(() => {
        // Prevent body scroll when mobile menu is open
        document.body.style.overflow = isMenuOpen ? 'hidden' : 'unset';
        return () => {
            document.body.style.overflow = 'unset';
        };
    }, [isMenuOpen]);

    const headerClasses = `fixed top-0 left-0 right-0 z-40 transition-all duration-300 bg-[var(--c-surface)]/80 backdrop-blur-sm border-b border-[var(--c-border)]`;
    
    const logoClasses = 'text-[var(--c-text-strong)]';
    const taglineClasses = 'text-[var(--c-text-secondary)]';
    const buttonClasses = `hidden md:block font-semibold px-5 py-2.5 rounded-lg transition-all whitespace-nowrap text-sm duration-300 transform hover:scale-105 bg-[var(--c-text-strong)] text-[var(--c-bg)] hover:opacity-90`;
    
  return (
    <>
      <header className={headerClasses}>
        <div className="container mx-auto px-4 sm:px-6 h-20 md:h-24 flex items-center justify-between">
          <div className="flex-1 flex justify-start">
              <div 
                className="flex items-center space-x-2 md:space-x-4 cursor-pointer"
                onClick={() => navigateTo('home')}
              >
                <div className={`font-serif text-2xl md:text-3xl font-bold ${logoClasses}`}>
                  Vernika
                </div>
                <span className={`hidden sm:block text-xs ${taglineClasses} mt-1.5 border-l border-current pl-2 md:pl-4`}>powered by PitchX</span>
              </div>
          </div>

          <nav className="hidden md:flex items-center justify-center space-x-10">
              <NavLink page="features" currentPage={currentPage} onClick={navigateTo}>Features</NavLink>
              <NavLink page="solutions" currentPage={currentPage} onClick={navigateTo}>Solutions</NavLink>
              <NavLink page="pricing" currentPage={currentPage} onClick={navigateTo}>Pricing</NavLink>
          </nav>

          <div className="flex-1 flex justify-end items-center gap-2">
              <ThemeToggleButton />
              <button 
                  onClick={() => navigateTo('login')}
                  className={buttonClasses}
              >
                Get Started
              </button>
              <button
                className="md:hidden p-2 rounded-md hover:bg-[var(--c-bg)]"
                onClick={() => setIsMenuOpen(true)}
                aria-label="Open menu"
              >
                <svg className="w-6 h-6 text-[var(--c-text-strong)]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7" />
                </svg>
              </button>
          </div>
        </div>
      </header>
      {isMenuOpen && <MobileNav navigateTo={navigateTo} currentPage={currentPage} closeMenu={() => setIsMenuOpen(false)} />}
    </>
  );
};

export default Header;