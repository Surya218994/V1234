

import React, { useState, useEffect, useRef } from 'react';
import { Agent, Page, AgentConfigurationData, AuthUser, CallHistoryRecord, TwilioConfig, PhoneNumber } from '../types';
import { AgentConfiguration } from './agent-configuration/AgentConfiguration';
import DemoModal from './DemoModal';
import CreateAgentWizard from './agent-configuration/CreateAgentWizard';
import AgentsPage from './AgentsPage';
import DashboardPage from './DashboardPage';
import PhoneNumbersPage from './PhoneNumbersPage';
import CallHistoryPage from './CallHistoryPage';
import CampaignsPage from './CampaignsPage';
import { ThemeToggleButton } from './ThemeToggleButton';
import { 
    UsersRound, 
    SlidersHorizontal, 
    Hash, 
    BarChart, 
    Phone, 
    Target, 
    ChevronsUpDown,
    User,
    PlayCircle,
    MessageSquarePlus,
    BookText,
    CircleDollarSign,
    ExternalLink,
    ChevronRight,
    Plus,
    X,
    Spinner,
    Code
} from './IconComponents';
import * as authService from '../services/authService';

const initialAgentData: Agent[] = [
  {
    id: 'eva-support',
    name: 'Eva',
    title: 'Support Specialist',
    description: 'Handles inbound customer queries, answers FAQs, and resolves common issues with empathy and efficiency.',
    status: 'Ready for deployment',
    category: 'Support',
    imageUrl: `https://storage.googleapis.com/aai-assets/vernika/support-bot.png`,
    configuration: {
      agentName: 'Eva',
      voice: 'en-US-Standard-C',
      accent: '',
      quality: 'medium',
      systemPrompt: "You are Eva, a friendly and knowledgeable customer support specialist. Your primary goal is to resolve customer issues quickly and accurately based on the provided knowledge base. Always be patient and empathetic. If you cannot solve the issue, offer to escalate to a human agent.",
      conversationStarters: "Thanks for calling. This is Eva, how can I help you today?",
      escalationRules: "If the user is angry, mentions a billing error, or asks to cancel their account, transfer to a human specialist.",
      prohibitedTopics: "Do not provide personal opinions or discuss other customers."
    }
  },
  {
    id: 'maya-sales',
    name: 'Maya',
    title: 'Sales Development Rep',
    description: 'Engages in outbound cold calls to qualify leads, introduce the product, and book meetings for the sales team.',
    status: 'Ready for deployment',
    category: 'Sales',
    imageUrl: 'https://storage.googleapis.com/aai-assets/vernika/sales-bot.png',
    configuration: {
      agentName: 'Maya',
      voice: 'en-US-Studio-O',
      accent: '',
      quality: 'high',
      systemPrompt: "You are Maya, a confident and persuasive Sales Development Representative. Your goal is to call leads, qualify their interest in our product based on a script, and schedule a demo with a senior account executive. Be energetic and professional.",
      conversationStarters: "Hi, I'm Maya calling from Vernika. Is now a good time to talk for a minute?",
      escalationRules: "If a lead asks a deep technical question you can't answer, book the meeting and note the question for the account executive.",
      prohibitedTopics: "Do not negotiate pricing or make promises about product features."
    }
  },
  {
    id: 'mia-scheduler',
    name: 'Mia',
    title: 'Appointment Setter',
    description: 'Efficiently schedules appointments, manages calendars, and sends reminders to reduce no-shows.',
    status: 'Ready for deployment',
    category: 'Scheduling',
    imageUrl: 'https://storage.googleapis.com/aai-assets/vernika/scheduling-bot.png',
    configuration: {
      agentName: 'Mia',
      voice: 'en-US-Studio-O',
      accent: '',
      quality: 'high',
      systemPrompt: "You are Mia, a highly organized and friendly appointment scheduler. Your purpose is to help users book, reschedule, or cancel appointments. Be clear, concise, and confirm all details with the user before ending the call.",
      conversationStarters: "Hello, you've reached the scheduling line. This is Mia, how can I assist you with an appointment today?",
      escalationRules: "If there's a scheduling conflict that cannot be resolved or it's a last-minute cancellation, transfer the call to the office manager.",
      prohibitedTopics: "Do not discuss the reason for the appointment unless required for scheduling purposes."
    }
  },
  {
    id: 'zoe-assistant',
    name: 'Zoe',
    title: 'Website Assistant',
    description: 'Proactively engages website visitors, answers questions about products, and captures leads for the sales team.',
    status: 'In training',
    category: 'Support',
    imageUrl: 'https://storage.googleapis.com/aai-assets/vernika/website-bot.png',
    configuration: {
      agentName: 'Zoe',
      voice: 'en-GB-Wavenet-F',
      accent: '',
      quality: 'high',
      systemPrompt: "You are Zoe, a helpful website assistant. Your job is to greet visitors, answer their questions about our products using the knowledge base, and encourage them to sign up for a demo if they show interest. Be cheerful and helpful.",
      conversationStarters: "Hi there! I'm Zoe. Do you have any questions about our products? I'm happy to help!",
      escalationRules: "If a visitor has a complex pricing question or wants a custom quote, collect their contact information and tell them a sales representative will reach out.",
      prohibitedTopics: "Do not comment on competitors."
    }
  }
];

const NavItem: React.FC<{
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick?: () => void;
}> = ({ icon, label, active, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-colors text-left ${
      active
        ? 'bg-[var(--c-primary)]/10 text-[var(--c-primary)]'
        : 'text-[var(--c-text-primary)] hover:bg-[var(--c-bg)] hover:text-[var(--c-text-strong)]'
    }`}
  >
    {icon}
    <span>{label}</span>
  </button>
);

interface AuthenticatedAppProps {
  navigateTo: (page: Page) => void;
  userEmail: string;
}

type ActiveView = 'dashboard' | 'agents' | 'numbers' | 'call-history' | 'campaigns';

export const AuthenticatedApp: React.FC<AuthenticatedAppProps> = ({ navigateTo, userEmail }) => {
  const [agents, setAgents] = useState<Agent[] | null>(null);
  const [callHistory, setCallHistory] = useState<CallHistoryRecord[] | null>(null);
  const [twilioConfig, setTwilioConfig] = useState<TwilioConfig | null>(null);
  const [phoneNumbers, setPhoneNumbers] = useState<PhoneNumber[] | null>(null);

  const [activeView, setActiveView] = useState<ActiveView>('dashboard');
  const [configuringAgent, setConfiguringAgent] = useState<Agent | null>(null);
  const [isDemoModalOpen, setIsDemoModalOpen] = useState(false);
  const [isCreatingAgent, setIsCreatingAgent] = useState(false);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  useEffect(() => {
    const currentUser = authService.getUserByEmail(userEmail);
    setUser(currentUser);

    const storedAgents = authService.getUserAgents(userEmail);
    setAgents(storedAgents || initialAgentData);

    const storedHistory = authService.getUserCallHistory(userEmail);
    setCallHistory(storedHistory || []);

    const storedTwilioConfig = authService.getUserTwilioConfig(userEmail);
    setTwilioConfig(storedTwilioConfig);
    const storedPhoneNumbers = authService.getUserPhoneNumbers(userEmail);
    setPhoneNumbers(storedPhoneNumbers || []);
  }, [userEmail]);

  useEffect(() => {
    if (agents && userEmail) authService.saveUserAgents(userEmail, agents);
  }, [agents, userEmail]);
  
  useEffect(() => {
    if(callHistory && userEmail) authService.saveUserCallHistory(userEmail, callHistory);
  }, [callHistory, userEmail]);

  useEffect(() => {
      if (userEmail && twilioConfig) authService.saveUserTwilioConfig(userEmail, twilioConfig);
      if (userEmail && phoneNumbers) authService.saveUserPhoneNumbers(userEmail, phoneNumbers);
  }, [twilioConfig, phoneNumbers, userEmail]);

  if (agents === null || user === null || callHistory === null || phoneNumbers === null) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[var(--c-bg)]">
        <Spinner className="w-12 h-12 text-[var(--c-primary)]" />
      </div>
    );
  }
  
  const handleNavItemClick = (view: ActiveView) => {
    setActiveView(view);
    setConfiguringAgent(null);
    setIsSidebarOpen(false);
  }
  
  const handleConfigureAgentClick = () => {
    if (!configuringAgent && agents.length > 0) {
      setConfiguringAgent(agents[0]);
    } else if (configuringAgent) {
      // do nothing, already showing config
    } else {
        setIsCreatingAgent(true);
    }
    setActiveView('agents');
    setIsSidebarOpen(false);
  };

  const handleSelectAgentToConfigure = (agent: Agent) => {
    setConfiguringAgent(agent);
    setActiveView('agents');
  };

  const handleCreateAgent = (config: AgentConfigurationData) => {
    const newAgent: Agent = {
      id: config.agentName.toLowerCase().replace(/\s+/g, '-') + '-' + Date.now(),
      name: config.agentName,
      title: 'Custom Agent',
      description: config.systemPrompt.substring(0, 100) + (config.systemPrompt.length > 100 ? '...' : ''),
      status: 'In training',
      category: 'Custom',
      imageUrl: `https://storage.googleapis.com/aai-assets/vernika/default-bot.png`,
      configuration: config,
    };
    setAgents(prev => (prev ? [newAgent, ...prev] : [newAgent]));
    setConfiguringAgent(newAgent);
  };

  const handleImportAgent = (config: AgentConfigurationData) => {
    const newAgent: Agent = {
      id: config.agentName.toLowerCase().replace(/\s+/g, '-') + '-' + Date.now(),
      name: config.agentName,
      title: 'Imported Agent',
      description: config.systemPrompt.substring(0, 100) + (config.systemPrompt.length > 100 ? '...' : ''),
      status: 'Ready for deployment',
      category: 'Custom',
      imageUrl: `https://storage.googleapis.com/aai-assets/vernika/google-studio-bot.png`,
      configuration: config,
    };
    setAgents(prev => (prev ? [newAgent, ...prev] : [newAgent]));
    setConfiguringAgent(newAgent);
  };

  const handleUpdateAgent = (updatedAgent: Agent) => {
    setAgents(prev => (prev ? prev.map(a => a.id === updatedAgent.id ? updatedAgent : a) : [updatedAgent]));
    setConfiguringAgent(updatedAgent);
  };

  const handleDeleteAgent = (agentIdToDelete: string) => {
    setAgents(prev => (prev ? prev.filter(a => a.id !== agentIdToDelete) : []));
    if (configuringAgent?.id === agentIdToDelete) {
      setConfiguringAgent(null);
    }
  };

  const handleConnectTwilio = async (config: TwilioConfig) => {
    const numbers = await authService.connectToTwilioAndFetchNumbers(config);
    setTwilioConfig(config);
    setPhoneNumbers(numbers);
  };

  const handleDisconnectTwilio = () => {
    authService.removeUserTwilioData(userEmail);
    setTwilioConfig(null);
    setPhoneNumbers([]);
  };
  
  const handleAddPhoneNumber = (number: PhoneNumber) => {
      setPhoneNumbers(prev => {
          if (prev && prev.find(n => n.phoneNumber === number.phoneNumber)) {
              return prev; // Avoid duplicates
          }
          return [...(prev || []), number];
      });
  };

  const handleLinkAgentToNumber = (phoneNumberSid: string, agentId: string | null) => {
    setPhoneNumbers(prev => (prev ? prev.map(num => num.sid === phoneNumberSid ? { ...num, linkedAgentId: agentId } : num) : []));
  };

  const handleSetInboundClick = () => {
    handleNavItemClick('numbers');
  };


  const truncateEmail = (email: string, maxLength: number = 15) => {
    if (email.length <= maxLength) return email;
    return email.substring(0, maxLength) + '...';
  };
  
  const SidebarContent = () => (
    <>
      <button
        type="button"
        onClick={() => navigateTo('home')}
        className="w-full flex items-center space-x-3 mb-10 px-2 py-2 rounded-lg text-left transition-colors hover:bg-[var(--c-bg)]"
      >
        <div className="w-9 h-9 bg-[var(--c-bg)] rounded-lg flex items-center justify-center font-bold text-lg text-[var(--c-primary)] flex-shrink-0">
            {user ? user.name.charAt(0).toUpperCase() : 'V'}
        </div>
        <div className="flex-grow overflow-hidden">
            <span className="font-bold text-[var(--c-text-strong)] block truncate">{user ? user.name : 'Vernika'}</span>
            <span className="text-xs text-[var(--c-text-secondary)] block">Trial</span>
        </div>
        <ChevronsUpDown className="w-4 h-4 ml-auto text-[var(--c-text-secondary)] flex-shrink-0" />
      </button>
      
      <nav className="flex-grow space-y-2">
          <p className="px-3 py-2 text-xs font-semibold uppercase text-[var(--c-text-secondary)] tracking-wider">Platform</p>
          <NavItem icon={<BarChart className="w-5 h-5"/>} label="Dashboard" active={activeView === 'dashboard' && !configuringAgent} onClick={() => handleNavItemClick('dashboard')} />
          <NavItem icon={<UsersRound className="w-5 h-5"/>} label="My Agents" active={activeView === 'agents' && !configuringAgent} onClick={() => handleNavItemClick('agents')} />
          <NavItem icon={<SlidersHorizontal className="w-5 h-5"/>} label="Configure Agent" active={!!configuringAgent} onClick={handleConfigureAgentClick} />
          <NavItem icon={<Hash className="w-5 h-5"/>} label="My numbers" active={activeView === 'numbers' && !configuringAgent} onClick={() => handleNavItemClick('numbers')} />
          <NavItem icon={<Phone className="w-5 h-5"/>} label="Call History" active={activeView === 'call-history' && !configuringAgent} onClick={() => handleNavItemClick('call-history')} />
          <NavItem icon={<Target className="w-5 h-5"/>} label="Campaigns" active={activeView === 'campaigns' && !configuringAgent} onClick={() => handleNavItemClick('campaigns')} />
      </nav>

      <div className="mt-auto">
          <div className="flex items-center space-x-3 cursor-pointer p-4 rounded-lg hover:bg-[var(--c-bg)]">
              <User className="w-10 h-10 p-2 bg-[var(--c-bg)] rounded-full text-[var(--c-text-strong)]"/>
              <span className="text-sm font-medium text-[var(--c-text-strong)] truncate">{truncateEmail(userEmail)}</span>
          </div>
      </div>
    </>
  )

  const renderHeader = () => {
    let title = '';
    let description = '';

    if (configuringAgent) {
        title = 'Agent Configuration';
        description = `Customizing ${configuringAgent.name}`;
    } else {
        switch(activeView) {
            case 'agents':
                title = 'My Agents';
                description = 'Create, view, and manage your AI agents.';
                break;
            case 'numbers':
                title = 'My Phone Numbers';
                description = 'Purchase and manage your inbound phone numbers.';
                break;
            case 'call-history':
                title = 'Agent Conversations';
                description = 'Review transcripts and details of all agent calls.';
                break;
            case 'campaigns':
                title = 'Campaigns';
                description = 'Create and manage outbound calling campaigns.';
                break;
            case 'dashboard':
            default:
                title = 'Dashboard';
                description = 'Analytics and insights for your voice operations.';
        }
    }

    const HeaderButton: React.FC<{children: React.ReactNode, onClick?: () => void}> = ({children, onClick}) => (
        <button onClick={onClick} className="flex items-center justify-center space-x-2 bg-[var(--c-surface)] text-[var(--c-text-strong)] font-semibold px-4 py-2.5 rounded-lg hover:bg-[var(--c-bg)] border border-[var(--c-border)] transition-colors text-sm">
            {children}
        </button>
    );

    const renderHeaderActions = () => {
        if (configuringAgent) return null;

        if (activeView === 'campaigns') {
          return (
            <div className="hidden md:flex items-center space-x-2">
                <HeaderButton onClick={() => setIsCreatingAgent(true)}>
                    <Plus className="w-5 h-5"/>
                    <span>Create New Campaign</span>
                </HeaderButton>
            </div>
          )
        }

        if (activeView === 'numbers') {
            return (
                <div className="hidden md:flex items-center space-x-2">
                    <HeaderButton>
                        <CircleDollarSign className="w-5 h-5 text-gray-400"/>
                        <span>Add Funds</span>
                    </HeaderButton>
                    <button className="bg-[var(--c-primary)] text-white font-semibold px-5 py-2.5 rounded-lg hover:opacity-90 transition-colors text-sm">
                        Buy Phone Number
                    </button>
                </div>
            )
        }
        
        // Default actions for dashboard/agents page
        return (
            <div className="hidden md:flex items-center space-x-2">
                 <HeaderButton onClick={() => setIsDemoModalOpen(true)}>
                    <PlayCircle className="w-5 h-5 text-[var(--c-text-secondary)]"/>
                    <span>See Demo</span>
                </HeaderButton>
                 <a href="#" target="_blank" rel="noopener noreferrer">
                    <HeaderButton>
                        <BookText className="w-5 h-5 text-[var(--c-text-secondary)]"/>
                        <span>Docs</span>
                         <ExternalLink className="w-4 h-4 ml-1 text-[var(--c-text-secondary)]"/>
                    </HeaderButton>
                 </a>
                <button 
                    onClick={() => setIsCreatingAgent(true)}
                    className="flex items-center justify-center space-x-2 bg-[var(--c-primary)] text-white font-semibold px-4 py-2.5 rounded-lg hover:opacity-90 transition-colors text-sm">
                    <MessageSquarePlus className="w-5 h-5"/>
                    <span>New Agent</span>
                </button>
            </div>
        );
    }

    return (
        <header className="flex justify-between items-start">
            <div className="flex items-center gap-4">
                <button
                    className="lg:hidden p-2 -ml-2 text-[var(--c-text-strong)]"
                    onClick={() => setIsSidebarOpen(true)}
                    aria-label="Open sidebar"
                >
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7" />
                    </svg>
                </button>
                <div>
                    <h1 className="text-2xl md:text-3xl font-bold text-[var(--c-text-strong)]">{title}</h1>
                    <p className="text-[var(--c-text-secondary)] mt-1">{description}</p>
                </div>
            </div>
            <div className="flex items-center gap-2 md:gap-4">
              {renderHeaderActions()}
              <ThemeToggleButton />
            </div>
        </header>
    );
  }

  const renderContent = () => {
    if (configuringAgent) {
      return (
        <AgentConfiguration 
          key={configuringAgent.id}
          agent={configuringAgent} 
          allAgents={agents} 
          onSelectAgent={handleSelectAgentToConfigure} 
          onUpdateAgent={handleUpdateAgent}
          onDeleteAgent={handleDeleteAgent}
          handleBackToList={() => { setConfiguringAgent(null); setActiveView('agents'); }}
          onStartCreateAgent={() => setIsCreatingAgent(true)}
          onAgentImported={handleImportAgent}
          onSetInbound={handleSetInboundClick}
        />
      );
    }

    switch (activeView) {
      case 'agents':
        return <AgentsPage agents={agents} onSelect={handleSelectAgentToConfigure} />;
      case 'numbers':
        return <PhoneNumbersPage 
                    agents={agents}
                    phoneNumbers={phoneNumbers}
                    twilioConfig={twilioConfig}
                    onConnectTwilio={handleConnectTwilio}
                    onDisconnectTwilio={handleDisconnectTwilio}
                    onLinkAgentToNumber={handleLinkAgentToNumber}
                    onAddPhoneNumber={handleAddPhoneNumber}
                />;
      case 'call-history':
        return <CallHistoryPage callData={callHistory} />;
      case 'campaigns':
        return <CampaignsPage agents={agents} />;
      case 'dashboard':
      default:
        return <DashboardPage callData={callHistory} agents={agents} phoneNumbers={phoneNumbers} twilioConfig={twilioConfig} />;
    }
  };

  return (
    <>
      <div className="flex min-h-screen bg-[var(--c-bg)]">
        {/* Mobile Sidebar */}
        <aside 
            className={`fixed inset-y-0 left-0 z-50 w-72 bg-[var(--c-surface)] text-[var(--c-text-primary)] p-6 flex flex-col border-r border-[var(--c-border)] transition-transform duration-300 ease-in-out lg:hidden ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}
        >
          <button 
            onClick={() => setIsSidebarOpen(false)} 
            className="absolute top-4 right-4 p-2 text-[var(--c-text-secondary)] hover:text-[var(--c-text-strong)]"
            aria-label="Close sidebar"
          >
            <X className="w-6 h-6"/>
          </button>
          <SidebarContent />
        </aside>
        {isSidebarOpen && <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setIsSidebarOpen(false)}></div>}

        {/* Desktop Sidebar */}
        <aside className="w-72 bg-[var(--c-surface)] p-6 flex-col border-r border-[var(--c-border)] fixed h-full hidden lg:flex">
            <SidebarContent />
        </aside>

        <main className="flex-1 p-4 sm:p-6 lg:p-10 lg:ml-72 bg-[var(--c-bg)]">
          {renderHeader()}
          <div className="mt-8">
            {renderContent()}
          </div>
        </main>
      </div>
      {isDemoModalOpen && <DemoModal onClose={() => setIsDemoModalOpen(false)} />}
      {isCreatingAgent && (
        <CreateAgentWizard 
          onClose={() => setIsCreatingAgent(false)} 
          onAgentCreated={handleCreateAgent}
        />
      )}
    </>
  );
};
