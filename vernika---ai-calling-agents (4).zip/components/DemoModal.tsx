import React from 'react';
import { PhoneMockup } from './PhoneMockup';

interface DemoModalProps {
  onClose: () => void;
}

const DemoModal: React.FC<DemoModalProps> = ({ onClose }) => {
  // Prevent clicks inside the modal from closing it
  const handleModalContentClick = (e: React.MouseEvent) => {
    e.stopPropagation();
  };
  
  return (
    <div 
      className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div 
        className="relative w-full max-w-md"
        onClick={handleModalContentClick}
      >
        <button
          onClick={onClose}
          className="absolute -top-2 -right-2 w-9 h-9 bg-white rounded-full text-slate-900 flex items-center justify-center font-bold text-xl z-10 hover:bg-gray-200 transition-colors"
          aria-label="Close demo"
        >
          &times;
        </button>
        <div className="transform scale-90 md:scale-100">
             <PhoneMockup />
        </div>
      </div>
    </div>
  );
};

export default DemoModal;