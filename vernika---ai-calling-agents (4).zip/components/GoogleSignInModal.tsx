
import React, { useState } from 'react';
import { GoogleIcon, Spinner, User } from './IconComponents';
import * as authService from '../services/authService';

interface GoogleSignInModalProps {
  onClose: () => void;
  onLoginSuccess: (email: string) => void;
}

const GoogleSignInModal: React.FC<GoogleSignInModalProps> = ({ onClose, onLoginSuccess }) => {
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  const handleSignIn = async () => {
    setIsAuthenticating(true);
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    try {
      const user = authService.signInWithGoogle();
      onLoginSuccess(user.email);
    } catch (error) {
      console.error("Google sign-in simulation failed", error);
      // Handle error display if necessary
    } finally {
      setIsAuthenticating(false);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div 
        className="bg-[var(--c-surface)] border border-[var(--c-border)] rounded-2xl shadow-xl w-full max-w-sm"
        onClick={(e) => e.stopPropagation()}
        role="dialog" 
        aria-modal="true" 
        aria-labelledby="modal-title"
      >
        <div className="p-6 text-center">
            <GoogleIcon className="w-8 h-8 mx-auto mb-4 text-[#4285F4]"/>
            <h2 id="modal-title" className="text-2xl font-semibold text-[var(--c-text-strong)]">Choose an account</h2>
            <p className="text-sm text-[var(--c-text-secondary)] mt-1">to continue to Vernika</p>
        </div>

        <div className="border-t border-[var(--c-border)] p-4 space-y-2">
            <button
                onClick={handleSignIn}
                disabled={isAuthenticating}
                className="w-full flex items-center gap-4 p-3 rounded-lg hover:bg-[var(--c-bg)] transition-colors text-left disabled:cursor-wait"
            >
                <div className="w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-xl flex-shrink-0">
                    G
                </div>
                <div className="flex-grow">
                    <p className="font-semibold text-[var(--c-text-strong)]">Google User</p>
                    <p className="text-sm text-[var(--c-text-secondary)]">google.user@example.com</p>
                </div>
                {isAuthenticating && <Spinner className="w-5 h-5 text-[var(--c-primary)]" />}
            </button>
            <button className="w-full flex items-center gap-4 p-3 rounded-lg hover:bg-[var(--c-bg)] transition-colors text-left">
                <div className="w-10 h-10 bg-[var(--c-surface)] border-2 border-[var(--c-border)] text-[var(--c-text-secondary)] rounded-full flex items-center justify-center flex-shrink-0">
                    <User className="w-5 h-5" />
                </div>
                <div>
                    <p className="font-semibold text-[var(--c-text-strong)]">Use another account</p>
                </div>
            </button>
        </div>

        <footer className="p-6 border-t border-[var(--c-border)] text-center">
            <p className="text-xs text-[var(--c-text-secondary)]">
                To continue, Google will share your name, email address, and profile picture with Vernika.
            </p>
        </footer>
      </div>
    </div>
  );
};

export default GoogleSignInModal;
