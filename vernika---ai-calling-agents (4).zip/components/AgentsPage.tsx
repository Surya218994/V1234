import React from 'react';
import { Agent } from '../types';
import AgentCard from './AgentCard';

interface AgentsPageProps {
  agents: Agent[];
  onSelect: (agent: Agent) => void;
}

const AgentsPage: React.FC<AgentsPageProps> = ({ agents, onSelect }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8">
      {agents.map((agent, index) => (
        <AgentCard key={agent.id} agent={agent} onSelect={onSelect} index={index} />
      ))}
    </div>
  );
};

export default AgentsPage;