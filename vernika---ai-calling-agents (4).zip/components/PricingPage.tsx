import React from 'react';
import PricingCard from './PricingCard';
import { Page } from '../types';

interface PricingPageProps {
    navigateTo: (page: Page) => void;
}

const pricingTiers = [
    {
        planName: 'Mini',
        price: '₹750',
        description: 'Perfect for a quick test drive or very light usage.',
        features: [
            '50 minutes/month',
            '1 Concurrent Call',
            'Community Support'
        ],
        ctaText: 'Get Started'
    },
    {
        planName: 'Starter',
        price: '₹12,000',
        description: 'For startups and small teams getting started with voice AI.',
        features: [
            '1,000 minutes/month',
            '2 Concurrent Calls',
            'Basic CRM Integration',
            'Email Support'
        ],
        ctaText: 'Get Started'
    },
    {
        planName: 'Pro',
        price: '₹50,000',
        description: 'For growing businesses that need more power and scale.',
        features: [
            '5,000 minutes/month',
            '10 Concurrent Calls',
            'Advanced CRM Integration',
            'Real-time Analytics',
            'Priority Email & Chat Support'
        ],
        isFeatured: true,
        ctaText: 'Choose Plan'
    },
    {
        planName: 'Business',
        price: '₹9,00,000',
        description: 'For large-scale operations with premium requirements.',
        features: [
            '10,000 minutes/month',
            '50 Concurrent Calls',
            'Advanced API Access',
            'Dedicated Onboarding',
            '24/7 Phone Support'
        ],
        ctaText: 'Choose Plan'
    },
    {
        planName: 'Enterprise',
        price: 'Custom',
        description: 'For organizations with unique needs and extreme volume.',
        features: [
            'Custom minute bundles',
            'Unlimited Concurrent Calls',
            'Custom Integrations & Development',
            'Dedicated Account Manager',
            'SLA & HIPAA/PCI Compliance'
        ],
        ctaText: 'Contact Sales'
    }
];

const FAQItem: React.FC<{ question: string, answer: string }> = ({ question, answer }) => (
    <div className="py-6 border-b border-[var(--c-border)] last:border-b-0">
        <dt className="text-lg font-medium text-[var(--c-text-strong)]">{question}</dt>
        <dd className="mt-2 text-base text-[var(--c-text-secondary)]">{answer}</dd>
    </div>
);

const PricingPage: React.FC<PricingPageProps> = ({ navigateTo }) => {
    return (
        <div className="container mx-auto px-4 sm:px-6 py-16 md:py-24">
            <div className="text-center max-w-3xl mx-auto">
                <h1 className="font-serif font-bold tracking-tight text-[var(--c-text-strong)] text-4xl sm:text-5xl md:text-6xl">
                    Find the Plan That's Right for You
                </h1>
                <p className="mt-6 text-lg leading-8 text-[var(--c-text-primary)]">
                    Simple, transparent pricing that scales with your business. No hidden fees.
                </p>
            </div>

            <div className="mt-20 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
                {pricingTiers.map(tier => (
                    <PricingCard key={tier.planName} {...tier} navigateTo={navigateTo} />
                ))}
            </div>

            <div className="mt-24 max-w-4xl mx-auto">
                <h2 className="font-serif font-bold text-center text-[var(--c-text-strong)] text-3xl sm:text-4xl">Frequently Asked Questions</h2>
                <dl className="mt-12 bg-[var(--c-surface)] rounded-2xl p-4 sm:p-6 border border-[var(--c-border)]">
                    <FAQItem
                        question="Can I try Vernika before I buy?"
                        answer="Yes, our new Mini plan is a great way to start with 50 minutes to test the service. You can sign up directly."
                    />
                    <FAQItem
                        question="What happens if I go over my monthly minutes?"
                        answer="We have a pay-as-you-go model for any overages. You'll be charged a small fee per additional minute. You can also upgrade your plan at any time."
                    />
                    <FAQItem
                        question="Can you support languages other than English?"
                        answer="Yes! Our Enterprise plan includes support for multiple languages. Please contact us to discuss your specific language requirements."
                    />
                </dl>
            </div>
        </div>
    );
};

export default PricingPage;