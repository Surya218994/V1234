import React from 'react';

interface ChartCardProps {
  title: string;
  children: React.ReactNode;
  legend?: React.ReactNode;
  actions?: React.ReactNode;
  className?: string;
  gridSpan?: string;
}

const ChartCard: React.FC<ChartCardProps> = ({ title, children, legend, actions, className = '', gridSpan = 'lg:col-span-1' }) => {
  return (
    <div className={`bg-[var(--c-surface)] border border-[var(--c-border)] rounded-xl p-6 flex flex-col ${gridSpan} ${className}`}>
      <div className="flex justify-between items-start mb-4">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-[var(--c-text-strong)]">{title}</h3>
          {legend && <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1">{legend}</div>}
        </div>
        {actions && <div className="flex-shrink-0">{actions}</div>}
      </div>
      <div className="flex-grow h-60">
        {children}
      </div>
    </div>
  );
};

export default ChartCard;