import React from 'react';
import { CallHistoryRecord } from '../../types';
import { X, Bot } from '../IconComponents';

const StatusBadge: React.FC<{ status: CallHistoryRecord['status'] }> = ({ status }) => {
    const statusClasses = {
        Completed: 'bg-green-100 dark:bg-green-500/20 text-green-700 dark:text-green-300',
        Failed: 'bg-red-100 dark:bg-red-500/20 text-red-700 dark:text-red-300',
        'No Answer': 'bg-amber-100 dark:bg-amber-500/20 text-amber-700 dark:text-amber-300',
    };
    return (
        <span className={`px-2 py-0.5 rounded-full text-xs font-semibold inline-flex items-center ${statusClasses[status]}`}>
            {status}
        </span>
    );
};

interface UnsuccessfulCallsModalProps {
  isOpen: boolean;
  onClose: () => void;
  calls: CallHistoryRecord[];
}

const UnsuccessfulCallsModal: React.FC<UnsuccessfulCallsModalProps> = ({ isOpen, onClose, calls }) => {
  if (!isOpen) {
    return null;
  }

  return (
    <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in"
        onClick={onClose}
    >
      <div 
        className="bg-[var(--c-surface)] border border-[var(--c-border)] rounded-2xl shadow-xl w-full max-w-2xl h-[80vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
        role="dialog" 
        aria-modal="true" 
        aria-labelledby="modal-title"
      >
        <header className="flex items-center justify-between p-4 border-b border-[var(--c-border)] flex-shrink-0">
            <h2 id="modal-title" className="text-lg font-semibold text-[var(--c-text-strong)]">
                Unsuccessful Calls
            </h2>
            <button onClick={onClose} className="p-2 rounded-full hover:bg-[var(--c-bg)]">
                <X className="w-5 h-5 text-[var(--c-text-secondary)]" />
            </button>
        </header>

        <main className="flex-grow p-4 overflow-y-auto">
          {calls.length > 0 ? (
            <ul className="space-y-3">
              {calls.map((call) => (
                <li key={call.id} className="bg-[var(--c-bg)] p-3 rounded-lg border border-[var(--c-border)]">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 flex items-center justify-center rounded-full bg-[var(--c-primary)]/10">
                            <Bot className="w-5 h-5 text-[var(--c-primary)]" />
                        </div>
                        <div>
                            <p className="font-semibold text-sm text-[var(--c-text-strong)]">{call.agent.name}</p>
                            <p className="text-xs text-[var(--c-text-secondary)]">{call.contact}</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-4">
                        <p className="text-xs text-[var(--c-text-secondary)]">{new Date(call.timestamp).toLocaleString()}</p>
                        <StatusBadge status={call.status} />
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <div className="text-center py-10">
              <h3 className="font-semibold text-[var(--c-text-strong)]">No Unsuccessful Calls</h3>
              <p className="text-sm text-[var(--c-text-secondary)] mt-1">All recent calls were completed successfully.</p>
            </div>
          )}
        </main>

        <footer className="p-4 border-t border-[var(--c-border)] flex-shrink-0 text-right">
             <button
                type="button"
                className="inline-flex justify-center rounded-md bg-[var(--c-surface)] px-4 py-2 text-sm font-semibold text-[var(--c-text-primary)] shadow-sm ring-1 ring-inset ring-[var(--c-border)] hover:bg-[var(--c-bg)] transition-colors"
                onClick={onClose}
            >
                Close
            </button>
        </footer>
      </div>
    </div>
  );
};

export default UnsuccessfulCallsModal;
