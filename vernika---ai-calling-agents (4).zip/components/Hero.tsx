import React from 'react';

const Hero: React.FC = () => {
  return null;
};

export default Hero;
