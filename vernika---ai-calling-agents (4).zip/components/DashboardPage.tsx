

import React, { useMemo, useState } from 'react';
import ChartCard from './dashboard/ChartCard';
import { Agent, CallHistoryRecord, DropdownOption, PhoneNumber, TwilioConfig } from '../types';
import { CalendarDays, ChevronDown, PhoneForwarded, PlayCircle, Spinner, CheckCircle, AlertTriangle } from './IconComponents';
import UnsuccessfulCallsModal from './dashboard/UnsuccessfulCallsModal';
import Dropdown from './ui/Dropdown';
import AgentTestModal from './agent-configuration/AgentTestModal';
import { useChat } from '../contexts/ChatContext';
import { initiateRealCall } from '../services/twilioService';
import { useTheme } from '../contexts/ThemeContext';


const StatusBadge: React.FC<{ status: CallHistoryRecord['status'] }> = ({ status }) => {
    const { theme } = useTheme();
    const isDark = theme === 'dark';
    const statusClasses = {
        Completed: isDark ? 'bg-green-500/20 text-green-300' : 'bg-green-100 text-green-700',
        Failed: isDark ? 'bg-red-500/20 text-red-300' : 'bg-red-100 text-red-700',
        'No Answer': isDark ? 'bg-amber-500/20 text-amber-300' : 'bg-amber-100 text-amber-700',
    };
    return (
        <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold inline-flex items-center gap-1.5 ${statusClasses[status]}`}>
            {status}
        </span>
    );
};


const MiniChart: React.FC<{
    data: number[];
    color: string;
    dates: string[];
    yLabelFormatter?: (value: number) => string;
}> = ({ data, color, dates, yLabelFormatter = (v) => v.toFixed(0) }) => {
    const width = 200;
    const height = 80;
    const padding = { top: 5, right: 5, bottom: 20, left: 35 };
    const chartWidth = width - padding.left - padding.right;
    const chartHeight = height - padding.top - padding.bottom;
    
    if (data.length === 0) return <div className="w-full h-full flex items-center justify-center text-[var(--c-text-secondary)] text-sm">No data</div>;

    const maxVal = Math.max(...data, 1); // Use 1 as a minimum max to avoid division by zero
    const minVal = 0; // Always start y-axis at 0
    const range = maxVal - minVal;

    const getPath = (d: number[], strokeWidth: number) => 
        d.map((val, i) => {
            const x = d.length > 1 ? (i / (d.length - 1)) * chartWidth : chartWidth / 2;
            const y = chartHeight - ((val - minVal) / (range || 1)) * (chartHeight - strokeWidth);
            return `${i === 0 ? 'M' : 'L'} ${x.toFixed(2)} ${y.toFixed(2)}`;
        }).join(' ');
        
    const path = getPath(data, 2);

    const startDate = dates[0] ? new Date(dates[0]).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : '';
    const endDate = dates[dates.length - 1] ? new Date(dates[dates.length - 1]).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : '';
    
    return (
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full">
            <g transform={`translate(${padding.left}, ${padding.top})`}>
                {/* Y-axis labels */}
                <text x={-padding.left + 5} y={0} dy="0.3em" textAnchor="start" className="text-xs fill-[var(--c-text-secondary)]">
                    {yLabelFormatter(maxVal)}
                </text>
                <text x={-padding.left + 5} y={chartHeight} dy="-0.3em" textAnchor="start" className="text-xs fill-[var(--c-text-secondary)]">
                    {yLabelFormatter(minVal)}
                </text>
                
                {/* X-axis labels */}
                {dates.length > 1 && (
                    <>
                        <text x={0} y={chartHeight + padding.bottom - 5} textAnchor="start" className="text-xs fill-[var(--c-text-secondary)]">
                            {startDate}
                        </text>
                        <text x={chartWidth} y={chartHeight + padding.bottom - 5} textAnchor="end" className="text-xs fill-[var(--c-text-secondary)]">
                            {endDate}
                        </text>
                    </>
                )}

                {/* Chart Area */}
                <defs>
                    <linearGradient id={`gradient-${color.replace('#', '')}`} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={color} stopOpacity={0.3} />
                        <stop offset="100%" stopColor={color} stopOpacity={0} />
                    </linearGradient>
                </defs>
                <path d={path + ` L ${chartWidth} ${height} L 0 ${height} Z`} fill={`url(#gradient-${color.replace('#', '')})`} />
                <path d={path} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </g>
        </svg>
    );
};

const MetricCard: React.FC<{ title: string; value: string; chart: React.ReactNode }> = ({ title, value, chart }) => (
    <div className="bg-[var(--c-surface)] border border-[var(--c-border)] rounded-xl p-6 transition-all duration-300 hover:shadow-md hover:-translate-y-1">
        <p className="text-sm text-[var(--c-text-secondary)]">{title}</p>
        <p className="text-3xl font-bold text-[var(--c-text-strong)] mt-2">{value}</p>
        <div className="h-20 mt-4">{chart}</div>
    </div>
);

type CallState = 'idle' | 'calling' | 'success' | 'error';

interface TestCallCardProps {
    agents: Agent[];
    phoneNumbers: PhoneNumber[];
    twilioConfig: TwilioConfig | null;
}

const TestCallCard: React.FC<TestCallCardProps> = ({ agents, phoneNumbers, twilioConfig }) => {
    const [destinationNumber, setDestinationNumber] = useState('');
    const [selectedAgentId, setSelectedAgentId] = useState<string>(agents.length > 0 ? agents[0].id : '');
    const [selectedFromNumberSid, setSelectedFromNumberSid] = useState<string>(phoneNumbers.length > 0 ? phoneNumbers[0].sid : '');
    const [callState, setCallState] = useState<CallState>('idle');
    const [callError, setCallError] = useState<string | null>(null);

    const handleCallClick = async () => {
        const fromNumber = phoneNumbers.find(n => n.sid === selectedFromNumberSid);
        
        if (!twilioConfig || !fromNumber || !destinationNumber.trim()) {
            alert("Please select a 'from' number and enter a destination number.");
            return;
        }

        setCallState('calling');
        setCallError(null);
        
        try {
            const result = await initiateRealCall({
                to: destinationNumber,
                from: fromNumber.phoneNumber,
                agentId: selectedAgentId,
                twilioConfig,
            });
            console.log("Call initiated with SID:", result.callSid);
            setCallState('success');
            setTimeout(() => setCallState('idle'), 3000); // Reset after 3s
        } catch (error) {
            console.error("Failed to place call:", error);
            setCallError(error instanceof Error ? error.message : "An unknown error occurred.");
            setCallState('error');
        }
    };

    const agentOptions: DropdownOption[] = agents.map(agent => ({
        value: agent.id,
        label: `${agent.name} (${agent.category})`,
    }));
    
    const fromNumberOptions: DropdownOption[] = phoneNumbers.map(num => ({
        value: num.sid,
        label: `${num.friendlyName || 'Unnamed'} (${num.phoneNumber})`,
    }));
    
    const renderButton = () => {
        switch (callState) {
            case 'calling':
                return <><Spinner className="w-5 h-5"/><span>Calling...</span></>;
            case 'success':
                return <><CheckCircle className="w-5 h-5"/><span>Call Initiated!</span></>;
            case 'error':
                 return <><AlertTriangle className="w-5 h-5"/><span>Call Failed</span></>;
            case 'idle':
            default:
                return <><PlayCircle className="w-5 h-5"/><span>Place Live Call</span></>;
        }
    }
    
    const buttonBgClass = {
        idle: 'bg-[var(--c-primary)] hover:opacity-90',
        calling: 'bg-blue-500',
        success: 'bg-green-500',
        error: 'bg-red-500',
    }[callState];

    if (!twilioConfig || phoneNumbers.length === 0) {
        return (
            <ChartCard title="Make a Live Call" gridSpan="lg:col-span-1">
                <div className="h-full flex flex-col items-center justify-center text-center p-4">
                    <PhoneForwarded className="w-12 h-12 text-[var(--c-text-secondary)] mb-4" />
                    <p className="text-sm text-[var(--c-text-secondary)]">Please import a Twilio phone number first to make live calls.</p>
                </div>
            </ChartCard>
        );
    }
    
    return (
        <ChartCard title="Make a Live Call" gridSpan="lg:col-span-1">
            <div className="h-full flex flex-col justify-between space-y-4">
                <div className="space-y-4">
                    <div>
                        <label className="text-xs font-medium text-[var(--c-text-secondary)] mb-1 block">Agent</label>
                        <Dropdown options={agentOptions} value={selectedAgentId} onChange={setSelectedAgentId} />
                    </div>
                    <div>
                        <label className="text-xs font-medium text-[var(--c-text-secondary)] mb-1 block">Call From Number</label>
                        <Dropdown options={fromNumberOptions} value={selectedFromNumberSid} onChange={setSelectedFromNumberSid} />
                    </div>
                    <div>
                        <label className="text-xs font-medium text-[var(--c-text-secondary)] mb-1 block">Your Phone Number</label>
                        <input
                            type="tel"
                            placeholder="+15551234567"
                            value={destinationNumber}
                            onChange={(e) => setDestinationNumber(e.target.value)}
                            className="w-full bg-[var(--c-bg)] border border-[var(--c-border)] rounded-lg px-3 py-2 text-sm text-[var(--c-text-strong)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)]"
                        />
                    </div>
                </div>
                <div className="mt-auto text-center">
                    <button
                        onClick={handleCallClick}
                        disabled={callState === 'calling' || callState === 'success'}
                        className={`w-full flex items-center justify-center gap-2 text-white font-semibold py-2.5 rounded-lg transition-colors duration-300 disabled:opacity-70 ${buttonBgClass}`}
                    >
                        {renderButton()}
                    </button>
                    {callState === 'error' && <p className="text-xs text-red-400 mt-2">{callError}</p>}
                </div>
            </div>
        </ChartCard>
    );
};


interface DashboardPageProps {
  callData: CallHistoryRecord[];
  agents: Agent[];
  phoneNumbers: PhoneNumber[];
  twilioConfig: TwilioConfig | null;
}

export default function DashboardPage({ callData, agents, phoneNumbers, twilioConfig }: DashboardPageProps) {
    const [isUnsuccessfulCallsModalOpen, setIsUnsuccessfulCallsModalOpen] = useState(false);
    const [isTestModalOpen, setIsTestModalOpen] = useState(false);
    const [testModalConfig, setTestModalConfig] = useState<any>(null);

    const { initializeChat, isInitializing, chatError } = useChat();

    const totalMinutes = callData.reduce((sum, call) => sum + call.duration, 0) / 60;
    const numberOfCalls = callData.length;
    const totalSpent = callData.reduce((sum, call) => sum + call.cost, 0);
    const avgCostPerCall = numberOfCalls > 0 ? totalSpent / numberOfCalls : 0;
    
    const { dailyStats, sortedDates } = useMemo(() => {
        const stats: { [key: string]: { calls: number; minutes: number; cost: number; } } = {};
        const dataToProcess = callData.filter(c => c.status === 'Completed');

        dataToProcess.forEach(call => {
            const date = new Date(call.timestamp).toISOString().split('T')[0];
            if (!stats[date]) stats[date] = { calls: 0, minutes: 0, cost: 0 };
            stats[date].calls += 1;
            stats[date].minutes += call.duration / 60;
            stats[date].cost += call.cost;
        });
        const sorted = Object.keys(stats).sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
        return { dailyStats: stats, sortedDates: sorted };
    }, [callData]);

    const callMinutesData = sortedDates.map(date => dailyStats[date]?.minutes || 0);
    const numberOfCallsData = sortedDates.map(date => dailyStats[date]?.calls || 0);
    const totalSpentData = sortedDates.map(date => dailyStats[date]?.cost || 0);
    const avgCostPerCallData = sortedDates.map(date => {
        const day = dailyStats[date];
        return day && day.calls > 0 ? day.cost / day.calls : 0;
    });
    
    const handlePlaceCall = async (agent: Agent) => {
        const config = agent.configuration;
        if (!config) {
            alert("This agent is not configured yet.");
            return;
        }

        try {
            const knowledgeBaseText = ''; 
            
            const initialHistory = [{
                role: "model",
                parts: [{ text: config.conversationStarters || "Hello, how can I help you?" }]
            }];
            
            await initializeChat(config.systemPrompt, knowledgeBaseText, config.quality, initialHistory);
            
            setTestModalConfig({
                agentName: config.agentName,
                agentVoice: config.voice,
                agentAccent: config.accent,
                agentQuality: config.quality,
                initialGreeting: config.conversationStarters,
                initialMode: 'voice',
            });
            setIsTestModalOpen(true);
        } catch (error) {
            console.error("Failed to initialize test session:", error);
            const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
            alert(`Failed to start test call: ${errorMessage}`);
        }
    };
    
    return (
        <>
            <div className="relative animate-fade-in">
                <div className="space-y-8">
                    <div className="flex flex-wrap gap-4 items-center justify-between">
                        <h2 className="text-xl font-bold text-[var(--c-text-strong)]">Metrics Overview</h2>
                        <div className="flex flex-wrap items-center gap-2">
                            <button className="flex items-center space-x-2 bg-[var(--c-surface)] border border-[var(--c-border)] text-[var(--c-text-primary)] px-3 py-1.5 rounded-md text-sm hover:bg-[var(--c-bg)]">
                                <CalendarDays className="w-4 h-4 text-[var(--c-text-secondary)]" />
                                <span>Last 15 Days</span>
                                 <ChevronDown className="w-4 h-4 text-[var(--c-text-secondary)]" />
                            </button>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <MetricCard 
                            title="Total Call Minutes" 
                            value={totalMinutes.toFixed(1)} 
                            chart={<MiniChart data={callMinutesData} color="#10B981" dates={sortedDates} yLabelFormatter={(v) => v.toFixed(0)} />} 
                        />
                        <MetricCard 
                            title="Number of Calls" 
                            value={numberOfCalls.toString()} 
                            chart={<MiniChart data={numberOfCallsData} color="#F59E0B" dates={sortedDates} yLabelFormatter={(v) => v.toFixed(0)}/>} 
                        />
                        <MetricCard 
                            title="Total Spent" 
                            value={`₹${totalSpent.toFixed(2)}`} 
                            chart={<MiniChart data={totalSpentData} color="#8B5CF6" dates={sortedDates} yLabelFormatter={(v) => `₹${v.toFixed(1)}`}/>} 
                        />
                        <MetricCard 
                            title="Avg. Cost per Call" 
                            value={`₹${avgCostPerCall.toFixed(2)}`} 
                            chart={<MiniChart data={avgCostPerCallData} color="#3B82F6" dates={sortedDates} yLabelFormatter={(v) => `₹${v.toFixed(2)}`}/>} 
                        />
                    </div>

                    <div className="pt-4">
                        <h2 className="text-xl font-bold text-[var(--c-text-strong)] mb-6">Quick Actions</h2>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <TestCallCard 
                                agents={agents} 
                                phoneNumbers={phoneNumbers || []}
                                twilioConfig={twilioConfig}
                            />
                            
                             <ChartCard title="Agent Performance" gridSpan="lg:col-span-1">
                                <div className="space-y-3 -m-2 h-full overflow-y-auto pr-2">
                                     <div className="flex items-center justify-center h-full text-sm text-[var(--c-text-secondary)]">
                                        Agent performance chart coming soon.
                                    </div>
                                 </div>
                             </ChartCard>
                        </div>
                    </div>
                </div>
            </div>
            <UnsuccessfulCallsModal 
                isOpen={isUnsuccessfulCallsModalOpen} 
                onClose={() => setIsUnsuccessfulCallsModalOpen(false)}
                calls={callData.filter(c => c.status === 'Failed' || c.status === 'No Answer')}
            />
             {isTestModalOpen && testModalConfig && (
                <AgentTestModal onClose={() => setIsTestModalOpen(false)} config={testModalConfig} />
            )}
        </>
    );
}
