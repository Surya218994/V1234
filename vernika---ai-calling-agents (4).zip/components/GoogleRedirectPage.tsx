import React, { useEffect } from 'react';
import { Spinner, GoogleIcon } from './IconComponents';
import * as authService from '../services/authService';

interface GoogleRedirectPageProps {
    onLoginSuccess: (email: string) => void;
}

const GoogleRedirectPage: React.FC<GoogleRedirectPageProps> = ({ onLoginSuccess }) => {
    useEffect(() => {
        const timer = setTimeout(() => {
            try {
                // Simulate the sign-in process
                const user = authService.signInWithGoogle();
                onLoginSuccess(user.email);
            } catch (error) {
                // In a real app, you might redirect back to login with an error message
                console.error("Google sign-in simulation failed", error);
                // For this app, we'll just log the user in anyway for demo purposes.
                const user = authService.signInWithGoogle();
                onLoginSuccess(user.email);
            }
        }, 2000); // 2-second delay to simulate redirect

        return () => clearTimeout(timer); // Cleanup on unmount
    }, [onLoginSuccess]);

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-[var(--c-bg)] text-center px-4">
            <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-lg mb-8 animate-fade-in">
               <GoogleIcon className="w-10 h-10"/>
            </div>
            <h1 className="text-3xl font-bold text-[var(--c-text-strong)] mb-4 animate-fade-in-up" style={{animationDelay: '100ms'}}>Redirecting to Google...</h1>
            <p className="text-[var(--c-text-secondary)] mb-8 animate-fade-in-up" style={{animationDelay: '200ms'}}>Please wait while we securely sign you in.</p>
            <Spinner className="w-10 h-10 text-[var(--c-primary)] animate-fade-in-up" style={{animationDelay: '300ms'}} />
        </div>
    );
};

export default GoogleRedirectPage;