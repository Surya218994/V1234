import React, { useState, useMemo, useRef } from 'react';
import { ChevronsUpDown, Download, ColumnsIcon, ChevronsLeft, ChevronLeft, ChevronRight, ChevronsRight, ExternalLink, PlayCircle, MessageSquareText, MoreVertical, Search, PauseCircle } from './IconComponents';
import { CallHistoryRecord } from '../types';

const StatusBadge: React.FC<{ status: CallHistoryRecord['status'] }> = ({ status }) => {
    const statusClasses = {
        Completed: 'bg-green-100 dark:bg-green-500/20 text-green-700 dark:text-green-300',
        Failed: 'bg-red-100 dark:bg-red-500/20 text-red-700 dark:text-red-300',
        'No Answer': 'bg-amber-100 dark:bg-amber-500/20 text-amber-700 dark:text-amber-300',
    };
    return (
        <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold inline-flex items-center gap-1.5 ${statusClasses[status]}`}>
            {status}
        </span>
    );
};

const Pagination: React.FC<{
    currentPage: number;
    totalPages: number;
    onPageChange: (page: number) => void;
}> = ({ currentPage, totalPages, onPageChange }) => {
    if (totalPages <= 1) return null;
    return (
        <div className="flex items-center gap-4 text-[var(--c-text-secondary)]">
            <span>Page {currentPage} of {totalPages}</span>
            <div className="flex items-center gap-1">
                <button onClick={() => onPageChange(1)} disabled={currentPage === 1} className="p-2 rounded-md hover:bg-[var(--c-bg)] disabled:opacity-50 disabled:cursor-not-allowed"><ChevronsLeft className="w-5 h-5" /></button>
                <button onClick={() => onPageChange(currentPage - 1)} disabled={currentPage === 1} className="p-2 rounded-md hover:bg-[var(--c-bg)] disabled:opacity-50 disabled:cursor-not-allowed"><ChevronLeft className="w-5 h-5" /></button>
                <button onClick={() => onPageChange(currentPage + 1)} disabled={currentPage === totalPages} className="p-2 rounded-md hover:bg-[var(--c-bg)] disabled:opacity-50 disabled:cursor-not-allowed"><ChevronRight className="w-5 h-5" /></button>
                <button onClick={() => onPageChange(totalPages)} disabled={currentPage === totalPages} className="p-2 rounded-md hover:bg-[var(--c-bg)] disabled:opacity-50 disabled:cursor-not-allowed"><ChevronsRight className="w-5 h-5" /></button>
            </div>
        </div>
    );
};

interface CallHistoryPageProps {
  callData: CallHistoryRecord[];
}

const CallHistoryPage: React.FC<CallHistoryPageProps> = ({ callData }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [playingCallId, setPlayingCallId] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  
  const filteredData = useMemo(() => {
    return callData.filter(record => 
        record.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        record.contact.toLowerCase().includes(searchTerm.toLowerCase()) ||
        record.agent.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm, callData]);

  const totalRecords = filteredData.length;
  const totalPages = Math.ceil(totalRecords / rowsPerPage);
  
  const paginatedData = useMemo(() => {
    if (totalRecords === 0) return [];
    return filteredData.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage);
  }, [filteredData, currentPage, rowsPerPage]);

  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    } else if (page < 1) {
        setCurrentPage(1);
    } else {
        setCurrentPage(totalPages);
    }
  };

  const handlePlayPause = (callId: string) => {
    if (playingCallId === callId) {
      audioRef.current?.pause();
      setPlayingCallId(null);
    } else {
      audioRef.current?.pause();
      setPlayingCallId(callId);
      
      if (!audioRef.current) {
        audioRef.current = new Audio();
        audioRef.current.onended = () => setPlayingCallId(null);
        audioRef.current.onerror = () => {
          console.error("Audio playback error");
          setPlayingCallId(null);
        };
      }
      // Use a mock audio file for demonstration
      audioRef.current.src = `https://storage.googleapis.com/aai-assets-prod/mock-call-recording.mp3`;
      audioRef.current.play().catch(e => console.error("Error playing audio:", e));
    }
  };
  
  // Reset page if filtered data changes
  React.useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm]);
  
  const headers = ['AGENT', 'CONTACT', 'DURATION', 'COST', 'STATUS', 'TIMESTAMP', 'SUMMARY', 'ACTIONS'];

  return (
    <div className="bg-[var(--c-surface)] border border-[var(--c-border)] rounded-2xl animate-fade-in">
        <div className="p-4 flex flex-wrap items-center justify-between gap-4 border-b border-[var(--c-border)]">
            <div className="relative flex-grow sm:flex-grow-0">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--c-text-secondary)]"/>
                <input
                    type="text"
                    placeholder="Search by agent, contact..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full sm:w-80 bg-[var(--c-bg)] border border-[var(--c-border)] rounded-lg pl-10 pr-4 py-2 text-[var(--c-text-strong)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)]"
                />
            </div>
            <div className="flex items-center gap-2">
                <button className="flex items-center gap-2 px-3 py-2 rounded-md hover:bg-[var(--c-bg)] text-[var(--c-text-primary)] text-sm font-medium border border-[var(--c-border)]">
                    <ColumnsIcon className="w-4 h-4 text-[var(--c-text-secondary)]"/>
                    <span>View</span>
                </button>
                 <button className="flex items-center gap-2 px-3 py-2 rounded-md hover:bg-[var(--c-bg)] text-[var(--c-text-primary)] text-sm font-medium border border-[var(--c-border)]">
                    <Download className="w-4 h-4 text-[var(--c-text-secondary)]"/>
                    <span>Export</span>
                </button>
            </div>
        </div>

        <div className="overflow-x-auto">
            <table className="w-full text-sm text-left text-[var(--c-text-secondary)] min-w-[1024px]">
                <thead className="text-xs text-[var(--c-text-secondary)] uppercase bg-[var(--c-bg)]">
                    <tr>
                        {headers.map(header => (
                            <th key={header} scope="col" className="px-6 py-4 font-medium whitespace-nowrap">
                                <div className="flex items-center gap-2">
                                    {header}
                                    <ChevronsUpDown className="w-3 h-3"/>
                                </div>
                            </th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {paginatedData.length > 0 ? paginatedData.map(record => (
                        <tr key={record.id} className="border-b border-[var(--c-border)] hover:bg-[var(--c-bg)]">
                            <td className="px-6 py-4 font-medium text-[var(--c-text-strong)]">{record.agent.name}</td>
                            <td className="px-6 py-4">{record.contact}</td>
                            <td className="px-6 py-4">{(record.duration / 60).toFixed(1)} min</td>
                            <td className="px-6 py-4">₹{record.cost.toFixed(2)}</td>
                            <td className="px-6 py-4"><StatusBadge status={record.status} /></td>
                            <td className="px-6 py-4">{new Date(record.timestamp).toLocaleString()}</td>
                            <td className="px-6 py-4 max-w-xs truncate">{record.summary}</td>
                            <td className="px-6 py-4">
                                <div className="flex items-center gap-2">
                                    <button onClick={() => handlePlayPause(record.id)} className="p-1.5 rounded-md hover:bg-[var(--c-surface)] text-[var(--c-text-secondary)]">
                                        {playingCallId === record.id ? <PauseCircle className="w-5 h-5 text-[var(--c-primary)]" /> : <PlayCircle className="w-5 h-5" />}
                                    </button>
                                    <button className="p-1.5 rounded-md hover:bg-[var(--c-surface)] text-[var(--c-text-secondary)]">
                                        <MessageSquareText className="w-5 h-5" />
                                    </button>
                                     <button className="p-1.5 rounded-md hover:bg-[var(--c-surface)] text-[var(--c-text-secondary)]">
                                        <MoreVertical className="w-5 h-5" />
                                    </button>
                                </div>
                            </td>
                        </tr>
                    )) : (
                        <tr>
                            <td colSpan={headers.length} className="text-center py-20 px-6">
                                <h3 className="text-lg font-semibold text-[var(--c-text-strong)]">No Records Found</h3>
                                <p className="text-[var(--c-text-secondary)] mt-1">
                                    {searchTerm ? 'Try adjusting your search terms.' : 'There is no call history to display yet.'}
                                </p>
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>

        <div className="p-4 flex flex-wrap items-center justify-between gap-4">
            <span className="text-sm text-[var(--c-text-secondary)]">{totalRecords} results</span>
            <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
        </div>
    </div>
  );
};

export default CallHistoryPage;