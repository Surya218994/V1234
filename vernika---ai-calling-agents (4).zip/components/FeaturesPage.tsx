import React from 'react';
import { FeatureCard } from './FeatureCard';
import { MessageCircle, TrendingUp, BarChart, Globe, ShieldCheck, Plug, Server, Clock } from './IconComponents';

const features = [
    {
        icon: <MessageCircle className="w-6 h-6"/>,
        title: "Human-like Conversations",
        description: "Powered by Gemini, Vernika engages customers with natural, empathetic, and context-aware conversations that build rapport."
    },
    {
        icon: <Clock className="w-6 h-6"/>,
        title: "24/7 Availability",
        description: "Provide round-the-clock support and sales outreach to your customers across all time zones, without any human intervention."
    },
    {
        icon: <Server className="w-6 h-6"/>,
        title: "Infinite Scalability",
        description: "Effortlessly handle call volume spikes during peak hours or marketing campaigns without compromising on quality or wait times."
    },
    {
        icon: <TrendingUp className="w-6 h-6"/>,
        title: "Significant Cost Reduction",
        description: "Automate routine calls and qualify leads, reducing reliance on large teams and leading to massive savings in operational costs."
    },
    {
        icon: <Plug className="w-6 h-6"/>,
        title: "Seamless CRM Integration",
        description: "Connect Vernika with your existing CRM and backend systems to provide personalized service and log all interactions automatically."
    },
    {
        icon: <BarChart className="w-6 h-6"/>,
        title: "Real-time Analytics",
        description: "Gain valuable insights from call transcripts, success rates, and sentiment analysis with a powerful analytics dashboard."
    },
    {
        icon: <Globe className="w-6 h-6"/>,
        title: "Multilingual Support",
        description: "Serve a global audience by deploying agents that can communicate in multiple languages, expanding your market reach."
    },
    {
        icon: <ShieldCheck className="w-6 h-6"/>,
        title: "Secure & Compliant",
        description: "Ensure all conversations are secure and compliant with industry standards, building trust with your customers."
    }
];

const FeaturesPage: React.FC = () => {
    return (
        <div className="container mx-auto px-4 sm:px-6 py-16 md:py-24">
            <div className="text-center max-w-3xl mx-auto">
                <h1 className="font-serif font-bold tracking-tight text-[var(--c-text-strong)] text-4xl sm:text-5xl md:text-6xl">
                    Powerful Features Built for Performance
                </h1>
                <p className="mt-6 text-lg leading-8 text-[var(--c-text-primary)]">
                    Vernika comes packed with enterprise-grade features designed to supercharge your business communication from day one.
                </p>
            </div>
            <div className="mt-20 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {features.map(feature => (
                    <FeatureCard key={feature.title} icon={feature.icon} title={feature.title} description={feature.description} />
                ))}
            </div>
        </div>
    );
};

export default FeaturesPage;