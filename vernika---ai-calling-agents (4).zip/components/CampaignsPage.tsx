import React, { useState } from 'react';
import { Plus, Target } from './IconComponents';
import CreateCampaignWizard from './campaigns/CreateCampaignWizard';
import { Agent } from '../types';

interface CampaignsPageProps {
  agents: Agent[];
}

export default function CampaignsPage({ agents }: CampaignsPageProps) {
  const [isCreating, setIsCreating] = useState(false); 
  const [campaigns, setCampaigns] = useState<any[]>([]); 

  if (isCreating) {
    return <CreateCampaignWizard onBack={() => setIsCreating(false)} agents={agents} />;
  }
  
  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex flex-wrap gap-4 justify-between items-center">
        <div className="flex items-center gap-4">
          <input 
            type="text"
            placeholder="Search campaigns..."
            className="bg-[var(--c-surface)] border border-[var(--c-border)] rounded-lg px-4 py-2.5 text-[var(--c-text-strong)] placeholder:text-[var(--c-text-secondary)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)] w-full sm:w-80"
          />
        </div>
        <button 
          onClick={() => setIsCreating(true)}
          className="flex items-center gap-2 bg-[var(--c-primary)] text-white font-semibold py-2.5 px-5 rounded-lg hover:opacity-90 transition-colors w-full sm:w-auto justify-center">
            <Plus className="w-5 h-5" />
            <span>Create New Campaign</span>
        </button>
      </div>

      {campaigns.length === 0 ? (
        <div className="text-center py-20 px-6 bg-[var(--c-surface)] border-2 border-dashed border-[var(--c-border)] rounded-2xl">
            <div className="max-w-md mx-auto">
              <div className="mx-auto w-24 h-24 flex items-center justify-center bg-[var(--c-bg)] rounded-full">
                <Target className="w-12 h-12 text-[var(--c-text-secondary)]" />
              </div>
              <h3 className="text-xl font-semibold text-[var(--c-text-strong)] mt-6">No campaigns running</h3>
              <p className="text-[var(--c-text-secondary)] mt-2">Get started by creating your first campaign to engage with your candidates or customers.</p>
              <button 
                onClick={() => setIsCreating(true)}
                className="mt-6 flex items-center mx-auto gap-2 bg-[var(--c-primary)] text-white font-semibold py-2.5 px-5 rounded-lg hover:opacity-90 transition-colors">
                  <Plus className="w-5 h-5" />
                  <span>Create a Campaign</span>
              </button>
            </div>
        </div>
      ) : (
        <div> {/* Table of campaigns would go here */} </div>
      )}
    </div>
  );
};