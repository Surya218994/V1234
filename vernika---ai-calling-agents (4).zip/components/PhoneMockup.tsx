
// --- Web Speech API Type Definitions for TypeScript ---
// These interfaces are based on the MDN documentation for the Web Speech API.
// They are provided here to resolve TypeScript errors in environments
// where these types are not available by default.

declare global {
  interface SpeechRecognitionResult {
      readonly isFinal: boolean;
      readonly length: number;
      item(index: number): SpeechRecognitionAlternative;
      [index: number]: SpeechRecognitionAlternative;
  }

  interface SpeechRecognitionResultList {
      readonly length: number;
      item(index: number): SpeechRecognitionResult;
      [index: number]: SpeechRecognitionResult;
  }

  interface SpeechRecognitionAlternative {
      readonly transcript: string;
      readonly confidence: number;
  }

  interface SpeechRecognitionEvent extends Event {
      readonly resultIndex: number;
      readonly results: SpeechRecognitionResultList;
  }

  type SpeechRecognitionErrorCode =
      | 'no-speech'
      | 'aborted'
      | 'audio-capture'
      | 'network'
      | 'not-allowed'
      | 'service-not-allowed'
      | 'bad-grammar'
      | 'language-not-supported';

  interface SpeechRecognitionErrorEvent extends Event {
      readonly error: SpeechRecognitionErrorCode;
      readonly message: string;
  }

  interface SpeechRecognition extends EventTarget {
      continuous: boolean;
      interimResults: boolean;
      lang: string;
      onend: (() => void) | null;
      onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
      onresult: ((event: SpeechRecognitionEvent) => void) | null;

      abort(): void;
      start(): void;
      stop(): void;
  }

  // Augmenting the Window interface to include SpeechRecognition API properties.
  interface Window {
      SpeechRecognition?: {
          prototype: SpeechRecognition;
          new(): SpeechRecognition;
      };
      webkitSpeechRecognition?: {
          prototype: SpeechRecognition;
          new(): SpeechRecognition;
      };
  }
}
// --- End of Type Definitions ---

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { CallStatus, Message } from '../types';
import { isGeminiApiKeyConfigured, sendMessageToAgentStream } from '../services/geminiService';
import { useChat } from '../contexts/ChatContext';
import { Phone, PhoneOff, Mic, Bot, User, AlertTriangle, Send, MessageSquareText } from './IconComponents';
import { synthesizeSpeech, stopSpeech as stopTts } from '../services/ttsService';

const sanitizeTextForSpeech = (text: string): string => {
  if (!text) return '';
  return text.replace(/\*\*(.*?)\*\*/g, '$1').replace(/\*(.*?)\*/g, '$1').replace(/^\s*\d+\.\s*/gm, '').replace(/^\s*(\*|-)\s/gm, '').replace(/\*/g, '').replace(/\s+/g, ' ').trim();
};

const AgentTypingIndicator: React.FC = () => (
  <div className="flex items-center space-x-2 p-2">
    <Bot className="w-5 h-5 text-[var(--c-primary)]" />
    <div className="flex items-center space-x-1">
        <span className="text-sm text-[var(--c-text-secondary)]">Vernika is thinking</span>
        <div className="flex space-x-1 items-end h-4">
            <span className="w-1 h-1 bg-[var(--c-primary)] rounded-full animate-bounce [animation-delay:-0.3s]"></span>
            <span className="w-1 h-1 bg-[var(--c-primary)] rounded-full animate-bounce [animation-delay:-0.15s]"></span>
            <span className="w-1 h-1 bg-[var(--c-primary)] rounded-full animate-bounce"></span>
        </div>
    </div>
  </div>
);

const MarkdownRenderer: React.FC<{ text: string }> = ({ text }) => {
    const listRegex = /^\s*(\*)\s+/;
    const processLine = (line: string, key: number) => {
      let content = line;
      const isListItem = listRegex.test(content);
      if (isListItem) content = content.replace(listRegex, '');
      const parts = content.split(/(\*\*.*?\*\*|\*.*?\*)/g).filter(Boolean);
      const renderedParts = parts.map((part, j) => {
        if (part.startsWith('**') && part.endsWith('**')) return <strong key={j}>{part.slice(2, -2)}</strong>;
        if (part.startsWith('*') && part.endsWith('*')) return <em key={j}>{part.slice(1, -1)}</em>;
        return <span key={j}>{part}</span>;
      });
      if (isListItem) {
        return <div key={key} className="flex items-start"><span className="mr-2">•</span><div className="flex-1">{renderedParts}</div></div>;
      }
      return <p key={key}>{renderedParts}</p>;
    };
    return <div className="text-sm space-y-1">{text.split('\n').map((line, i) => processLine(line, i))}</div>;
};

const MessageBubble: React.FC<{ message: Message }> = ({ message }) => {
    const isAgent = message.sender === 'agent';
    return (
        <div className={`flex items-start gap-2.5 ${isAgent ? 'justify-start' : 'justify-end'}`}>
            {isAgent && <Bot className="w-5 h-5 text-[var(--c-text-secondary)] flex-shrink-0 mt-1" />}
            <div className={`max-w-[80%] rounded-2xl px-4 py-2 ${isAgent ? 'bg-[var(--c-border)] rounded-bl-none text-[var(--c-text-strong)]' : 'bg-[var(--c-primary)] rounded-br-none text-white'}`}>
                {isAgent ? <MarkdownRenderer text={message.text} /> : <p className="text-sm">{message.text}</p>}
            </div>
             {!isAgent && <User className="w-5 h-5 text-[var(--c-text-secondary)] flex-shrink-0 mt-1" />}
        </div>
    );
};

type TurnState = 'user' | 'agent' | 'agent-ending-turn';
type InteractionMode = 'voice' | 'chat';

interface PhoneMockupProps {
  initialGreeting?: string;
  defaultInteractionMode?: InteractionMode;
  agentAccent?: string; // This is the browser voice name
  agentVoice?: string; // This is the Google voice name
  agentQuality?: 'low' | 'medium' | 'high';
  systemInstruction?: string;
}

export const PhoneMockup: React.FC<PhoneMockupProps> = ({ 
  initialGreeting, 
  defaultInteractionMode = 'voice',
  agentAccent = '',
  agentVoice = '',
  agentQuality = 'medium',
  systemInstruction,
}) => {
  const [isGeminiApiReady, setIsGeminiApiReady] = useState(false);
  const [callStatus, setCallStatus] = useState<CallStatus>(CallStatus.IDLE);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isAgentThinking, setIsAgentThinking] = useState(false);
  const [isAgentSpeaking, setIsAgentSpeaking] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [playbackQueue, setPlaybackQueue] = useState<string[]>([]);
  const [turn, setTurn] = useState<TurnState>('agent');
  const [statusMessage, setStatusMessage] = useState('');
  const [interactionMode, setInteractionMode] = useState<InteractionMode>(defaultInteractionMode);
  const [textInput, setTextInput] = useState('');
  
  const { chat, isInitializing, chatError, initializeChat, endChat } = useChat();

  const messageContainerRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<number | null>(null);
  const agentMessageIdRef = useRef<string | null>(null);
  const speechBufferRef = useRef<string>("");
  const userHasScrolledUpRef = useRef(false);
  
  // --- STT Refs ---
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const isListeningRef = useRef(false);
  
  useEffect(() => setIsGeminiApiReady(isGeminiApiKeyConfigured()), []);

  const SCROLL_THRESHOLD = 50;
  const handleScroll = useCallback(() => {
    const el = messageContainerRef.current;
    if (el) userHasScrolledUpRef.current = el.scrollHeight - el.scrollTop - el.clientHeight > SCROLL_THRESHOLD;
  }, []);
  const scrollToBottom = useCallback((behavior: 'smooth' | 'auto' = 'smooth') => {
    if (messageContainerRef.current) messageContainerRef.current.scrollTo({ top: messageContainerRef.current.scrollHeight, behavior });
  }, []);
  const formatDuration = (s: number) => `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;
  
  const stopAgentSpeech = useCallback(() => {
    stopTts();
    setIsAgentSpeaking(false);
  }, []);
  
    // --- STT Management ---
  const stopListening = useCallback(() => {
    isListeningRef.current = false;
    if (recognitionRef.current) {
        recognitionRef.current.stop();
        recognitionRef.current = null;
    }
  }, []);

  const speak = useCallback(async (text: string) => {
    const cleanText = sanitizeTextForSpeech(text);
    if (!cleanText) return;

    stopListening();
    setIsAgentSpeaking(true);
    setStatusMessage('Speaking...');

    synthesizeSpeech({
      text: cleanText,
      quality: agentQuality,
      voice: agentVoice,
      accent: agentAccent,
      handlers: {
        onEnd: () => setIsAgentSpeaking(false),
        onError: (e) => {
            console.error("Audio playback error:", e);
            const errorMessage = typeof e === 'string' ? e : "Sorry, I'm having trouble speaking right now.";
            setMessages(prev => [...prev, { id: 'tts-error', sender: 'agent', text: errorMessage }]);
            setIsAgentSpeaking(false);
        },
      }
    });
  }, [stopListening, agentQuality, agentVoice, agentAccent]);

  const processUserMessage = useCallback(async (transcript: string) => {
    if (!transcript.trim() || !chat) return;
    setTurn('agent');
    const newUserMessage: Message = { id: Date.now().toString(), sender: 'user', text: transcript };
    setMessages(prev => [...prev, newUserMessage]);
    setIsAgentThinking(true);
    agentMessageIdRef.current = (Date.now() + 1).toString();
    const newAgentMessage: Message = { id: agentMessageIdRef.current, sender: 'agent', text: "" };
    setMessages(prev => [...prev, newAgentMessage]);
    speechBufferRef.current = "";

    try {
        const stream = await sendMessageToAgentStream(chat, transcript);
        setIsAgentThinking(false);
        for await (const chunk of stream) {
            if (chunk.text) {
                setMessages(prev => prev.map(msg => msg.id === agentMessageIdRef.current ? { ...msg, text: msg.text + chunk.text } : msg));
                
                if (interactionMode === 'voice') {
                    speechBufferRef.current += chunk.text;
                    const sentencesToAdd = [];
                    let lastIndex = 0;

                    const sentenceEndRegex = /[^.!?।]+[.!?।](\s|$)/g;
                    let match;
                    
                    while ((match = sentenceEndRegex.exec(speechBufferRef.current)) !== null) {
                        sentencesToAdd.push(match[0].trim());
                        lastIndex = match.index + match[0].length;
                    }
                    
                    if (sentencesToAdd.length > 0) {
                        setPlaybackQueue(prev => [...prev, ...sentencesToAdd]);
                        speechBufferRef.current = speechBufferRef.current.substring(lastIndex);
                    }
                }
            }
        }

        if (interactionMode === 'voice' && speechBufferRef.current.trim()) {
            setPlaybackQueue(prev => [...prev, speechBufferRef.current.trim()]);
            speechBufferRef.current = "";
        }
    } catch (error) {
        console.error('Error processing stream:', error);
        const errorMessageText = 'I seem to be having some trouble. Please try again.';
        setMessages(prev => prev.map(msg => msg.id === agentMessageIdRef.current ? { ...msg, text: errorMessageText } : msg));
        setIsAgentThinking(false);
        if (interactionMode === 'voice') setPlaybackQueue(prev => [...prev, errorMessageText]);
    } finally {
      if (interactionMode !== 'voice') setTurn('user');
    }
  }, [interactionMode, chat]);

  const handleSendTextMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    const transcript = textInput.trim();
    if (!transcript || isAgentThinking || isAgentSpeaking) return;
    setTextInput('');
    await processUserMessage(transcript);
  };
  
  const handleTranscription = useCallback(async (transcript: string) => {
    if (turn !== 'user' || !transcript.trim()) return;
    await processUserMessage(transcript);
  }, [processUserMessage, turn]);
  

  const startListening = useCallback(() => {
    if (isListeningRef.current || recognitionRef.current) return;
    isListeningRef.current = true;
    
    const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognitionAPI) {
        console.error("Speech Recognition not supported.");
        setStatusMessage("Voice not supported.");
        isListeningRef.current = false;
        return;
    }

    const recognition = new SpeechRecognitionAPI();
    recognitionRef.current = recognition;
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onresult = (event: SpeechRecognitionEvent) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
            if (event.results[i].isFinal) finalTranscript += event.results[i][0].transcript;
        }
        if (finalTranscript.trim()) handleTranscription(finalTranscript.trim());
    };

    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
        if (['aborted', 'no-speech', 'network'].includes(event.error)) return;
        console.error("Speech recognition error:", event.error, event.message);
        setStatusMessage(`Mic error: ${event.error}`);
    };

    recognition.onend = () => {
        recognitionRef.current = null;
        if (isListeningRef.current) {
             startListening();
        }
    };
    
    recognition.start();

  }, [handleTranscription]);
  
  useEffect(() => {
    const setupChatSession = async () => {
      if (chat && !isInitializing && !chatError) {
        setCallStatus(CallStatus.ACTIVE);
        const history = await chat.getHistory();
        const initialMessages: Message[] = history
          .filter(h => h.role === 'model' || h.role === 'user')
          .filter(h => !h.parts.some(p => p.text?.startsWith('CONTEXT:') || p.text?.startsWith('OK, I have read the context')))
          .map((h, i) => ({ id: `hist-${i}`, sender: h.role === 'model'?'agent':'user', text: h.parts.map(p => p.text).join('') }));

        setMessages(initialMessages);
        const firstAgentMessage = initialMessages.find(m => m.sender === 'agent');
        if (interactionMode === 'voice' && firstAgentMessage) {
            setPlaybackQueue(prev => [...prev, firstAgentMessage.text]);
        } else if (interactionMode === 'chat') {
            setTurn('user');
        }
      } else if (isInitializing) {
        setMessages([]);
        setCallStatus(CallStatus.CONNECTING);
      } else if (chatError) {
        setCallStatus(CallStatus.IDLE);
        setMessages([{ id: 'error', sender: 'agent', text: `Connection failed: ${chatError}` }]);
      }
    };
    setupChatSession();
  }, [chat, isInitializing, chatError, interactionMode]);

  useEffect(() => {
    if (callStatus === CallStatus.ACTIVE) {
        setCallDuration(0);
        timerRef.current = window.setInterval(() => setCallDuration(p => p + 1), 1000);
    } else if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [callStatus]);

  useEffect(() => {
    return () => { stopAgentSpeech(); stopListening(); };
  }, [stopAgentSpeech, stopListening]);

  const handleStartSessionClick = useCallback(() => {
    if (!isGeminiApiReady || isInitializing) return;
    const greetingText = initialGreeting || "Hello! I'm Vernika. How can I help?";
    const history = [{ role: "model", parts: [{ text: greetingText }] }];
    initializeChat(systemInstruction, undefined, agentQuality, history);
  }, [isGeminiApiReady, isInitializing, initializeChat, initialGreeting, systemInstruction, agentQuality]);

  const handleHangUpClick = () => {
    endChat(); setCallStatus(CallStatus.ENDED); stopAgentSpeech(); stopListening(); setPlaybackQueue([]); setTextInput('');
  };
  const handleRestart = () => {
    endChat(); setCallStatus(CallStatus.IDLE); setMessages([]); setCallDuration(0); setTextInput(''); setInteractionMode(defaultInteractionMode);
  }
  const handleModeChange = (mode: InteractionMode) => {
    if (mode === interactionMode) return;
    setInteractionMode(mode);
    if (mode === 'chat') { stopAgentSpeech(); setPlaybackQueue([]); }
  }
  
  useEffect(() => {
    if (callStatus === CallStatus.ACTIVE && interactionMode === 'voice' && turn === 'user' && !isAgentSpeaking && !isAgentThinking) startListening();
    else stopListening();
  }, [callStatus, interactionMode, turn, isAgentSpeaking, isAgentThinking, startListening, stopListening]);

  useEffect(() => {
    if (turn === 'agent-ending-turn') {
        const timer = setTimeout(() => setTurn('user'), 300);
        return () => clearTimeout(timer);
    }
  }, [turn]);

  useEffect(() => {
    const processQueue = () => {
        if (interactionMode === 'voice' && playbackQueue.length > 0 && !isAgentSpeaking) {
            const nextSentence = playbackQueue[0];
            setPlaybackQueue(prev => prev.slice(1));
            speak(nextSentence);
        } else if (playbackQueue.length === 0 && !isAgentSpeaking && turn === 'agent') {
            setTurn('agent-ending-turn');
        }
    };
    processQueue();
  }, [playbackQueue, isAgentSpeaking, speak, turn, interactionMode]);

  useEffect(() => {
    const lastMessage = messages[messages.length - 1];
    if (lastMessage?.sender === 'user') userHasScrolledUpRef.current = false;
    if (!userHasScrolledUpRef.current) scrollToBottom();
  }, [messages, isAgentThinking, scrollToBottom]);
  
  useEffect(() => {
    if (callStatus !== CallStatus.ACTIVE) return;
    if (interactionMode === 'voice') {
      if (turn === 'agent') setStatusMessage(isAgentThinking ? 'Vernika is thinking...' : 'Speaking...');
      else setStatusMessage('Listening...');
    } else if (!statusMessage.startsWith('Connection issue')) setStatusMessage('');
  }, [turn, isAgentThinking, isAgentSpeaking, callStatus, interactionMode, statusMessage]);

  const renderContent = () => {
    if (!isGeminiApiReady) {
      return <div className="flex flex-col items-center justify-center h-full text-center p-4"><AlertTriangle className="w-14 h-14" style={{ color: 'var(--color-warning)' }} /><h3 className="mt-4 text-xl font-semibold text-[var(--c-text-strong)]">Service Not Configured</h3><p className="mt-2 text-[var(--c-text-secondary)]">The Gemini API key is not set. Please configure it.</p></div>;
    }
    if (callStatus === CallStatus.CONNECTING) {
      return <div className="flex flex-col items-center justify-center h-full text-[var(--c-text-strong)]"><div className="animate-pulse flex items-center space-x-3"><div className="w-3 h-3 bg-green-400 rounded-full"></div><div className="w-3 h-3 bg-green-400 rounded-full animate-pulse [animation-delay:0.2s]"></div><div className="w-3 h-3 bg-green-400 rounded-full animate-pulse [animation-delay:0.4s]"></div></div><p className="mt-4 text-lg">Connecting...</p></div>;
    }
    if (callStatus === CallStatus.IDLE) {
       return <div className="flex flex-col items-center justify-center h-full">{chatError ? <div className="text-center p-4"><AlertTriangle className="w-14 h-14 mx-auto" style={{ color: 'var(--color-danger)' }} /><h3 className="mt-4 text-lg font-semibold text-[var(--c-text-strong)]">Connection Failed</h3><p className="mt-2 text-sm text-[var(--c-text-secondary)] max-w-xs">{chatError}</p><button onClick={handleRestart} className="mt-6 bg-blue-500 hover:bg-blue-600 text-white font-semibold px-6 py-2 rounded-lg transition-colors">Try Again</button></div> : <><button onClick={handleStartSessionClick} className="bg-green-500 hover:bg-green-600 text-white rounded-full p-5 transition-all transform hover:scale-105 shadow-lg shadow-green-500/30" aria-label="Start voice call" disabled={isInitializing}><Phone className="w-9 h-9" /></button><p className="mt-6 text-[var(--c-text-primary)] font-medium">Tap to start session</p></>}</div>;
    }
    if (callStatus === CallStatus.ENDED) {
        return <div className="flex flex-col items-center justify-center h-full text-[var(--c-text-strong)] animate-fade-in"><PhoneOff className="w-14 h-14 text-red-500" /><p className="mt-4 text-lg">Session Ended</p><button onClick={handleRestart} className="mt-4 bg-blue-500 hover:bg-blue-600 text-white font-semibold px-6 py-2 rounded-lg transition-colors">Start New Session</button></div>;
    }
    if (callStatus === CallStatus.ACTIVE) {
        const tabBaseClasses = "flex-1 flex items-center justify-center gap-2 px-4 py-3 text-sm font-medium transition-colors focus:outline-none";
        const activeTabClasses = "text-[var(--c-text-strong)] bg-black/20 dark:bg-white/10";
        const inactiveTabClasses = "text-[var(--c-text-secondary)] hover:bg-black/10 dark:hover:bg-white/5";
        return (
          <>
            <div className="flex-shrink-0 p-1 bg-black/10 dark:bg-white/5 flex justify-center gap-1 border-b border-[var(--c-border)] rounded-t-lg">
                <button onClick={() => handleModeChange('voice')} className={`${tabBaseClasses} rounded-tl-lg ${interactionMode==='voice'?activeTabClasses:inactiveTabClasses}`}><Mic className="w-4 h-4"/> Voice</button>
                <button onClick={() => handleModeChange('chat')} className={`${tabBaseClasses} rounded-tr-lg ${interactionMode==='chat'?activeTabClasses:inactiveTabClasses}`}><MessageSquareText className="w-4 h-4"/> Chat</button>
            </div>

            <div className="flex-grow p-4 space-y-4 overflow-y-auto" ref={messageContainerRef} onScroll={handleScroll}>
                {messages.map((msg, index) => <MessageBubble key={msg.id + '-' + index} message={msg} />)}
                {isAgentThinking && <AgentTypingIndicator />}
            </div>
            
            <div className="flex-shrink-0 border-t border-[var(--c-border)] p-2">
                {interactionMode === 'voice' ? (
                    <div className="flex items-center justify-between text-center px-2">
                        <div className="w-20"><p className="text-sm font-medium text-[var(--c-text-secondary)]">{statusMessage}</p></div>
                        <button onClick={handleHangUpClick} className="bg-red-500 hover:bg-red-600 text-white rounded-full p-4 transition-colors"><PhoneOff className="w-6 h-6"/></button>
                        <div className="w-20"><p className="text-sm font-medium text-[var(--c-text-secondary)]">{formatDuration(callDuration)}</p></div>
                    </div>
                ) : (
                    <form onSubmit={handleSendTextMessage} className="flex items-center gap-2">
                        <input
                            type="text"
                            value={textInput}
                            onChange={(e) => setTextInput(e.target.value)}
                            placeholder="Type your message..."
                            className="w-full bg-[var(--c-bg)] border border-[var(--c-border)] rounded-full px-4 py-2 text-sm text-[var(--c-text-strong)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)]"
                        />
                        <button type="submit" className="bg-[var(--c-primary)] text-white rounded-full p-2.5 hover:opacity-90" aria-label="Send message">
                            <Send className="w-5 h-5"/>
                        </button>
                    </form>
                )}
            </div>
          </>
        );
    }
    return null;
  };

  return (
    <div className="w-full max-w-sm mx-auto bg-[var(--c-surface)] rounded-[40px] shadow-2xl border-4 border-gray-800 dark:border-gray-600 overflow-hidden h-[700px] flex flex-col">
      <div className="flex-shrink-0 bg-gray-800 dark:bg-gray-700 py-2">
        <div className="w-20 h-1 mx-auto bg-gray-600 dark:bg-gray-500 rounded-full"></div>
      </div>
      <header className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[var(--c-border)]">
        <div className="flex items-center gap-2">
            <Bot className="w-6 h-6 text-[var(--c-primary)]" />
            <div>
              <p className="font-semibold text-[var(--c-text-strong)]">Vernika</p>
              {callStatus === CallStatus.ACTIVE ? <p className="text-xs text-green-500 flex items-center gap-1.5"><span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>Connected</p> : <p className="text-xs text-[var(--c-text-secondary)]">Waiting to connect...</p>}
            </div>
        </div>
        {callStatus === CallStatus.ACTIVE && <p className="text-sm text-[var(--c-text-secondary)] font-mono">{formatDuration(callDuration)}</p>}
      </header>
      <main className="flex-grow flex flex-col overflow-hidden">
        {renderContent()}
      </main>
    </div>
  );
};
