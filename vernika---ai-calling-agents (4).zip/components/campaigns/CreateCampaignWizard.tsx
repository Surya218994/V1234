
import React, { useState } from 'react';
import { Agent, AgentConfigurationData } from '../../types';
import Stepper from '../ui/Stepper';
import { X } from '../IconComponents';
import Step1CampaignDetails from './Step1CampaignDetails';
import Step2WorkflowAgent from './Step2WorkflowAgent';
import Step3Review from './Step3Review';

const steps = [
  { title: 'Campaign Details', description: 'Basic campaign information' },
  { title: 'Workflow & Agent', description: 'Select workflow and agent' },
  { title: 'Review', description: 'Review and create campaign' },
];

interface CreateCampaignWizardProps {
  onBack: () => void;
  agents: Agent[];
}

const CreateCampaignWizard: React.FC<CreateCampaignWizardProps> = ({ onBack, agents }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [campaignData, setCampaignData] = useState({
      campaignName: `New campaign ${new Date().toISOString().slice(0, 19).replace('T', ' ')}`,
      description: '',
      candidatesCsv: [],
      workflow: '',
      agent: '',
      fromPhoneNumber: '',
  });

  const updateData = (update: any) => {
    setCampaignData(prev => ({ ...prev, ...update }));
  };

  const handleNext = () => setCurrentStep(prev => Math.min(prev + 1, steps.length));
  const handlePrev = () => setCurrentStep(prev => Math.max(prev - 1, 1));
  
  const handleCreateCampaign = () => {
    console.log("Creating campaign:", campaignData);
    onBack();
  }

  const renderStepContent = () => {
    switch(currentStep) {
      case 1:
        return <Step1CampaignDetails data={campaignData} onUpdate={updateData} onNext={handleNext} />;
      case 2:
        return <Step2WorkflowAgent data={campaignData} onUpdate={updateData} onNext={handleNext} onPrev={handlePrev} agents={agents} />;
      case 3:
        return <Step3Review data={campaignData} onPrev={handlePrev} onCreate={handleCreateCampaign} />;
      default:
        return null;
    }
  }

  return (
    <div className="bg-[var(--c-surface)] border border-[var(--c-border)] rounded-2xl p-6 animate-fade-in shadow-xl">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-[var(--c-text-strong)]">Create New Campaign</h2>
        <button onClick={onBack} className="p-2 rounded-full hover:bg-[var(--c-bg)]">
          <X className="w-5 h-5 text-[var(--c-text-secondary)]" />
        </button>
      </div>
      <div className="mb-8 px-2">
        <Stepper currentStep={currentStep} steps={steps} />
      </div>
      <div>
        {renderStepContent()}
      </div>
    </div>
  );
};

export default CreateCampaignWizard;
