
import React from 'react';
import FileUpload from '../ui/FileUpload';
import { ChevronRight, FileText } from '../IconComponents';

interface Step1Props {
    data: any;
    onUpdate: (data: any) => void;
    onNext: () => void;
}

const Step1CampaignDetails: React.FC<Step1Props> = ({ data, onUpdate, onNext }) => {
    
    return (
        <div className="bg-[var(--c-bg)] border border-[var(--c-border)] rounded-xl p-8 space-y-6">
            <h3 className="text-lg font-semibold text-[var(--c-text-strong)] flex items-center gap-3">
                <FileText className="w-6 h-6 text-[var(--c-primary)]" />
                Campaign Details
            </h3>

            <div>
                <label htmlFor="campaignName" className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Campaign Name</label>
                <input
                    type="text"
                    id="campaignName"
                    value={data.campaignName}
                    onChange={(e) => onUpdate({ campaignName: e.target.value })}
                    className="w-full bg-[var(--c-surface)] border border-[var(--c-border)] rounded-md px-3 py-2 text-sm text-[var(--c-text-strong)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)]"
                />
            </div>

            <div>
                <label htmlFor="description" className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Description</label>
                <textarea
                    id="description"
                    rows={4}
                    value={data.description}
                    onChange={(e) => onUpdate({ description: e.target.value })}
                    placeholder="Campaign description"
                    className="w-full bg-[var(--c-surface)] border border-[var(--c-border)] rounded-md px-3 py-2 text-sm text-[var(--c-text-strong)] focus:outline-none focus:ring-2 focus:ring-[var(--c-primary)]"
                />
            </div>

            <div>
                <label className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Contacts CSV</label>
                <FileUpload files={data.candidatesCsv || []} setFiles={(files) => onUpdate({ candidatesCsv: files })} />
            </div>

            <div className="flex justify-end pt-4">
                 <button
                    onClick={onNext}
                    className="bg-[var(--c-primary)] text-white font-semibold py-2 px-5 rounded-lg hover:opacity-90 transition-colors flex items-center gap-2"
                >
                    <span>Next</span>
                    <ChevronRight className="w-4 h-4" />
                </button>
            </div>
        </div>
    );
};

export default Step1CampaignDetails;
