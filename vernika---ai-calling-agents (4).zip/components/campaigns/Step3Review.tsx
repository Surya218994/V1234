
import React from 'react';
import { ChevronLeft, CheckCircle } from '../IconComponents';

interface Step3Props {
    data: any;
    onPrev: () => void;
    onCreate: () => void;
}

const ReviewItem: React.FC<{label: string; value: string | React.ReactNode}> = ({label, value}) => (
    <div>
        <dt className="text-sm font-medium text-[var(--c-text-secondary)]">{label}</dt>
        <dd className="mt-1 text-sm text-[var(--c-text-strong)] font-semibold">{value || '-'}</dd>
    </div>
);


const Step3Review: React.FC<Step3Props> = ({ data, onPrev, onCreate }) => {
    return (
        <div className="bg-[var(--c-bg)] border border-[var(--c-border)] rounded-xl p-8">
            <h3 className="text-lg font-semibold text-[var(--c-text-strong)] flex items-center gap-3 mb-6">
                <CheckCircle className="w-6 h-6 text-[var(--c-primary)]" />
                Review
            </h3>
            <div className="space-y-6 bg-[var(--c-surface)] p-6 rounded-lg border border-[var(--c-border)]">
                <dl className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                    <ReviewItem label="Campaign Name" value={data.campaignName} />
                    <ReviewItem label="Workflow" value={data.workflow} />
                    <ReviewItem label="Agent" value={data.agent} />
                    <ReviewItem label="From Phone Number" value={data.fromPhoneNumber} />
                    <div className="md:col-span-2">
                        <ReviewItem label="Description" value={data.description} />
                    </div>
                    <div className="md:col-span-2">
                         <ReviewItem label="Contacts CSV" value={data.candidatesCsv?.[0]?.name ?? 'No file chosen'} />
                    </div>
                </dl>
            </div>

            <div className="mt-8 pt-6 border-t border-[var(--c-border)] flex justify-between">
                 <button
                    onClick={onPrev}
                    className="bg-[var(--c-surface)] text-[var(--c-text-strong)] font-semibold py-2 px-5 rounded-lg hover:bg-[var(--c-bg)] border border-[var(--c-border)] transition-colors flex items-center gap-2"
                >
                    <ChevronLeft className="w-4 h-4"/>
                    <span>Back</span>
                </button>
                 <button
                    onClick={onCreate}
                    className="bg-[var(--c-primary)] text-white font-semibold py-2 px-5 rounded-lg hover:opacity-90 transition-colors"
                >
                    Create Campaign
                </button>
            </div>
        </div>
    );
};

export default Step3Review;
