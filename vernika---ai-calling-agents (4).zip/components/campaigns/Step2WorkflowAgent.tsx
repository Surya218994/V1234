
import React from 'react';
import Dropdown from '../ui/Dropdown';
import { ChevronLeft, ChevronRight, GitBranch } from '../IconComponents';
import { Agent, DropdownOption } from '../../types';

interface Step2Props {
    data: any;
    onUpdate: (data: any) => void;
    onNext: () => void;
    onPrev: () => void;
    agents: Agent[];
}

const workflowOptions = [ { value: 'workflow1', label: 'Default Workflow' } ];
const phoneOptions = [ { value: '1234567890', label: '+1 234-567-890' } ];

const Step2WorkflowAgent: React.FC<Step2Props> = ({ data, onUpdate, onNext, onPrev, agents }) => {
    const agentOptions: DropdownOption[] = agents.map(agent => ({
        value: agent.id,
        label: agent.name,
    }));

    return (
        <div className="bg-[var(--c-bg)] border border-[var(--c-border)] rounded-xl p-8">
            <h3 className="text-lg font-semibold text-[var(--c-text-strong)] flex items-center gap-3 mb-6">
                <GitBranch className="w-6 h-6 text-[var(--c-primary)]" />
                Workflow & Agent
            </h3>
            <div className="grid grid-cols-2 gap-8">
                <div className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Select Workflow</label>
                        <Dropdown
                            options={workflowOptions}
                            value={data.workflow}
                            onChange={(val) => onUpdate({ workflow: val })}
                            placeholder="Select Workflow"
                        />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">Select Agent</label>
                        <Dropdown
                            options={agentOptions}
                            value={data.agent}
                            onChange={(val) => onUpdate({ agent: val })}
                             placeholder="Select Agent"
                        />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-[var(--c-text-primary)] mb-2">From phone number</label>
                        <Dropdown
                            options={phoneOptions}
                            value={data.fromPhoneNumber}
                            onChange={(val) => onUpdate({ fromPhoneNumber: val })}
                            placeholder="Select a phone number"
                        />
                         <p className="text-xs text-[var(--c-text-secondary)] mt-2">You can <a href="#" className="text-[var(--c-primary)] hover:underline">purchase phone numbers</a> to start making calls from your own custom numbers.</p>
                    </div>
                </div>
                <div className="flex items-center justify-center bg-[var(--c-surface)] rounded-lg text-[var(--c-text-secondary)] text-sm border border-[var(--c-border)]">
                    Select a workflow to view details
                </div>
            </div>

            <div className="mt-8 pt-6 border-t border-[var(--c-border)] flex justify-between">
                <button
                    onClick={onPrev}
                    className="bg-[var(--c-surface)] text-[var(--c-text-strong)] font-semibold py-2 px-5 rounded-lg hover:bg-[var(--c-bg)] border border-[var(--c-border)] transition-colors flex items-center gap-2"
                >
                    <ChevronLeft className="w-4 h-4" />
                    <span>Back</span>
                </button>
                <button
                    onClick={onNext}
                    className="bg-[var(--c-primary)] text-white font-semibold py-2 px-5 rounded-lg hover:opacity-90 transition-colors flex items-center gap-2"
                >
                    <span>Next</span>
                    <ChevronRight className="w-4 h-4" />
                </button>
            </div>
        </div>
    );
};

export default Step2WorkflowAgent;
