
import React, { useState } from 'react';
import { Agent, DropdownOption, PhoneNumber, TwilioConfig } from '../types';
import { Plus, Spinner, TwilioIcon, Unlink, X, ChevronDown } from './IconComponents';
import Dropdown from './ui/Dropdown';

// --- Start of ImportTwilioModal Component ---
interface ImportTwilioModalProps {
  onClose: () => void;
  onImport: (details: { phoneNumber: string, countryCode: string, accountSid: string, authToken: string, label: string }) => Promise<void>;
}

const CountryCodeDropdown: React.FC<{value: string, onChange: (value: string) => void}> = ({value, onChange}) => {
    const [isOpen, setIsOpen] = useState(false);
    const options = [{code: 'US', name: 'United States', dial: '+1'}];

    return (
        <div className="relative">
            <button type="button" onClick={() => setIsOpen(!isOpen)} className="flex items-center space-x-1 pl-4 pr-3 h-full">
                <span className="font-medium">{value}</span>
                <ChevronDown className="w-4 h-4 text-gray-400" />
            </button>
            {isOpen && (
                <div className="absolute left-0 bottom-full mb-2 w-48 bg-[#131922] border border-gray-700/50 rounded-md shadow-lg z-10 p-1">
                    {options.map(opt => (
                        <div key={opt.code} onClick={() => { onChange(opt.code); setIsOpen(false); }} className="px-3 py-1.5 hover:bg-gray-700/50 cursor-pointer rounded-md text-white">
                           {opt.code}
                        </div>
                    ))}
                </div>
            )}
        </div>
    )
}

const ImportTwilioModal: React.FC<ImportTwilioModalProps> = ({ onClose, onImport }) => {
  const [phoneNumber, setPhoneNumber] = useState('14156021922');
  const [countryCode, setCountryCode] = useState('US');
  const [accountSid, setAccountSid] = useState('');
  const [authToken, setAuthToken] = useState('');
  const [label, setLabel] = useState('');
  const [isImporting, setIsImporting] = useState(false);
  const [error, setError] = useState('');
  const [focusedInput, setFocusedInput] = useState('phone');

  const handleImportClick = async () => {
    if (!accountSid || !authToken || !phoneNumber) {
      setError('Please fill in all required fields.');
      return;
    }
    setError('');
    setIsImporting(true);
    try {
      await onImport({ phoneNumber: `+${phoneNumber}`, countryCode, accountSid, authToken, label });
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsImporting(false);
    }
  };

  const getInputClasses = (name: string) => {
    const baseClasses = "w-full bg-[#131922] border border-gray-700/50 rounded-md p-3 outline-none focus:ring-2 focus:ring-green-400/50 focus:border-green-400 transition-all";
    if (focusedInput === name) {
        return `${baseClasses} border-green-400 ring-2 ring-green-400/30`;
    }
    return baseClasses;
  }

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
        <div className="bg-[#1c212c] rounded-lg shadow-xl w-full max-w-lg text-white" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center border-b border-gray-700/50 px-8 py-5">
                <h2 className="text-lg font-semibold text-white">Import Phone Number</h2>
                <button onClick={onClose} className="p-2 -mr-2 rounded-full hover:bg-gray-700/50"><X className="w-5 h-5 text-gray-400 hover:text-white" /></button>
            </div>
            
            <div className="p-8 space-y-6">
                 <div>
                    <label className="text-sm font-medium text-gray-300 mb-2 block">Twilio Phone Number</label>
                    <div className={`flex items-stretch bg-[#131922] border rounded-md transition-all ${focusedInput === 'phone' ? 'border-green-400 ring-2 ring-green-400/30' : 'border-gray-700/50'}`}>
                        <CountryCodeDropdown value={countryCode} onChange={setCountryCode} />
                        <div className="flex items-center pl-2 pr-3">
                            <span className="text-gray-400">+</span>
                        </div>
                        <input 
                            type="tel"
                            value={phoneNumber}
                            onChange={e => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                            onFocus={() => setFocusedInput('phone')}
                            className="w-full bg-transparent p-3 outline-none"
                            placeholder="14156021922"
                        />
                    </div>
                </div>
                 <div>
                    <label className="text-sm font-medium text-gray-300 mb-2 block">Twilio Account SID</label>
                    <input type="text" placeholder="Twilio Account SID" value={accountSid} onChange={e => setAccountSid(e.target.value)} onFocus={() => setFocusedInput('sid')} className={getInputClasses('sid')} />
                </div>
                 <div>
                    <label className="text-sm font-medium text-gray-300 mb-2 block">Twilio Auth Token</label>
                    <input type="password" placeholder="Twilio Auth Token" value={authToken} onChange={e => setAuthToken(e.target.value)} onFocus={() => setFocusedInput('token')} className={getInputClasses('token')} />
                </div>
                 <div>
                    <label className="text-sm font-medium text-gray-300 mb-2 block">Label</label>
                    <input type="text" placeholder="Label for Phone Number" value={label} onChange={e => setLabel(e.target.value)} onFocus={() => setFocusedInput('label')} className={getInputClasses('label')} />
                </div>

                {error && <p className="text-sm text-red-400 text-center">{error}</p>}
                
                <div className="flex justify-end space-x-4 pt-4">
                    <button onClick={onClose} className="px-8 py-2.5 rounded-md bg-[#374151] hover:bg-gray-500 font-semibold transition-colors">Cancel</button>
                    <button onClick={handleImportClick} disabled={isImporting} className="px-8 py-2.5 rounded-md bg-green-400 text-black hover:opacity-90 font-semibold flex items-center space-x-2 disabled:opacity-70 transition-colors">
                        {isImporting && <Spinner className="w-5 h-5" />}
                        <span>Import from Twilio</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
  );
};
// --- End of ImportTwilioModal Component ---


interface PhoneNumbersPageProps {
  agents: Agent[];
  phoneNumbers: PhoneNumber[];
  twilioConfig: TwilioConfig | null;
  onConnectTwilio: (config: TwilioConfig) => Promise<void>;
  onDisconnectTwilio: () => void;
  onLinkAgentToNumber: (phoneNumberSid: string, agentId: string | null) => void;
  onAddPhoneNumber: (number: PhoneNumber) => void;
}

const PhoneNumbersPage: React.FC<PhoneNumbersPageProps> = ({
  agents,
  phoneNumbers,
  twilioConfig,
  onConnectTwilio,
  onDisconnectTwilio,
  onLinkAgentToNumber,
  onAddPhoneNumber,
}) => {
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  
  const agentOptions: DropdownOption[] = agents.map(agent => ({
    value: agent.id,
    label: agent.name
  }));

  const handleImportNumber = async (details: { phoneNumber: string, countryCode: string, accountSid: string, authToken: string, label: string }) => {
    // If not connected, first establish connection. This also sets the Twilio config in the parent state.
    if (!twilioConfig) {
      await onConnectTwilio({ accountSid: details.accountSid, authToken: details.authToken });
    }
    
    // Simulate adding the number. In a real app, you might verify the number exists in the Twilio account.
    const newNumber: PhoneNumber = {
        sid: `PN${Math.random().toString(36).substring(2, 10)}`,
        phoneNumber: details.phoneNumber,
        friendlyName: details.label || `Imported Number`,
        linkedAgentId: null,
    };
    
    onAddPhoneNumber(newNumber);
  };

  const headers = [
    'Phone number',
    'Friendly Name',
    'Linked Agent',
    'Actions'
  ];

  if (!twilioConfig) {
    return (
        <>
            <div className="text-center py-20 px-6 bg-[var(--c-surface)] border-2 border-dashed border-[var(--c-border)] rounded-2xl animate-fade-in">
                <div className="max-w-md mx-auto">
                <div className="mx-auto w-24 h-24 flex items-center justify-center bg-[var(--c-bg)] rounded-full">
                    <TwilioIcon className="w-12 h-12 text-[#F22F46]" />
                </div>
                <h3 className="text-2xl font-semibold text-[var(--c-text-strong)] mt-6">Connect your Twilio Account</h3>
                <p className="text-[var(--c-text-secondary)] mt-2">Import your Twilio phone numbers to start assigning them to your AI agents for inbound calls.</p>
                <button 
                    onClick={() => setIsImportModalOpen(true)}
                    className="mt-8 flex items-center mx-auto gap-2 bg-[var(--c-primary)] text-white font-semibold py-3 px-6 rounded-lg hover:opacity-90 transition-all transform hover:scale-105">
                    <Plus className="w-5 h-5" />
                    <span>Import Phone Number</span>
                </button>
                </div>
            </div>
            {isImportModalOpen && <ImportTwilioModal onClose={() => setIsImportModalOpen(false)} onImport={handleImportNumber} />}
        </>
    );
  }

  return (
    <>
        <div className="bg-[var(--c-surface)] border border-[var(--c-border)] rounded-2xl animate-fade-in">
            <div className="p-4 flex flex-wrap items-center justify-between gap-4 border-b border-[var(--c-border)]">
                <p className="text-sm text-[var(--c-text-secondary)]">Connected to Twilio Account: <span className="font-semibold text-[var(--c-text-strong)]">{twilioConfig.accountSid}</span></p>
                <div className="flex items-center gap-4">
                    <button onClick={() => setIsImportModalOpen(true)} className="text-sm text-[var(--c-primary)] hover:opacity-80 font-semibold">Import Number</button>
                    <button onClick={onDisconnectTwilio} className="text-sm text-red-500 hover:text-red-700 font-semibold">Disconnect</button>
                </div>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-[var(--c-text-secondary)] min-w-[800px]">
                <thead className="text-xs text-[var(--c-text-secondary)] uppercase bg-[var(--c-bg)] border-b border-[var(--c-border)]">
                    <tr>
                    {headers.map(header => (
                        <th key={header} scope="col" className="px-6 py-4 font-medium whitespace-nowrap">
                        {header}
                        </th>
                    ))}
                    </tr>
                </thead>
                <tbody>
                    {phoneNumbers.length > 0 ? phoneNumbers.map(num => (
                    <tr key={num.sid} className="border-b border-[var(--c-border)] last:border-b-0 hover:bg-[var(--c-bg)]/50">
                        <td className="px-6 py-4 font-semibold text-[var(--c-text-strong)]">{num.phoneNumber}</td>
                        <td className="px-6 py-4">{num.friendlyName}</td>
                        <td className="px-6 py-4 w-64">
                        <Dropdown 
                            options={agentOptions}
                            value={num.linkedAgentId || ''}
                            onChange={(agentId) => onLinkAgentToNumber(num.sid, agentId)}
                            placeholder="Select an agent..."
                        />
                        </td>
                        <td className="px-6 py-4">
                        <button 
                            onClick={() => onLinkAgentToNumber(num.sid, null)} 
                            disabled={!num.linkedAgentId}
                            className="p-2 rounded-md text-[var(--c-text-secondary)] hover:bg-[var(--c-surface)] hover:text-red-500 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:text-[var(--c-text-secondary)]"
                            aria-label="Unlink agent"
                        >
                            <Unlink className="w-5 h-5"/>
                        </button>
                        </td>
                    </tr>
                    )) : (
                    <tr>
                        <td colSpan={headers.length} className="text-center py-20 px-6">
                        <h3 className="text-xl font-semibold text-[var(--c-text-strong)]">No phone numbers found</h3>
                        <p className="text-[var(--c-text-secondary)] mt-2">You haven't imported any numbers from your Twilio account yet.</p>
                        <button 
                            onClick={() => setIsImportModalOpen(true)}
                            className="mt-6 flex items-center mx-auto gap-2 bg-[var(--c-primary)] text-white font-semibold py-2.5 px-5 rounded-lg hover:opacity-90 transition-colors">
                            <Plus className="w-5 h-5" />
                            <span>Import Your First Number</span>
                        </button>
                        </td>
                    </tr>
                    )}
                </tbody>
                </table>
            </div>
        </div>
        {isImportModalOpen && <ImportTwilioModal onClose={() => setIsImportModalOpen(false)} onImport={handleImportNumber} />}
    </>
  );
};

export default PhoneNumbersPage;
