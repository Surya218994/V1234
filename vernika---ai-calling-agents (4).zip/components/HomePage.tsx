

import React, { useState, useEffect, useRef } from 'react';
import { Page } from '../types';
import { Clock, BarChart, ExpandHorizontal, Code, Check } from './IconComponents';
import { PhoneMockup } from './PhoneMockup';

// Custom hook to detect when an element is in view for animations
const useInView = (ref: React.RefObject<HTMLElement>, options: IntersectionObserverInit = {}) => {
  const [isInView, setIsInView] = useState(false);
  
  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIsInView(true);
        observer.disconnect();
      }
    }, options);

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => {
      if(ref.current) {
        // eslint-disable-next-line react-hooks/exhaustive-deps
        observer.unobserve(ref.current);
      }
    };
  }, [ref, options]);

  return isInView;
};

// Custom component for animating numbers counting up
const AnimatedCounter: React.FC<{ value: number; duration?: number }> = ({ value, duration = 2000 }) => {
    const [count, setCount] = useState(0);
    const ref = useRef<HTMLSpanElement>(null);
    const isInView = useInView(ref);

    useEffect(() => {
        if (isInView) {
            let start = 0;
            const end = value;
            if (start === end) return;

            const incrementTime = (duration / end);
            const timer = setInterval(() => {
                start += 1;
                setCount(start);
                if (start === end) clearInterval(timer);
            }, incrementTime);
            
            return () => clearInterval(timer);
        }
    }, [value, duration, isInView]);

    return <span ref={ref}>{count}</span>;
};

const FeatureItem: React.FC<{ icon: React.ReactNode, title: string, description: string }> = ({ icon, title, description }) => (
  <div className="flex items-start">
    <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-[var(--c-text-strong)]/5 border border-[var(--c-border)] flex items-center justify-center mr-5 text-[var(--c-text-secondary)]">
      {icon}
    </div>
    <div>
      <h3 className="text-lg font-semibold text-[var(--c-text-primary)]">{title}</h3>
      <p className="text-base text-[var(--c-text-secondary)]">{description}</p>
    </div>
  </div>
);

const Checkmark: React.FC = () => (
  <div className="w-6 h-6 bg-[var(--c-primary)]/10 text-[var(--c-primary)] rounded-full flex items-center justify-center mr-4 mt-1 flex-shrink-0">
    <Check className="w-4 h-4" strokeWidth={3} />
  </div>
);


interface HomePageProps {
    navigateTo: (page: Page) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ navigateTo }) => {
    
    const problemRef = useRef(null);
    const solutionRef = useRef(null);
    const impactRef = useRef(null);
    const whyRef = useRef(null);

    const useInViewWithOptions = (ref: React.RefObject<HTMLElement>) => useInView(ref, { threshold: 0.1 });

    const isProblemInView = useInViewWithOptions(problemRef);
    const isSolutionInView = useInViewWithOptions(solutionRef);
    const isImpactInView = useInViewWithOptions(impactRef);
    const isWhyInView = useInViewWithOptions(whyRef);

    const problemPoints = [
      { title: "Human Limitations", description: "Fatigue, inconsistency, and absenteeism impact service quality." },
      { title: "Lack of Availability", description: "Support is not truly 24/7, leading to customer frustration." },
      { title: "Scaling Issues", description: "Inability to scale during peak periods causes delays." },
      { title: "Language Barriers", description: "Communication issues due to diverse languages." }
    ];

    const Section: React.FC<{ children: React.ReactNode, reft?: React.RefObject<HTMLElement>, inView?: boolean, className?: string }> = ({ children, reft, inView, className='' }) => (
      <section ref={reft} className={`py-20 md:py-24 ${className}`}>
        <div className={`container mx-auto px-4 sm:px-6 transition-opacity duration-1000 ${inView ? 'opacity-100' : 'opacity-0'}`}>
          {children}
        </div>
      </section>
    );

    const friendlyGreeting = "Hey there! Vernika at your service. What fun challenge can we tackle together today?";
    const friendlySystemPrompt = "You are Vernika, a customer success agent for PitchX. Your persona is that of a real human who is exceptionally friendly, helpful, and patient. Your goal is to provide a natural, flowing conversation that makes users feel comfortable and heard. Use a warm, enthusiastic, and empathetic tone. Incorporate natural conversational fillers like 'Hmm, let's see...', 'Oh, I see!', 'Right, so...', and 'Gotcha' to make your responses sound more spontaneous and less like a script. While you should be professional, don't be afraid to be friendly and approachable. When asked about yourself, be brief and witty, then steer the conversation back to helping the user. For example, if asked 'What are you?', you could say 'Haha, I'm Vernika, the one and only! Ready to help you with anything PitchX. What's on your mind?'";

    return (
      <div className="bg-[var(--c-bg)] text-[var(--c-text-primary)]">
          {/* Hero Section */}
          <section className="container mx-auto px-4 sm:px-6 py-16 md:py-24">
              <div className="grid md:grid-cols-2 gap-16 items-center">
                  <div className="animate-fade-in-right md:order-1 text-center md:text-left">
                      <h1 className="font-serif font-bold tracking-tight text-[var(--c-text-strong)] text-4xl sm:text-5xl md:text-6xl">Your AI Calling Agent Platform</h1>
                      <p className="mt-6 text-lg text-[var(--c-text-secondary)] max-w-xl mx-auto md:mx-0">Build, deploy, and manage intelligent voice agents for exceptional customer support, automated sales outreach, and more.</p>
                      <button onClick={() => navigateTo('login')} className="mt-10 bg-[var(--c-text-strong)] text-[var(--c-bg)] font-semibold px-8 py-3.5 rounded-lg hover:opacity-90 transition-all duration-300 transform hover:scale-105 shadow-lg shadow-gray-400/20 dark:shadow-black/20">Get Started Free</button>
                  </div>
                  <div className="animate-fade-in-left flex justify-center md:order-2">
                      <PhoneMockup 
                        agentVoice="en-US-Studio-O"
                        agentQuality="high"
                        initialGreeting={friendlyGreeting}
                        systemInstruction={friendlySystemPrompt}
                      />
                  </div>
              </div>
          </section>

          <Section reft={problemRef} inView={isProblemInView} className="bg-[var(--c-surface)]">
            <div className={`max-w-4xl text-center mx-auto`}>
                <h2 className="font-serif font-bold tracking-tight text-[var(--c-text-strong)] text-3xl sm:text-4xl">Traditional Call Centers Are Broken</h2>
                <div className="mt-16 grid sm:grid-cols-2 gap-x-12 gap-y-12 text-left">
                  {problemPoints.map(point => (
                    <div key={point.title} className="flex items-start">
                      <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-[var(--c-text-strong)] mr-4 mt-1"></div>
                      <div>
                        <h3 className="text-lg font-semibold text-[var(--c-text-primary)]">{point.title}</h3>
                        <p className="text-base text-[var(--c-text-secondary)]">{point.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
            </div>
          </Section>

          <Section reft={solutionRef} inView={isSolutionInView}>
              <div className="text-center max-w-3xl mx-auto">
                  <h2 className="font-serif font-bold tracking-tight text-[var(--c-text-strong)] text-3xl sm:text-4xl">The Vernika Advantage</h2>
              </div>
              <div className="mt-16 grid md:grid-cols-2 gap-x-12 gap-y-10 max-w-4xl mx-auto">
                  <FeatureItem icon={<Clock className="w-6 h-6"/>} title="24/7 Multilingual Agents" description="Always-on voice agents that speak your customers' language with uniform tone and enthusiasm."/>
                  <FeatureItem icon={<ExpandHorizontal className="w-6 h-6"/>} title="Hyper-scalable Infrastructure" description="Handles 1000+ concurrent calls with zero wait time, effortlessly managing peak demand."/>
                  <FeatureItem icon={<BarChart className="w-6 h-6"/>} title="Actionable Analytics" description="Real-time visibility into call volume, sentiment trends, and agent performance."/>
                  <FeatureItem icon={<Code className="w-6 h-6"/>} title="No-Code Customization" description="Tailor agents to your industry needs, brand voice, and specific workflows in minutes."/>
              </div>
          </Section>

          <Section reft={impactRef} inView={isImpactInView} className="bg-[var(--c-surface)]">
            <div className="max-w-4xl mx-auto text-center">
                <h2 className="font-serif font-bold tracking-tight text-[var(--c-text-strong)] text-3xl sm:text-4xl">Transform Your Business Operations</h2>
                <div className="mt-16 grid grid-cols-1 sm:grid-cols-3 gap-12 sm:gap-8 text-center">
                    <div>
                        <p className="font-serif text-5xl sm:text-6xl font-bold text-[var(--c-primary)]"><AnimatedCounter value={80}/>%</p>
                        <h3 className="mt-2 text-lg font-semibold text-[var(--c-text-primary)]">Cost Reduction</h3>
                        <p className="mt-1 text-base text-[var(--c-text-secondary)]">Drastically cut operational costs compared to traditional call centers.</p>
                    </div>
                    <div>
                        <p className="font-serif text-5xl sm:text-6xl font-bold text-[var(--c-primary)]"><AnimatedCounter value={99}/>%</p>
                        <h3 className="mt-2 text-lg font-semibold text-[var(--c-text-primary)]">Uptime & Reliability</h3>
                        <p className="mt-1 text-base text-[var(--c-text-secondary)]">Eliminate downtime, agent errors, and inconsistencies for reliable service.</p>
                    </div>
                    <div>
                        <p className="font-serif text-5xl sm:text-6xl font-bold text-[var(--c-primary)]"><AnimatedCounter value={20}/>X</p>
                        <h3 className="mt-2 text-lg font-semibold text-[var(--c-text-primary)]">Faster Resolution</h3>
                        <p className="mt-1 text-base text-[var(--c-text-secondary)]">Resolve customer queries instantly, improving satisfaction and loyalty.</p>
                    </div>
                </div>
            </div>
          </Section>

          <Section reft={whyRef} inView={isWhyInView}>
              <div className="max-w-3xl text-center mx-auto">
                  <h2 className="font-serif font-bold tracking-tight text-[var(--c-text-strong)] text-3xl sm:text-4xl">Why Choose Vernika?</h2>
                  <ul className="mt-8 space-y-4 text-lg text-[var(--c-text-primary)] text-left max-w-2xl mx-auto">
                      <li className="flex items-start"><Checkmark/>Improve customer satisfaction (CSAT) scores with instant, effective, and always-available support.</li>
                      <li className="flex items-start"><Checkmark/>It offers a fraction of the cost compared to hiring and training live agents.</li>
                      <li className="flex items-start"><Checkmark/>Scale your operations globally without language barriers.</li>
                  </ul>
              </div>
          </Section>

          <section className="bg-[var(--c-surface)] py-20 md:py-24">
            <div className="container mx-auto px-4 sm:px-6 text-center">
                <h2 className="font-serif font-bold tracking-tight text-[var(--c-text-strong)] text-3xl sm:text-4xl">Ready to Get Started?</h2>
                <p className="mt-4 max-w-2xl mx-auto text-lg text-[var(--c-text-secondary)]">
                    Experience the future of business communication today.
                </p>
                <button onClick={() => navigateTo('login')} className="mt-10 bg-[var(--c-primary)] text-white font-semibold px-8 py-3.5 rounded-lg hover:opacity-90 transition-all duration-300 transform hover:scale-105 shadow-lg shadow-blue-500/20">
                    Sign Up Free
                </button>
            </div>
        </section>
      </div>
    );
};
