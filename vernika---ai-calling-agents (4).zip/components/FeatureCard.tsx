import React from 'react';

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

export const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description }) => {
  return (
    <div className="bg-[var(--c-surface)] p-8 rounded-2xl border border-[var(--c-border)] transition-all duration-300 group hover:-translate-y-1 hover:shadow-lg">
      <div className="relative z-10">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-lg bg-[var(--c-primary)]/10 text-[var(--c-primary)] mb-6">
          {icon}
        </div>
        <h3 className="text-xl font-semibold text-[var(--c-text-strong)]">{title}</h3>
        <p className="mt-2 text-[var(--c-text-secondary)]">{description}</p>
      </div>
    </div>
  );
};