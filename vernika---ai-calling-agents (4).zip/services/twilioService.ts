
import { TwilioConfig } from '../types';

interface InitiateCallParams {
  to: string;
  from: string;
  agentId: string;
  twilioConfig: TwilioConfig;
}

// =================================================================================
//                               !!! IMPORTANT !!!
// This URL points to your deployed 'initiate-call' Edge Function.
// =================================================================================
const INITIATE_CALL_FUNCTION_URL = 'https://ovqfxjhsnupetcvmnaxi.supabase.co/functions/v1/initiate-call';

/**
 * Invokes a Supabase Edge Function to initiate a real phone call via Twilio.
 * This function acts as a secure bridge between the frontend and the backend logic.
 *
 * @param params - The parameters for the call.
 * @returns A promise that resolves with the call SID on success.
 * @throws An error if the function URL is still a placeholder.
 */
export const initiateRealCall = async (params: InitiateCallParams): Promise<{ callSid: string }> => {
  if (INITIATE_CALL_FUNCTION_URL.includes('YOUR_SUPABASE_PROJECT_ID')) {
    throw new Error("Backend not configured. Please deploy the Supabase 'initiate-call' function and update the INITIATE_CALL_FUNCTION_URL constant in 'services/twilioService.ts'.");
  }

  const { to, from, agentId, twilioConfig } = params;

  console.log('--- INVOKING SUPABASE EDGE FUNCTION "initiate-call" ---');
  
  try {
    const response = await fetch(INITIATE_CALL_FUNCTION_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            to,
            from,
            agentId,
            twilioAccountSid: twilioConfig.accountSid,
            twilioAuthToken: twilioConfig.authToken,
        }),
    });

    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `The backend function failed with status ${response.status}.`);
    }

    const data = await response.json();
    
    if (!data.callSid) {
        throw new Error(data.error || 'The backend function did not return a Call SID.');
    }

    console.log('Supabase Edge Function response:', data);
    return { callSid: data.callSid };

  } catch (error) {
    console.error('Error invoking Supabase Edge function:', error);
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred.';
    throw new Error(errorMessage);
  }
};