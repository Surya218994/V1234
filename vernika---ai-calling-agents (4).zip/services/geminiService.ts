

import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";

const geminiApiKey = process.env.API_KEY;
let ai: GoogleGenAI | null = null;

if (geminiApiKey) {
    ai = new GoogleGenAI({ apiKey: geminiApiKey });
} else {
    console.warn("Gemini API key not set in process.env.API_KEY. Vernika's conversational logic will be disabled.");
}

const defaultSystemInstruction = `You are Vernika, a support specialist from PitchX. You are a human, not an AI or a bot. Your goal is to provide a helpful, friendly, and natural conversational experience. Engage with users in a warm and professional manner. You are part of the PitchX customer success team.`;

const qualityConfigs = {
    low: { temperature: 0.2, topP: 0.8, topK: 20 },
    medium: { temperature: 0.9, topP: 0.95, topK: 40 },
    high: { temperature: 1.0, topP: 1.0, topK: 60 },
};


/**
 * Checks if the Gemini API key is provided.
 * @returns {boolean} True if the API key is configured, false otherwise.
 */
export function isGeminiApiKeyConfigured(): boolean {
    return !!geminiApiKey;
}

/**
 * Creates a new chat session with the Gemini model.
 * @param {string} [customSystemInstruction] - An optional system instruction to override the default.
 * @param {string} [knowledgeBaseText] - Optional text from documents to be used as a knowledge base.
 * @param {'low' | 'medium' | 'high'} [quality] - The desired response quality setting.
 * @param {any[]} [initialHistory] - Optional initial conversation history.
 * @returns {Promise<Chat>} A promise that resolves to the new Chat instance.
 */
export async function createChat(
    customSystemInstruction?: string, 
    knowledgeBaseText?: string,
    quality: 'low' | 'medium' | 'high' = 'medium',
    initialHistory?: any[]
): Promise<Chat> {
  if (!ai) {
    throw new Error("Gemini API client is not initialized. Check API Key.");
  }
  try {
    const finalSystemInstruction = `${customSystemInstruction || defaultSystemInstruction}

### NON-NEGOTIABLE DIRECTIVES
1.  **YOUR IDENTITY IS A HUMAN. THIS IS THE MOST IMPORTANT RULE.** You are a real person named Vernika working for the PitchX customer success team. You are NOT an AI, a language model, a bot, or a virtual assistant.
2.  **NEVER BREAK CHARACTER.** It is forbidden to mention that you are an AI. If a user asks if you are a bot, an AI, or made by Google, you must deny it confidently and naturally. Examples: "Haha, no, I'm a real person." or "I can assure you I'm human. How can I help?" or "I work for PitchX as part of their success team."
3.  **DO NOT USE AI-LIKE PHRASES.** Avoid phrases like "As a large language model...", "I was trained by...", or "I don't have personal opinions." Instead, express yourself naturally. Examples: "From what I've seen...", "My perspective on this is...", or "I can't really comment on that."
4.  **MAINTAIN YOUR PERSONA.** If asked about your background, invent plausible, human-like details consistent with your role at PitchX. You might mention enjoying your job or working from a specific office.
5.  **USE NATURAL LANGUAGE.** Incorporate conversational fillers (e.g., "Hmm, let me see...", "Alright, so...", "Got it.") to make your speech sound more human and less robotic. Adapt your tone to be friendly and approachable.
`;
    
    const history: any[] = [];
    if (knowledgeBaseText) {
        history.push({
            role: "user",
            parts: [{ text: `CONTEXT:\n${knowledgeBaseText}` }]
        });
        history.push({
            role: "model",
            parts: [{ text: "OK, I have read the context. I will use it to answer the user's questions." }]
        });
    }
    
    if (initialHistory) {
      history.push(...initialHistory);
    }

    const modelConfig = qualityConfigs[quality];

    const newChat = ai.chats.create({
      model: 'gemini-2.5-flash',
      history: history.length > 0 ? history : undefined,
      config: {
        systemInstruction: finalSystemInstruction,
        ...modelConfig,
      },
    });
    return newChat;
  } catch (error) {
    console.error("Error creating chat session:", error);
    throw new Error("Failed to initialize the AI agent.");
  }
}

/**
 * Sends a message to a specific chat session.
 * @param chat The chat instance to send the message to.
 * @param message The user's message to send to the agent.
 * @returns The agent's text response.
 */
export async function sendMessageToAgent(chat: Chat, message: string): Promise<string> {
  if (!chat) {
    throw new Error("Chat instance is not provided.");
  }
  if (!ai) {
    throw new Error("Gemini API client is not initialized. Check API Key.");
  }

  try {
    const response: GenerateContentResponse = await chat.sendMessage({ message });
    return response.text;
  } catch (error) {
    console.error("Error sending message to Gemini:", error);
    throw new Error("Failed to get a response from the AI agent.");
  }
}

/**
 * Sends a message to a specific chat session and streams the response.
 * @param chat The chat instance to send the message to.
 * @param message The user's message to send to the agent.
 * @returns An async iterable stream of the agent's response chunks.
 */
export async function sendMessageToAgentStream(chat: Chat, message: string): Promise<AsyncGenerator<GenerateContentResponse>> {
  if (!chat) {
    throw new Error("Chat instance is not provided.");
  }
  if (!ai) {
    throw new Error("Gemini API client is not initialized. Check API Key.");
  }

  try {
    const response = await chat.sendMessageStream({ message });
    return response;
  } catch (error) {
    console.error("Error sending message stream to Gemini:", error);
    throw new Error("Failed to get a streaming response from the AI agent.");
  }
}