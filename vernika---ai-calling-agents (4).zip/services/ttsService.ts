

let browserVoices: SpeechSynthesisVoice[] = [];
let voicesLoadedPromise: Promise<SpeechSynthesisVoice[]> | null = null;

// --- Google TTS specific variables ---
const GOOGLE_API_KEY = "AIzaSyBwrKXiBkIqAj3fFBGkjX2l4rqYMWqVPI4";
let audioContext: AudioContext | null = null;
let audioSource: AudioBufferSourceNode | null = null;

interface SpeechHandlers {
    onEnd: () => void;
    onError: (event: string | Event) => void;
}

// --- Combined Stop Function ---
export const stopSpeech = (): void => {
    // Stop Browser TTS
    if (window.speechSynthesis && window.speechSynthesis.speaking) {
        window.speechSynthesis.cancel();
    }
    // Stop Google TTS (Web Audio API)
    if (audioSource) {
        try {
            audioSource.stop();
        } catch (e) {
            // Can throw an error if already stopped, which is fine.
        }
        audioSource = null;
    }
};

// --- Browser TTS Logic ---
const loadVoices = (): Promise<SpeechSynthesisVoice[]> => {
    if (browserVoices.length > 0) {
        return Promise.resolve(browserVoices);
    }
    if (voicesLoadedPromise) {
        return voicesLoadedPromise;
    }
    voicesLoadedPromise = new Promise((resolve, reject) => {
        if (!window.speechSynthesis) {
           return reject("Speech Synthesis not supported by this browser.");
        }
        const getAndResolveVoices = () => {
            const voices = window.speechSynthesis.getVoices();
            if (voices.length > 0) {
                browserVoices = voices;
                resolve(voices);
                return true;
            }
            return false;
        };
        if (!getAndResolveVoices()) {
            window.speechSynthesis.onvoiceschanged = getAndResolveVoices;
        }
    });
    return voicesLoadedPromise;
};

export const getAvailableBrowserVoices = async (): Promise<{ value: string, label: string }[]> => {
    try {
        const voices = await loadVoices();
        return voices
            .filter(voice => voice.lang.startsWith('en-'))
            .map(voice => ({
                value: voice.name,
                label: `${voice.name} (${voice.lang})`,
            }));
    } catch (error) {
        console.error("Could not get browser voices:", error);
        return [];
    }
};

const synthesizeWithBrowser = (text: string, voiceName: string, handlers: SpeechHandlers): void => {
    loadVoices().then(voices => {
        const utterance = new SpeechSynthesisUtterance(text);
        const selectedVoice = voices.find(v => v.name === voiceName);
        utterance.voice = selectedVoice || voices.find(v => v.lang.startsWith('en-US')) || voices[0];
        if (!selectedVoice && voiceName) {
            console.warn(`Browser voice "${voiceName}" not found. Using default.`);
        }
        utterance.onend = handlers.onEnd;
        utterance.onerror = (e: SpeechSynthesisErrorEvent) => {
            if (e.error === 'interrupted' || e.error === 'canceled') return;
            handlers.onError(`Browser TTS Error: ${e.error || 'Unknown error'}`);
        };
        window.speechSynthesis.speak(utterance);
    }).catch(err => {
        handlers.onError(`Failed to load browser voices: ${err.message || String(err)}`);
    });
};


// --- Google TTS Logic ---
const getAudioContext = () => {
  if (!audioContext) {
    audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  return audioContext;
};

const playAudioBuffer = (buffer: ArrayBuffer, onEnd: () => void, onError: (e: any) => void) => {
    const audioCtx = getAudioContext();
    audioCtx.decodeAudioData(buffer, (decodedData) => {
        if (audioSource) {
            audioSource.stop();
        }
        audioSource = audioCtx.createBufferSource();
        audioSource.buffer = decodedData;
        audioSource.connect(audioCtx.destination);
        audioSource.onended = onEnd;
        audioSource.start(0);
    }, (error) => {
        console.error('Error decoding audio data', error);
        onError('Failed to decode audio.');
    });
};

const synthesizeWithGoogle = async (text: string, voiceName: string, handlers: SpeechHandlers) => {
    const HINDI_CHARS_REGEX = /[\u0900-\u097F]/;
    const isHindi = HINDI_CHARS_REGEX.test(text);
    
    // Dynamically determine language code from voice name.
    const languageCode = isHindi ? 'hi-IN' : (voiceName.split('-')[0] + '-' + voiceName.split('-')[1]);
    const voiceToUse = isHindi ? { name: 'hi-IN-Wavenet-A', languageCode: 'hi-IN' } : { name: voiceName, languageCode };
    
    const body = {
        input: { text },
        voice: voiceToUse,
        audioConfig: {
            audioEncoding: 'OGG_OPUS',
            speakingRate: 1,
            pitch: 0,
        },
    };
    
    try {
        if (!GOOGLE_API_KEY) {
            throw new Error("Google API key is not configured.");
        }
        const response = await fetch(`https://texttospeech.googleapis.com/v1/text:synthesize?key=${GOOGLE_API_KEY}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        });

        if (!response.ok) {
            const errorData = await response.json();
            const errorMessage = errorData?.error?.message || `API request failed with status ${response.status}`;
            throw new Error(errorMessage);
        }

        const data = await response.json();
        if (data.audioContent) {
            const audioBuffer = Uint8Array.from(atob(data.audioContent), c => c.charCodeAt(0)).buffer;
            playAudioBuffer(audioBuffer, handlers.onEnd, handlers.onError);
        } else {
            throw new Error("No audio content in response.");
        }
    } catch (error) {
        const message = error instanceof Error ? error.message : "An unknown error occurred.";
        console.error('Google TTS failed:', message);
        handlers.onError(`Google TTS failed:\n${message}`);
    }
};


// --- Main Dispatcher Function ---
export const synthesizeSpeech = (params: {
    text: string;
    quality?: 'low' | 'medium' | 'high';
    voice?: string; // Google voice
    accent?: string; // Browser voice
    handlers: SpeechHandlers;
}) => {
    const { text, quality = 'medium', voice = '', accent = '', handlers } = params;

    if (!text.trim()) {
        handlers.onEnd();
        return;
    }
    stopSpeech();

    if (quality === 'low') {
        synthesizeWithBrowser(text, accent, handlers);
    } else {
        synthesizeWithGoogle(text, voice, handlers);
    }
};
