
import { AuthUser, Agent, CallHistoryRecord, TwilioConfig, PhoneNumber } from '../types';

const USERS_STORAGE_KEY = 'vernika_users';
const getAgentsKey = (email: string) => `vernika_agents_${email.toLowerCase()}`;
const getCallHistoryKey = (email: string) => `vernika_call_history_${email.toLowerCase()}`;
const getTwilioConfigKey = (email: string) => `vernika_twilio_config_${email.toLowerCase()}`;
const getPhoneNumbersKey = (email: string) => `vernika_phone_numbers_${email.toLowerCase()}`;


// Helper to save users to localStorage
const saveUsers = (users: AuthUser[]): void => {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
};

// Helper to get users from localStorage with enhanced validation
const getUsers = (): AuthUser[] => {
    const usersJson = localStorage.getItem(USERS_STORAGE_KEY);
    if (!usersJson) {
        return [];
    }
    try {
        const parsedData = JSON.parse(usersJson);
        
        if (!Array.isArray(parsedData)) {
            console.error("User data in localStorage is not an array. Clearing.");
            localStorage.removeItem(USERS_STORAGE_KEY);
            return [];
        }

        const validUsers = parsedData.filter(user => 
            user && typeof user === 'object' &&
            typeof user.name === 'string' &&
            typeof user.email === 'string' &&
            typeof user.password === 'string'
        );

        if (validUsers.length < parsedData.length) {
            console.warn("Removed malformed user records from localStorage.");
            saveUsers(validUsers);
        }

        return validUsers;

    } catch (error) {
        console.error("Failed to parse users from localStorage. Data might be corrupted.", error);
        localStorage.removeItem(USERS_STORAGE_KEY);
        return [];
    }
};

/**
 * Retrieves agents for a specific user from localStorage.
 * @param email The user's email.
 * @returns The user's agents array or null if not found.
 */
export const getUserAgents = (email: string): Agent[] | null => {
    const key = getAgentsKey(email);
    const dataJson = localStorage.getItem(key);
    if (!dataJson) {
        return null;
    }
    try {
        const data = JSON.parse(dataJson);
        // Restore the non-serializable File array property
        const restoredAgents = data.map((agent: Agent) => {
            if (agent.configuration) {
                agent.configuration.knowledgeBaseFiles = [];
            }
            return agent;
        });
        return restoredAgents as Agent[];
    } catch (error) {
        console.error(`Failed to parse agent data for ${email}`, error);
        localStorage.removeItem(key);
        return null;
    }
};

/**
 * Saves agents for a specific user to localStorage.
 * This function strips out non-serializable File objects.
 * @param email The user's email.
 * @param agents The agents array to save.
 */
export const saveUserAgents = (email: string, agents: Agent[]): void => {
    const key = getAgentsKey(email);
    // Create a deep copy to avoid mutating state, and remove File objects.
    const agentsToSave = JSON.parse(JSON.stringify(agents));
    agentsToSave.forEach((agent: Agent) => {
        if (agent.configuration?.knowledgeBaseFiles) {
            delete agent.configuration.knowledgeBaseFiles;
        }
    });
    localStorage.setItem(key, JSON.stringify(agentsToSave));
};

/**
 * Retrieves call history for a specific user from localStorage.
 * @param email The user's email.
 * @returns The user's call history array or null if not found.
 */
export const getUserCallHistory = (email: string): CallHistoryRecord[] | null => {
    const key = getCallHistoryKey(email);
    const dataJson = localStorage.getItem(key);
    if (!dataJson) return null;
    try {
        return JSON.parse(dataJson) as CallHistoryRecord[];
    } catch (error) {
        console.error(`Failed to parse call history for ${email}`, error);
        localStorage.removeItem(key);
        return null;
    }
};

/**
 * Saves call history for a specific user to localStorage.
 * @param email The user's email.
 * @param history The call history array to save.
 */
export const saveUserCallHistory = (email: string, history: CallHistoryRecord[]): void => {
    const key = getCallHistoryKey(email);
    localStorage.setItem(key, JSON.stringify(history));
};


/**
 * Simulates sending a welcome email to a new user.
 */
const sendWelcomeEmail = (name: string, email: string): void => {
  const emailContent = `
    Subject: Welcome to Vernika!
    Hi ${name},
    Welcome to Vernika, powered by PitchX! We're thrilled to have you on board.
    You're now ready to start creating, configuring, and deploying your own AI agents.
    Best regards,
    The Vernika Team
  `;
  console.log('--- SIMULATING WELCOME EMAIL ---');
  console.log(`Sending to: ${email}`);
  console.log(emailContent.trim());
  console.log('------------------------------');
};

// Initialize default user and their data if not present
(() => {
    const users = getUsers();
    if (users.length === 0) {
        const defaultUser: AuthUser = { name: 'Test User', email: 'test@example.com', password: 'password123' };
        saveUsers([defaultUser]);

        // Generate mock call history ONLY for the default test user for a good demo experience.
        const defaultUserHistory = getUserCallHistory(defaultUser.email);
        if (!defaultUserHistory) {
            const generateMockCallHistory = (count: number): CallHistoryRecord[] => {
                const records: CallHistoryRecord[] = [];
                const agents: CallHistoryRecord['agent'][] = [{ name: 'Eva', category: 'Support' }, { name: 'Maya', category: 'Sales' }, { name: 'Mia', category: 'Scheduling' }];
                const statuses: CallHistoryRecord['status'][] = ['Completed', 'Completed', 'Failed', 'No Answer'];
                const summaries = [
                    'Customer inquired about pricing plans and was directed to the website.',
                    'Follow-up call regarding a recent support ticket. Issue was resolved.',
                    'Scheduled a product demo for next Tuesday at 2 PM.',
                    'Call was not answered, left a voicemail.',
                    'Connection failed due to a network error on the customer side.'
                ];
                for (let i = 0; i < count; i++) {
                    const agent = agents[Math.floor(Math.random() * agents.length)];
                    const status = statuses[Math.floor(Math.random() * statuses.length)];
                    records.push({
                        id: `call_${Date.now() - i * 100000}`,
                        agent: agent,
                        contact: `+91 98765 ${String(Math.floor(10000 + Math.random() * 90000))}`,
                        duration: Math.floor(Math.random() * 600) + 30,
                        cost: Math.random() * 15 + 2,
                        status: status,
                        timestamp: new Date(Date.now() - i * 3600000 * Math.random()).toISOString(),
                        summary: summaries[Math.floor(Math.random() * summaries.length)],
                    });
                }
                return records;
            };
            saveUserCallHistory(defaultUser.email, generateMockCallHistory(50));
        }
    }
})();

export const getUserByEmail = (email: string): AuthUser | null => {
    const users = getUsers();
    const trimmedEmail = email.trim().toLowerCase();
    const user = users.find(u => u.email.toLowerCase() === trimmedEmail);
    return user || null;
};

export const register = (name: string, email: string, password: string): AuthUser => {
    const users = getUsers();
    const trimmedEmail = email.trim();
    if (!trimmedEmail) throw new Error('Email cannot be empty.');

    const existingUser = users.find(user => user.email.toLowerCase() === trimmedEmail.toLowerCase());

    if (existingUser) {
        throw new Error('Email already exists. Please sign in.');
    }

    const newUser: AuthUser = { name, email: trimmedEmail, password };
    const updatedUsers = [...users, newUser];
    saveUsers(updatedUsers);

    try {
        sendWelcomeEmail(name, trimmedEmail);
    } catch (error) {
        console.error("Failed to send welcome email:", error);
    }

    return newUser;
};

export const login = (email: string, password: string): AuthUser => {
    const users = getUsers();
    const trimmedEmail = email.trim().toLowerCase();
    const user = users.find(u => u.email.toLowerCase() === trimmedEmail);

    if (!user || user.password !== password) {
        throw new Error('Invalid email or password.');
    }

    return user;
};

/**
 * Simulates a sign-in with Google.
 * If the user doesn't exist, it creates a new account.
 * @returns The user object.
 */
export const signInWithGoogle = (): AuthUser => {
    const googleTestEmail = 'google.user@example.com';
    let user = getUserByEmail(googleTestEmail);

    if (!user) {
        user = register('Google User', googleTestEmail, 'google_password_placeholder');
    }
    
    return user;
};


// --- Twilio Integration Service Functions ---

export const saveUserTwilioConfig = (email: string, config: TwilioConfig): void => {
    localStorage.setItem(getTwilioConfigKey(email), JSON.stringify(config));
};

export const getUserTwilioConfig = (email: string): TwilioConfig | null => {
    const configJson = localStorage.getItem(getTwilioConfigKey(email));
    if (!configJson) return null;
    try {
        return JSON.parse(configJson);
    } catch {
        return null;
    }
};

export const saveUserPhoneNumbers = (email: string, numbers: PhoneNumber[]): void => {
    localStorage.setItem(getPhoneNumbersKey(email), JSON.stringify(numbers));
};

export const getUserPhoneNumbers = (email: string): PhoneNumber[] | null => {
    const numbersJson = localStorage.getItem(getPhoneNumbersKey(email));
    if (!numbersJson) return null;
    try {
        return JSON.parse(numbersJson);
    } catch {
        return null;
    }
};

export const removeUserTwilioData = (email: string): void => {
    localStorage.removeItem(getTwilioConfigKey(email));
    localStorage.removeItem(getPhoneNumbersKey(email));
};

/**
 * Simulates connecting to Twilio and fetching the user's phone numbers.
 * @param config The user's Twilio credentials.
 * @returns A promise that resolves to an array of mock phone numbers.
 */
export const connectToTwilioAndFetchNumbers = async (config: TwilioConfig): Promise<PhoneNumber[]> => {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    // In a real app, you would validate the config with the Twilio API.
    // Here, we'll just check if the keys look plausible.
    if (!config.accountSid.startsWith('AC') || config.authToken.length < 30) {
        throw new Error("Invalid Twilio credentials. Please check your Account SID and Auth Token.");
    }
    
    // Return an empty list now. We will add numbers manually via the import modal.
    return [];
};
